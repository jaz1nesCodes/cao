
<?php
require_once __DIR__ . '/config.php';

if (empty($_SESSION['customer'])) {
    redirect('customer_login.php');
}

$pdo = db();
$customerId = (int)($_SESSION['customer']['id'] ?? 0);
$customerName = $_SESSION['customer']['name'] ?? 'Customer';

$stmt = $pdo->prepare("
    SELECT *
    FROM orders
    WHERE customer_id = ?
    ORDER BY created_at DESC
");

$stmt->execute([$customerId]);
$orders = $stmt->fetchAll();

$itemStmt = $pdo->prepare("
    SELECT product_name, quantity, unit_price, subtotal
    FROM order_items
    WHERE order_id = ?
    ORDER BY id ASC
");

function orderMessage(string $status): string {
    switch ($status) {
        case 'Pending':
            return 'Your order has been received. Waiting for seller approval.';
        case 'Preparing':
            return 'Good news! Your order has been approved and is now being prepared.';
        case 'Ready for Pickup':
            return 'Your order is ready! You can now pick it up at your selected branch.';
        case 'Completed':
            return 'Your order has been completed. Thank you for shopping with Jobili!';
        case 'Cancelled':
            return 'Your order has been cancelled. Please contact the store if you need assistance.';
        default:
            return 'Your order status has been updated.';
    }
}

function orderColor(string $status): string {
    switch ($status) {
        case 'Pending': return '#b7791f';
        case 'Preparing': return '#2563eb';
        case 'Ready for Pickup': return '#15803d';
        case 'Completed': return '#15803d';
        case 'Cancelled': return '#dc2626';
        default: return '#555';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Orders - Jobili</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #f5f5f5;
    color: #222;
    font-family: Arial, sans-serif;
}

.navbar {
    background: white;
    padding: 18px 6%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
    gap: 15px;
    flex-wrap: wrap;
}

.logo {
    color: #d62828;
    font-size: 25px;
    font-weight: bold;
}

.nav-right {
    display: flex;
    align-items: center;
    gap: 20px;
    font-size: 14px;
    flex-wrap: wrap;
}

.nav-right a {
    color: #d62828;
    text-decoration: none;
    font-weight: bold;
}

.container {
    width: 90%;
    max-width: 1100px;
    margin: 30px auto;
}

.welcome {
    margin-bottom: 25px;
}

.welcome p {
    color: #777;
}

.order-card {
    background: white;
    border-radius: 12px;
    padding: 22px;
    margin-bottom: 20px;
    box-shadow: 0 3px 12px rgba(0,0,0,.05);
}

.order-header {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    flex-wrap: wrap;
    border-bottom: 1px solid #eee;
    padding-bottom: 15px;
}

.status {
    font-weight: bold;
}

.notice {
    margin-top: 15px;
    padding: 13px;
    border-radius: 7px;
    background: #fef3c7;
    color: #92400e;
    font-size: 14px;
}

.order-info {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
    margin: 18px 0;
}

.order-info small {
    display: block;
    color: #777;
    margin-bottom: 5px;
}

.products {
    border-top: 1px solid #eee;
    padding-top: 15px;
}

.product-row {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    padding: 9px 0;
    border-bottom: 1px solid #f1f1f1;
    font-size: 14px;
}

.total {
    display: flex;
    justify-content: space-between;
    font-size: 18px;
    font-weight: bold;
    margin-top: 18px;
    color: #d62828;
}

.empty {
    background: white;
    padding: 35px;
    text-align: center;
    border-radius: 12px;
    color: #777;
}

.btn {
    display: inline-block;
    padding: 11px 17px;
    border-radius: 7px;
    background: #d62828;
    color: white;
    text-decoration: none;
    font-weight: bold;
    margin-top: 15px;
}

@media(max-width: 600px) {
    .order-info {
        grid-template-columns: 1fr;
    }
}
</style>
</head>

<body>

<header class="navbar">
    <div class="logo">JOBILI</div>

    <div class="nav-right">
        <span>Hello, <?= e($customerName) ?>!</span>
        <a href="customer_shop.php">Shop</a>
        <a href="customer_orders.php">My Orders</a>
        <a href="customer_logout.php">Logout</a>
    </div>
</header>

<main class="container">

    <div class="welcome">
        <h1>My Orders</h1>
        <p>Track your orders and check their latest status.</p>
    </div>

    <?php if (!$orders): ?>

        <div class="empty">
            <h3>No orders yet.</h3>
            <p>Your purchased products will appear here.</p>
            <a href="customer_shop.php" class="btn">Browse Products</a>
        </div>

    <?php else: ?>

        <?php foreach ($orders as $order): ?>

            <section class="order-card">

                <div class="order-header">
                    <div>
                        <small>Order Number</small>
                        <h3><?= e($order['order_number']) ?></h3>
                    </div>

                    <div class="status"
                         style="color:<?= e(orderColor($order['order_status'])) ?>">

                        <?= e($order['order_status']) ?>

                    </div>
                </div>

                <div class="notice">
                    <?= e(orderMessage($order['order_status'])) ?>
                </div>

                <div class="order-info">

                    <div>
                        <small>Pickup Branch</small>
                        <strong><?= e($order['pickup_branch']) ?></strong>
                    </div>

                    <div>
                        <small>Pickup Date</small>
                        <strong>
                            <?= date('M j, Y', strtotime($order['pickup_date'])) ?>
                        </strong>
                    </div>

                    <div>
                        <small>Pickup Time</small>
                        <strong>
                            <?= date('g:i A', strtotime($order['pickup_time'])) ?>
                        </strong>
                    </div>

                    <div>
                        <small>Payment</small>
                        <strong>
                            <?= e($order['payment_method']) ?>
                            - <?= e($order['payment_status']) ?>
                        </strong>
                    </div>

                </div>

                <div class="products">

                    <h4>Ordered Products</h4>

                    <?php
                    $itemStmt->execute([(int)$order['id']]);
                    $items = $itemStmt->fetchAll();
                    ?>

                    <?php foreach ($items as $item): ?>

                        <div class="product-row">
                            <span>
                                <?= e($item['product_name']) ?>
                                × <?= (int)$item['quantity'] ?>
                            </span>

                            <strong><?= money($item['subtotal']) ?></strong>
                        </div>

                    <?php endforeach; ?>

                </div>

                <div class="total">
                    <span>Total Amount</span>
                    <span><?= money($order['total_amount']) ?></span>
                </div>

                <small style="display:block;color:#888;margin-top:12px;">
                    Order placed:
                    <?= date('M j, Y g:i A', strtotime($order['created_at'])) ?>
                </small>

            </section>

        <?php endforeach; ?>

    <?php endif; ?>

</main>

</body>
</html>
