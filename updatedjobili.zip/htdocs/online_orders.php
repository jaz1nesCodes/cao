
<?php
require __DIR__ . '/config.php';
require_login();

$pdo = db();
$pageTitle = 'Online Orders';

$user = current_user();

if (!in_array($user['role'] ?? '', ['owner', 'cashier'], true)) {
    http_response_code(403);
    exit('Access denied.');
}

// PROCESS SELLER ACTIONS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $action = $_POST['action'] ?? '';
    $orderId = (int)($_POST['order_id'] ?? 0);

    try {
        if ($orderId < 1) {
            throw new RuntimeException('Invalid order.');
        }

        $pdo->beginTransaction();

        // Lock selected order
        $stmt = $pdo->prepare("
            SELECT *
            FROM orders
            WHERE id = ?
            FOR UPDATE
        ");
        $stmt->execute([$orderId]);
        $order = $stmt->fetch();

        if (!$order) {
            throw new RuntimeException('Order not found.');
        }

        $userId = (int)$user['id'];

        // ACCEPT ORDER
        if ($action === 'accept') {

            if ($order['order_status'] !== 'Pending') {
                throw new RuntimeException('This order is no longer pending.');
            }

            if ((int)$order['stock_deducted'] === 1) {
                throw new RuntimeException('Stock has already been deducted.');
            }

            $stmt = $pdo->prepare("
                SELECT product_id, SUM(quantity) AS total_qty
                FROM order_items
                WHERE order_id = ?
                GROUP BY product_id
            ");
            $stmt->execute([$orderId]);
            $items = $stmt->fetchAll();

            if (!$items) {
                throw new RuntimeException('This order has no products.');
            }

            $productStmt = $pdo->prepare("
                SELECT id, name, stock
                FROM products
                WHERE id = ?
                FOR UPDATE
            ");

            $deductions = [];

            foreach ($items as $item) {
                $productId = (int)$item['product_id'];
                $qty = (int)$item['total_qty'];

                if ($productId < 1 || $qty < 1) {
                    throw new RuntimeException('Invalid product quantity.');
                }

                $productStmt->execute([$productId]);
                $product = $productStmt->fetch();

                if (!$product) {
                    throw new RuntimeException('A product in this order no longer exists.');
                }

                if ((int)$product['stock'] < $qty) {
                    throw new RuntimeException(
                        'Not enough stock for ' . $product['name'] .
                        '. Available: ' . $product['stock'] .
                        ', Required: ' . $qty
                    );
                }

                $deductions[] = [
                    'id' => $productId,
                    'qty' => $qty
                ];
            }

            foreach ($deductions as $item) {

                $pdo->prepare("
                    UPDATE products
                    SET stock = stock - ?
                    WHERE id = ?
                ")->execute([
                    $item['qty'],
                    $item['id']
                ]);

                $pdo->prepare("
                    INSERT INTO inventory_logs
                    (product_id, user_id, change_qty, reason)
                    VALUES (?, ?, ?, ?)
                ")->execute([
                    $item['id'],
                    $userId,
                    -$item['qty'],
                    'Online Order Accepted - ' . $order['order_number']
                ]);
            }

            $pdo->prepare("
                UPDATE orders
                SET order_status = 'Preparing',
                    stock_deducted = 1
                WHERE id = ?
            ")->execute([$orderId]);

            flash('Order accepted! Stock deducted successfully.');
        }

        // READY FOR PICKUP
        elseif ($action === 'ready') {

            if (
                $order['order_status'] !== 'Preparing' ||
                (int)$order['stock_deducted'] !== 1
            ) {
                throw new RuntimeException('This order cannot be marked ready.');
            }

            $pdo->prepare("
                UPDATE orders
                SET order_status = 'Ready for Pickup'
                WHERE id = ?
            ")->execute([$orderId]);

            flash('Order is now Ready for Pickup.');
        }

        // COMPLETE ORDER AND RECORD IN SALES
        elseif ($action === 'complete') {

            if (
                $order['order_status'] !== 'Ready for Pickup' ||
                (int)$order['stock_deducted'] !== 1
            ) {
                throw new RuntimeException('This order is not ready for completion.');
            }

            // Cashier must select the actual payment method
            $paymentMethod = $_POST['payment_method'] ?? '';

            $allowedMethods = ['cash', 'gcash', 'bank'];

            if (!in_array($paymentMethod, $allowedMethods, true)) {
                throw new RuntimeException('Please select a valid payment method.');
            }

            // Check if this online order already has a sales record
            $checkSale = $pdo->prepare("
                SELECT id, payment_method
                FROM sales
                WHERE online_order_id = ?
                LIMIT 1
            ");
            $checkSale->execute([$orderId]);
            $existingSale = $checkSale->fetch();

            if ($existingSale) {

                // Do not create another sale
                $pdo->prepare("
                    UPDATE orders
                    SET order_status = 'Completed',
                        payment_status = 'Paid',
                        payment_method = ?
                    WHERE id = ?
                ")->execute([
                    $existingSale['payment_method'],
                    $orderId
                ]);

                flash('This order was already recorded in Sales. No duplicate sale was created.');

            } else {

                // Get order items and their current product costs
                $itemStmt = $pdo->prepare("
                    SELECT
                        oi.product_id,
                        oi.product_name,
                        oi.quantity,
                        oi.unit_price,
                        oi.subtotal,
                        p.cost
                    FROM order_items oi
                    INNER JOIN products p ON p.id = oi.product_id
                    WHERE oi.order_id = ?
                    ORDER BY oi.id ASC
                ");
                $itemStmt->execute([$orderId]);
                $items = $itemStmt->fetchAll();

                if (!$items) {
                    throw new RuntimeException('No valid products found for this order.');
                }

                $subtotal = 0;

                foreach ($items as $item) {
                    $subtotal += (float)$item['subtotal'];
                }

                $subtotal = round($subtotal, 2);
                $total = round((float)$order['total_amount'], 2);

                if (abs($subtotal - $total) > 0.01) {
                    throw new RuntimeException(
                        'Order total does not match its product items. Please check this order.'
                    );
                }

                // Generate receipt number
                $receipt = 'JB-' . date('ymd') . '-' .
                    strtoupper(bin2hex(random_bytes(3)));

                // Create sales record
                $saleStmt = $pdo->prepare("
                    INSERT INTO sales (
                        receipt_no,
                        customer_id,
                        user_id,
                        subtotal,
                        discount,
                        total,
                        amount_paid,
                        change_due,
                        payment_method,
                        status,
                        online_order_id
                    ) VALUES (?, ?, ?, ?, 0, ?, ?, 0, ?, 'paid', ?)
                ");

                $saleStmt->execute([
                    $receipt,
                    (int)$order['customer_id'],
                    $userId,
                    $subtotal,
                    $total,
                    $total,
                    $paymentMethod,
                    $orderId
                ]);

                $saleId = (int)$pdo->lastInsertId();

                // Create sale item records
                $saleItemStmt = $pdo->prepare("
                    INSERT INTO sale_items (
                        sale_id,
                        product_id,
                        product_name,
                        quantity,
                        unit_price,
                        unit_cost,
                        line_total
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ");

                foreach ($items as $item) {
                    $saleItemStmt->execute([
                        $saleId,
                        (int)$item['product_id'],
                        $item['product_name'],
                        (int)$item['quantity'],
                        (float)$item['unit_price'],
                        (float)$item['cost'],
                        (float)$item['subtotal']
                    ]);
                }

                // Do not deduct stock again.
                // Stock was already deducted when the order was accepted.

                $pdo->prepare("
                    UPDATE orders
                    SET order_status = 'Completed',
                        payment_status = 'Paid',
                        payment_method = ?
                    WHERE id = ?
                ")->execute([
                    $paymentMethod,
                    $orderId
                ]);

                flash(
                    'Order completed! Sales record created. Receipt: ' . $receipt
                );
            }
        }

        // CANCEL ORDER
        elseif ($action === 'cancel') {

            if (in_array($order['order_status'], ['Completed', 'Cancelled'], true)) {
                throw new RuntimeException('This order cannot be cancelled.');
            }

            if ((int)$order['stock_deducted'] === 1) {

                $stmt = $pdo->prepare("
                    SELECT product_id, SUM(quantity) AS total_qty
                    FROM order_items
                    WHERE order_id = ?
                    GROUP BY product_id
                ");
                $stmt->execute([$orderId]);
                $items = $stmt->fetchAll();

                $productStmt = $pdo->prepare("
                    SELECT id
                    FROM products
                    WHERE id = ?
                    FOR UPDATE
                ");

                foreach ($items as $item) {

                    $productId = (int)$item['product_id'];
                    $qty = (int)$item['total_qty'];

                    $productStmt->execute([$productId]);

                    if (!$productStmt->fetch()) {
                        throw new RuntimeException(
                            'Cannot restore stock because a product is missing.'
                        );
                    }

                    $pdo->prepare("
                        UPDATE products
                        SET stock = stock + ?
                        WHERE id = ?
                    ")->execute([$qty, $productId]);

                    $pdo->prepare("
                        INSERT INTO inventory_logs
                        (product_id, user_id, change_qty, reason)
                        VALUES (?, ?, ?, ?)
                    ")->execute([
                        $productId,
                        $userId,
                        $qty,
                        'Online Order Cancelled - ' . $order['order_number']
                    ]);
                }
            }

            $pdo->prepare("
                UPDATE orders
                SET order_status = 'Cancelled',
                    stock_deducted = 0
                WHERE id = ?
            ")->execute([$orderId]);

            flash('Order cancelled. Stock restored if it was previously deducted.');
        }

        else {
            throw new RuntimeException('Invalid action.');
        }

        $pdo->commit();

    } catch (Throwable $ex) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        flash($ex->getMessage(), 'error');
    }

    redirect('online_orders.php');
}

// GET ALL ORDERS
$orders = $pdo->query("
    SELECT
        id,
        order_number,
        customer_name,
        phone,
        address,
        pickup_date,
        pickup_time,
        pickup_branch,
        total_amount,
        order_status,
        payment_status,
        payment_method,
        stock_deducted,
        created_at
    FROM orders
    ORDER BY created_at DESC
")->fetchAll();

// PREPARE ORDER ITEMS QUERY
$itemStmt = $pdo->prepare("
    SELECT product_name, sku, quantity, unit_price, subtotal
    FROM order_items
    WHERE order_id = ?
    ORDER BY id ASC
");

$pendingCount = 0;

foreach ($orders as $order) {
    if ($order['order_status'] === 'Pending') {
        $pendingCount++;
    }
}

require __DIR__ . '/partials/header.php';
?>

<div class="page-intro">
    <div>
        <h1>Online Orders</h1>
        <p>Review, approve, and manage customer orders.</p>
    </div>

    <span class="pill utang">
        <?= $pendingCount ?> Pending Orders
    </span>
</div>

<section class="panel section-gap">

    <div class="panel-heading">
        <div>
            <h2>Customer Orders</h2>
            <p><?= count($orders) ?> total online orders</p>
        </div>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Order Details</th>
                    <th>Customer</th>
                    <th>Pickup Schedule</th>
                    <th>Branch</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Payment</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>

            <?php if (!$orders): ?>
                <tr>
                    <td colspan="8" class="empty">
                        No online orders found.
                    </td>
                </tr>
            <?php endif; ?>

            <?php foreach ($orders as $order): ?>

                <tr>
                    <td>
                        <b><?= e($order['order_number']) ?></b>

                        <small>
                            <?= date('M j, Y g:i A', strtotime($order['created_at'])) ?>
                        </small>

                        <details style="margin-top:8px;">
                            <summary style="cursor:pointer;color:#d62828;">
                                View Products
                            </summary>

                            <div style="padding:10px 0;min-width:180px;">

                                <?php
                                $itemStmt->execute([(int)$order['id']]);
                                $items = $itemStmt->fetchAll();
                                ?>

                                <?php foreach ($items as $item): ?>
                                    <div style="padding:7px 0;border-bottom:1px solid #eee;">
                                        <b><?= e($item['product_name']) ?></b>

                                        <small>
                                            <?= (int)$item['quantity'] ?> ×
                                            <?= money($item['unit_price']) ?>
                                        </small>

                                        <small>
                                            Subtotal: <?= money($item['subtotal']) ?>
                                        </small>
                                    </div>
                                <?php endforeach; ?>

                            </div>
                        </details>
                    </td>

                    <td>
                        <b><?= e($order['customer_name']) ?></b>
                        <small><?= e($order['phone']) ?></small>
                        <small><?= e($order['address'] ?: 'No address provided') ?></small>
                    </td>

                    <td>
                        <b><?= date('M j, Y', strtotime($order['pickup_date'])) ?></b>
                        <small>
                            <?= date('g:i A', strtotime($order['pickup_time'])) ?>
                        </small>
                    </td>

                    <td><?= e($order['pickup_branch']) ?></td>

                    <td>
                        <b><?= money($order['total_amount']) ?></b>
                    </td>

                    <td>
                        <span class="pill <?= $order['order_status'] === 'Pending' ? 'utang' : '' ?>">
                            <?= e($order['order_status']) ?>
                        </span>
                    </td>

                    <td>
                        <b><?= e($order['payment_status']) ?></b>
                        <small><?= e($order['payment_method']) ?></small>
                    </td>

                    <td style="min-width:170px;">

                        <?php if ($order['order_status'] === 'Pending'): ?>

                            <form method="post" style="margin-bottom:6px;">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
                                <input type="hidden" name="action" value="accept">

                                <button type="submit" class="btn primary full">
                                    Accept Order
                                </button>
                            </form>

                        <?php elseif ($order['order_status'] === 'Preparing'): ?>

                            <form method="post" style="margin-bottom:6px;">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
                                <input type="hidden" name="action" value="ready">

                                <button type="submit" class="btn primary full">
                                    Ready for Pickup
                                </button>
                            </form>

                        <?php elseif ($order['order_status'] === 'Ready for Pickup'): ?>

                            <form method="post" style="margin-bottom:6px;">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
                                <input type="hidden" name="action" value="complete">

                                <label style="display:block;margin-bottom:6px;">
                                    Payment received via:
                                </label>

                                <select name="payment_method" required
                                        style="width:100%;padding:9px;margin-bottom:7px;">
                                    <option value="">Select payment</option>
                                    <option value="cash">Cash</option>
                                    <option value="gcash">GCash</option>
                                    <option value="bank">Bank Transfer</option>
                                </select>

                                <button
                                    type="submit"
                                    class="btn primary full"
                                    onclick="return confirm('Confirm that the customer has paid and picked up this order?');"
                                >
                                    Confirm Payment & Complete
                                </button>
                            </form>

                        <?php endif; ?>

                        <?php if (!in_array($order['order_status'], ['Completed', 'Cancelled'], true)): ?>

                            <form method="post"
                                  onsubmit="return confirm('Are you sure you want to cancel this order?');">

                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
                                <input type="hidden" name="action" value="cancel">

                                <button type="submit"
                                        class="btn secondary full"
                                        style="border:1px solid #dc3545;color:#dc3545;">
                                    Cancel Order
                                </button>
                            </form>

                        <?php endif; ?>

                    </td>
                </tr>

            <?php endforeach; ?>

            </tbody>
        </table>
    </div>

</section>

<?php require __DIR__ . '/partials/footer.php'; ?>
