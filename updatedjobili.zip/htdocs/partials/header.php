
<?php
require_once __DIR__.'/../config.php';
require_login();

$pageTitle = $pageTitle ?? 'Dashboard';
$user = current_user();

// Count pending online orders
$pendingOnlineOrders = 0;

try {
    $pdo = db();
    $stmt = $pdo->query("SELECT COUNT(*) FROM orders WHERE order_status = 'Pending'");
    $pendingOnlineOrders = (int)$stmt->fetchColumn();
} catch (Throwable $e) {
    error_log('Online order notification error: ' . $e->getMessage());
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($pageTitle)?> · Jobili</title>
<link rel="stylesheet" href="assets/style.css?v=2">
<style>
.nav-count {
    background: #dc2626;
    color: white;
    border-radius: 20px;
    padding: 2px 8px;
    font-size: 11px;
    font-weight: bold;
    margin-left: auto;
}
</style>
</head>
<body>
<div class="app">

<aside class="sidebar">

<a class="brand" href="index.php">
    <span class="brand-mark small-mark">J</span>
    <span><b>Jobili</b><small>Store Manager</small></span>
</a>

<div class="side-label">WORKSPACE</div>

<nav>
    <a class="<?=basename($_SERVER['PHP_SELF'])==='index.php'?'active':''?>" href="index.php">
        ▦ <span>Dashboard</span>
    </a>

    <a href="pos.php" class="<?=basename($_SERVER['PHP_SELF'])==='pos.php'?'active':''?>">
        ▣ <span>POS Register</span>
    </a>

    <a href="products.php" class="<?=basename($_SERVER['PHP_SELF'])==='products.php'?'active':''?>">
        ▤ <span>Products & Inventory</span>
    </a>

    <a href="customers.php" class="<?=basename($_SERVER['PHP_SELF'])==='customers.php'?'active':''?>">
        ♙ <span>Customers & Utang</span>
    </a>

    <a href="expenses.php" class="<?=basename($_SERVER['PHP_SELF'])==='expenses.php'?'active':''?>">
        ₱ <span>Expenses</span>
    </a>

    <a href="reports.php" class="<?=basename($_SERVER['PHP_SELF'])==='reports.php'?'active':''?>">
        ▥ <span>Reports</span>
    </a>

    <!-- Online Orders - Cashier and Owner -->
    <a href="online_orders.php" class="<?=basename($_SERVER['PHP_SELF'])==='online_orders.php'?'active':''?>">
        🛒 <span>Online Orders</span>

        <?php if ($pendingOnlineOrders > 0): ?>
            <span class="nav-count">
                <?= $pendingOnlineOrders > 99 ? '99+' : $pendingOnlineOrders ?>
            </span>
        <?php endif; ?>
    </a>

    <?php if($user['role']==='owner'): ?>
        <a href="users.php" class="<?=basename($_SERVER['PHP_SELF'])==='users.php'?'active':''?>">
            ⚙ <span>Accounts</span>
        </a>
    <?php endif; ?>
</nav>

<div class="sidebar-bottom">

    <div class="profile">
        <div class="avatar"><?=e(strtoupper(substr($user['name'],0,1)))?></div>
        <div>
            <b><?=e($user['name'])?></b>
            <small><?=e(ucfirst($user['role']))?> · BSCS</small>
        </div>
    </div>

    <a class="logout" href="logout.php">↪ Sign out</a>

</div>
</aside>

<main class="main">

<header class="topbar">
    <div>
        <span class="mobile-brand">Jobili / </span>
        <b><?=e($pageTitle)?></b>
        <small class="status-dot">● Online</small>
    </div>

    <div class="top-actions">
        <span class="date"><?=date('D, M j, Y')?></span>
        <a class="btn primary compact" href="pos.php">＋ New Sale</a>
    </div>
</header>

<section class="content">

<?php if(!empty($_SESSION['flash'])): 
    $f = $_SESSION['flash'];
    unset($_SESSION['flash']);
?>
    <div class="alert <?=e($f[1])?>"><?=e($f[0])?></div>
<?php endif; ?>
