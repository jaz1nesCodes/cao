
<?php
require __DIR__.'/config.php';
require_login();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    try {
        $action = $_POST['action'] ?? '';

        // SAVE CUSTOMER
        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $address = trim($_POST['address'] ?? '');
            $notes = trim($_POST['notes'] ?? '');

            if (!$name) {
                throw new RuntimeException('Customer name is required.');
            }

            if ($id) {
                $pdo->prepare(
                    'UPDATE customers SET name=?,phone=?,address=?,notes=? WHERE id=?'
                )->execute([$name,$phone,$address,$notes,$id]);
            } else {
                $pdo->prepare(
                    'INSERT INTO customers(name,phone,address,notes) VALUES(?,?,?,?)'
                )->execute([$name,$phone,$address,$notes]);
            }

            flash('Customer saved.');
        }

        // PRODUCT-BASED UTANG WITH INITIAL PAYMENT
        elseif ($action === 'add_debt') {
            $customerId = (int)($_POST['customer_id'] ?? 0);
            $items = $_POST['items'] ?? [];
            $initialPayment = round((float)($_POST['initial_payment'] ?? 0), 2);

            if ($customerId < 1) {
                throw new RuntimeException('Pumili muna ng customer.');
            }

            if (!is_array($items)) {
                throw new RuntimeException('Invalid product selection.');
            }

            if ($initialPayment < 0) {
                throw new RuntimeException('Invalid initial payment.');
            }

            $pdo->beginTransaction();

            $st = $pdo->prepare(
                'SELECT id FROM customers WHERE id=? FOR UPDATE'
            );
            $st->execute([$customerId]);

            if (!$st->fetch()) {
                throw new RuntimeException('Customer not found.');
            }

            $receipt = 'JB-UTANG-'.date('ymdHis').'-'.strtoupper(bin2hex(random_bytes(2)));

            $subtotal = 0;
            $selectedProducts = [];

            foreach ($items as $productId => $item) {
                if (!is_array($item) || empty($item['selected'])) {
                    continue;
                }

                $productId = (int)$productId;
                $quantity = (int)($item['quantity'] ?? 0);

                if ($productId < 1 || $quantity < 1) {
                    throw new RuntimeException('Invalid product or quantity.');
                }

                $st = $pdo->prepare(
                    'SELECT id,name,price,cost,stock,active
                     FROM products WHERE id=? AND active=1 FOR UPDATE'
                );
                $st->execute([$productId]);
                $product = $st->fetch();

                if (!$product) {
                    throw new RuntimeException('May napiling product na hindi na active.');
                }

                if ((int)$product['stock'] < $quantity) {
                    throw new RuntimeException(
                        'Kulang ang stock ng '.$product['name'].
                        '. Available: '.$product['stock']
                    );
                }

                $price = (float)$product['price'];
                $cost = (float)$product['cost'];
                $lineTotal = round($price * $quantity, 2);

                $subtotal += $lineTotal;

                $selectedProducts[] = [
                    'id' => $productId,
                    'name' => $product['name'],
                    'quantity' => $quantity,
                    'price' => $price,
                    'cost' => $cost,
                    'line_total' => $lineTotal
                ];
            }

            if (!$selectedProducts) {
                throw new RuntimeException('Pumili ng kahit isang product.');
            }

            $subtotal = round($subtotal, 2);

            if ($initialPayment > $subtotal) {
                throw new RuntimeException(
                    'Ang initial payment ay hindi puwedeng mas mataas sa total.'
                );
            }

            $status = ($initialPayment >= $subtotal)
                ? 'paid'
                : 'utang';

            $pdo->prepare(
                "INSERT INTO sales(
                    receipt_no,customer_id,user_id,subtotal,discount,
                    total,amount_paid,change_due,payment_method,status
                ) VALUES(?,?,?,?,0,?,?,0,'utang',?)"
            )->execute([
                $receipt,
                $customerId,
                current_user()['id'],
                $subtotal,
                $subtotal,
                $initialPayment,
                $status
            ]);

            $saleId = (int)$pdo->lastInsertId();

            foreach ($selectedProducts as $product) {
                $pdo->prepare(
                    'INSERT INTO sale_items(
                        sale_id,product_id,product_name,quantity,
                        unit_price,unit_cost,line_total
                    ) VALUES(?,?,?,?,?,?,?)'
                )->execute([
                    $saleId,
                    $product['id'],
                    $product['name'],
                    $product['quantity'],
                    $product['price'],
                    $product['cost'],
                    $product['line_total']
                ]);

                $pdo->prepare(
                    'UPDATE products SET stock=stock-? WHERE id=?'
                )->execute([
                    $product['quantity'],
                    $product['id']
                ]);

                $pdo->prepare(
                    'INSERT INTO inventory_logs(product_id,user_id,change_qty,reason)
                     VALUES(?,?,?,?)'
                )->execute([
                    $product['id'],
                    current_user()['id'],
                    -$product['quantity'],
                    'Utang '.$receipt
                ]);
            }

            if ($initialPayment > 0) {
                $pdo->prepare(
                    'INSERT INTO debt_payments(sale_id,amount,user_id,notes)
                     VALUES(?,?,?,?)'
                )->execute([
                    $saleId,
                    $initialPayment,
                    current_user()['id'],
                    'Initial payment'
                ]);
            }

            $pdo->commit();

            flash(
                'Utang saved! Total: '.money($subtotal).
                ' | Initial payment: '.money($initialPayment).
                ' | Remaining: '.money($subtotal - $initialPayment)
            );
        }

        // DELETE CUSTOMER
        elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);

            $st = $pdo->prepare(
                'SELECT COUNT(*) FROM sales WHERE customer_id=?'
            );
            $st->execute([$id]);

            if ((int)$st->fetchColumn() > 0) {
                throw new RuntimeException(
                    'Hindi puwedeng i-delete ang customer na may sales/utang history.'
                );
            }

            $pdo->prepare(
                'DELETE FROM customers WHERE id=?'
            )->execute([$id]);

            flash('Customer deleted.');
        }

        // COLLECT DEBT PAYMENT
        elseif ($action === 'payment') {
            $saleId = (int)($_POST['sale_id'] ?? 0);
            $amount = round((float)($_POST['amount'] ?? 0), 2);

            if ($amount <= 0) {
                throw new RuntimeException('Payment must be greater than zero.');
            }

            $pdo->beginTransaction();

            $st = $pdo->prepare(
                "SELECT total,amount_paid,status
                 FROM sales
                 WHERE id=? AND status<>'void'
                 AND (status='utang' OR payment_method='utang')
                 AND total>amount_paid
                 FOR UPDATE"
            );

            $st->execute([$saleId]);
            $sale = $st->fetch();

            if (!$sale) {
                throw new RuntimeException('Utang sale not found.');
            }

            $balance = round(
                (float)$sale['total'] - (float)$sale['amount_paid'],
                2
            );

            if ($amount > $balance) {
                throw new RuntimeException(
                    'Payment exceeds the remaining balance of '.money($balance)
                );
            }

            $newPaid = round((float)$sale['amount_paid'] + $amount, 2);

            $status = $newPaid + 0.0001 >= (float)$sale['total']
                ? 'paid'
                : 'utang';

            $pdo->prepare(
                'UPDATE sales SET amount_paid=?,status=? WHERE id=?'
            )->execute([$newPaid,$status,$saleId]);

            $pdo->prepare(
                'INSERT INTO debt_payments(sale_id,amount,user_id,notes)
                 VALUES(?,?,?,?)'
            )->execute([
                $saleId,
                $amount,
                current_user()['id'],
                trim($_POST['notes'] ?? 'Payment')
            ]);

            $pdo->commit();

            flash('Utang payment recorded.');
        }

    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        flash($ex->getMessage(), 'error');
    }

    redirect('customers.php');
}

// LOAD CUSTOMERS
$customers = $pdo->query(
    "SELECT c.*,
    COALESCE((
        SELECT SUM(GREATEST(s.total-s.amount_paid,0))
        FROM sales s
        WHERE s.customer_id=c.id
        AND s.status<>'void'
        AND (s.status='utang' OR s.payment_method='utang')
        AND s.total>s.amount_paid
    ),0) balance
    FROM customers c ORDER BY c.name"
)->fetchAll();

// LOAD ACTIVE PRODUCTS
$products = $pdo->query(
    'SELECT id,name,sku,price,cost,stock
     FROM products WHERE active=1 ORDER BY name'
)->fetchAll();

// LOAD OUTSTANDING DEBTS
$debts = $pdo->query(
    "SELECT s.*,c.name customer
     FROM sales s
     JOIN customers c ON c.id=s.customer_id
     WHERE s.status<>'void'
     AND (s.status='utang' OR s.payment_method='utang')
     AND s.total>s.amount_paid
     ORDER BY s.created_at DESC"
)->fetchAll();

// LOAD SELECTED DEBT DETAILS
$viewDebt = null;
$debtItems = [];
$debtPayments = [];

if (isset($_GET['view_debt'])) {
    $viewId = (int)$_GET['view_debt'];

    $st = $pdo->prepare(
        "SELECT s.*,c.name customer,c.phone customer_phone,
                c.address customer_address,c.notes customer_notes,
                u.name cashier
         FROM sales s
         LEFT JOIN customers c ON c.id=s.customer_id
         LEFT JOIN users u ON u.id=s.user_id
         WHERE s.id=?
         AND s.status<>'void'
         AND (s.status='utang' OR s.payment_method='utang')"
    );
    $st->execute([$viewId]);
    $viewDebt = $st->fetch();

    if ($viewDebt) {
        $st = $pdo->prepare(
            'SELECT * FROM sale_items WHERE sale_id=? ORDER BY id'
        );
        $st->execute([$viewId]);
        $debtItems = $st->fetchAll();

        $st = $pdo->prepare(
            "SELECT dp.*,u.name collector
             FROM debt_payments dp
             LEFT JOIN users u ON u.id=dp.user_id
             WHERE dp.sale_id=?
             ORDER BY dp.paid_at ASC,dp.id ASC"
        );
        $st->execute([$viewId]);
        $debtPayments = $st->fetchAll();
    }
}

// TOTAL DEBT
$totalDebt = (float)$pdo->query(
    "SELECT COALESCE(SUM(GREATEST(total-amount_paid,0)),0)
     FROM sales
     WHERE status<>'void'
     AND (status='utang' OR payment_method='utang')
     AND total>amount_paid"
)->fetchColumn();

// EDIT CUSTOMER
$edit = null;

if (isset($_GET['edit'])) {
    $st = $pdo->prepare(
        'SELECT * FROM customers WHERE id=?'
    );
    $st->execute([(int)$_GET['edit']]);
    $edit = $st->fetch();
}

$pageTitle = 'Customers & Utang';
require __DIR__.'/partials/header.php';
?>

<div class="page-intro">
    <div>
        <h1>Customers & Utang</h1>
        <p>Keep customer records and collect outstanding balances.</p>
    </div>
    <span class="pill utang">
        Outstanding: <?=money($totalDebt)?>
    </span>
</div>

<?php if (isset($_GET['view_debt'])): ?>
<section class="panel section-gap">
    <?php if (!$viewDebt): ?>
        <div class="panel-heading">
            <div>
                <h2>Utang not found</h2>
                <p>Hindi makita ang transaction na ito.</p>
            </div>
            <a href="customers.php" class="btn secondary">Back</a>
        </div>
    <?php else:
        $remaining = max(0, (float)$viewDebt['total'] - (float)$viewDebt['amount_paid']);
    ?>
        <div class="panel-heading">
            <div>
                <h2>Utang Details</h2>
                <p>Complete transaction and payment information</p>
            </div>
            <a href="customers.php" class="btn secondary">← Back to Customers</a>
        </div>

        <div class="two-col">
            <div>
                <h3>Customer Information</h3>
                <p><b>Name:</b> <?=e($viewDebt['customer'] ?? '—')?></p>
                <p><b>Phone:</b> <?=e($viewDebt['customer_phone'] ?: '—')?></p>
                <p><b>Address:</b> <?=e($viewDebt['customer_address'] ?: '—')?></p>
                <p><b>Customer Notes:</b> <?=e($viewDebt['customer_notes'] ?: '—')?></p>
            </div>

            <div>
                <h3>Transaction Information</h3>
                <p><b>Receipt:</b> <?=e($viewDebt['receipt_no'])?></p>
                <p><b>Date:</b> <?=e(date('M j, Y h:i A', strtotime($viewDebt['created_at'])))?></p>
                <p><b>Cashier:</b> <?=e($viewDebt['cashier'] ?? '—')?></p>
                <p><b>Status:</b> <?=e(strtoupper($viewDebt['status']))?></p>
            </div>
        </div>

        <h3 style="margin-top:20px">Products Inutang</h3>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Line Total</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($debtItems as $it): ?>
                    <tr>
                        <td><?=e($it['product_name'])?></td>
                        <td><?=e($it['quantity'])?></td>
                        <td><?=money($it['unit_price'])?></td>
                        <td><?=money($it['line_total'])?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$debtItems): ?>
                    <tr><td colspan="4" class="empty">No product details found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="panel" style="padding:15px;margin-top:20px">
            <h3>Payment Summary</h3>
            <div class="receipt-totals">
                <div>
                    <span>Subtotal</span>
                    <b><?=money($viewDebt['subtotal'])?></b>
                </div>
                <div>
                    <span>Discount</span>
                    <b><?=money($viewDebt['discount'])?></b>
                </div>
                <div>
                    <span>Total Utang</span>
                    <b><?=money($viewDebt['total'])?></b>
                </div>
                <div>
                    <span>Total Amount Paid</span>
                    <b><?=money($viewDebt['amount_paid'])?></b>
                </div>
                <div class="grand-total">
                    <span>Remaining Balance</span>
                    <b><?=money($remaining)?></b>
                </div>
            </div>
        </div>

        <h3 style="margin-top:20px">Payment History</h3>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Amount Paid</th>
                        <th>Received By</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($debtPayments as $payment): ?>
                    <tr>
                        <td><?=e(date('M j, Y h:i A', strtotime($payment['paid_at'])))?></td>
                        <td><b><?=money($payment['amount'])?></b></td>
                        <td><?=e($payment['collector'] ?? '—')?></td>
                        <td><?=e($payment['notes'] ?: '—')?></td>
                    </tr>
                <?php endforeach; ?>

                <?php if (!$debtPayments): ?>
                    <tr>
                        <td colspan="4" class="empty">No payment history recorded.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div style="margin-top:18px">
            <a class="btn secondary" href="receipt.php?id=<?=$viewDebt['id']?>" target="_blank">
                View / Print Receipt
            </a>
        </div>
    <?php endif; ?>
</section>
<?php endif; ?>

<div class="two-col">

    <!-- CUSTOMER FORM -->
    <section class="panel">
        <div class="panel-heading">
            <div>
                <h2><?=$edit?'Edit customer':'Add customer'?></h2>
                <p>Customer contact details</p>
            </div>
        </div>

        <form method="post" class="form-stack">
            <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?=e($edit['id']??'')?>">

            <label>Full name *</label>
            <input name="name" required value="<?=e($edit['name']??'')?>">

            <label>Phone</label>
            <input name="phone" value="<?=e($edit['phone']??'')?>">

            <label>Address</label>
            <input name="address" value="<?=e($edit['address']??'')?>">

            <label>Notes</label>
            <textarea name="notes" rows="2"><?=e($edit['notes']??'')?></textarea>

            <button class="btn primary">Save customer</button>
        </form>
    </section>

    <!-- PRODUCT-BASED UTANG -->
    <section class="panel">
        <div class="panel-heading">
            <div>
                <h2>Record Product Utang</h2>
                <p>Pumili ng customer at products na inutang.</p>
            </div>
        </div>

        <form method="post" class="form-stack" id="debtForm">
            <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
            <input type="hidden" name="action" value="add_debt">

            <label>Customer *</label>
            <select name="customer_id" required>
                <option value="">Pumili ng customer</option>
                <?php foreach ($customers as $c): ?>
                    <option value="<?=e($c['id'])?>"><?=e($c['name'])?></option>
                <?php endforeach; ?>
            </select>

            <label>Select Products *</label>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Select</th>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($products as $p): ?>
                        <tr>
                            <td>
                                <input
                                    type="checkbox"
                                    name="items[<?=$p['id']?>][selected]"
                                    value="1"
                                    class="debt-check"
                                    data-price="<?=e($p['price'])?>"
                                    data-stock="<?=e($p['stock'])?>"
                                    <?=((int)$p['stock'] < 1)?'disabled':''?>
                                >
                            </td>
                            <td>
                                <b><?=e($p['name'])?></b>
                                <small><?=e($p['sku']??'')?></small>
                            </td>
                            <td><?=money($p['price'])?></td>
                            <td><?=e($p['stock'])?></td>
                            <td>
                                <input
                                    type="number"
                                    name="items[<?=$p['id']?>][quantity]"
                                    class="debt-qty"
                                    min="1"
                                    max="<?=max(1,(int)$p['stock'])?>"
                                    value="1"
                                    style="width:75px"
                                    <?=((int)$p['stock'] < 1)?'disabled':''?>
                                >
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <?php if (!$products): ?>
                        <tr>
                            <td colspan="5" class="empty">No active products available.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="panel" style="padding:15px">
                <h3>Payment Summary</h3>

                <div class="panel-heading">
                    <span>Total Utang</span>
                    <h2 id="debtTotal">₱0.00</h2>
                </div>

                <label>Initial Payment (₱)</label>
                <input
                    type="number"
                    name="initial_payment"
                    id="initialPayment"
                    min="0"
                    step="0.01"
                    value="0.00"
                >

                <div class="panel-heading">
                    <span>Remaining Balance</span>
                    <h2 id="remainingBalance">₱0.00</h2>
                </div>

                <small>
                    Ilagay ang halagang unang ibinayad ng customer.
                    Puwedeng zero kung walang initial payment.
                </small>
            </div>

            <button class="btn primary" type="submit"
                onclick="return confirm('I-save ang utang, initial payment, at ibawas ang stock?')">
                Save Product Utang
            </button>
        </form>
    </section>

    <!-- OUTSTANDING DEBTS -->
    <section class="panel">
        <div class="panel-heading">
            <div>
                <h2>Outstanding utang</h2>
                <p>Open balances by sale</p>
            </div>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Customer / receipt</th>
                        <th>Balance</th>
                        <th>Collect payment</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$debts): ?>
                    <tr>
                        <td colspan="4" class="empty">No outstanding utang.</td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($debts as $d):
                    $balance = round(
                        (float)$d['total'] - (float)$d['amount_paid'],
                        2
                    );
                ?>
                    <tr>
                        <td>
                            <b><?=e($d['customer'])?></b>
                            <small>
                                <?=e($d['receipt_no'])?> ·
                                <?=date('M j, Y',strtotime($d['created_at']))?>
                            </small>
                        </td>
                        <td><?=money($balance)?></td>
                        <td>
                            <form method="post" class="inline-form">
                                <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                                <input type="hidden" name="action" value="payment">
                                <input type="hidden" name="sale_id" value="<?=$d['id']?>">

                                <input
                                    type="number"
                                    name="amount"
                                    min=".01"
                                    max="<?=e($balance)?>"
                                    step=".01"
                                    placeholder="₱ amount"
                                    required
                                >

                                <button class="btn secondary compact">Collect</button>
                            </form>
                        </td>
                        <td>
                            <a class="btn secondary compact"
                               href="customers.php?view_debt=<?=$d['id']?>">
                                View Details
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<!-- CUSTOMER DIRECTORY -->
<section class="panel section-gap">
    <div class="panel-heading">
        <div>
            <h2>Customer directory</h2>
            <p><?=count($customers)?> customers</p>
        </div>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Outstanding balance</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$customers): ?>
                <tr>
                    <td colspan="5" class="empty">No customers added yet.</td>
                </tr>
            <?php endif; ?>

            <?php foreach ($customers as $c): ?>
                <tr>
                    <td><b><?=e($c['name'])?></b></td>
                    <td><?=e($c['phone']?:'—')?></td>
                    <td><?=e($c['address']?:'—')?></td>
                    <td><?=money($c['balance'])?></td>
                    <td>
                        <a href="customers.php?edit=<?=$c['id']?>">Edit</a>

                        <form method="post" style="display:inline"
                            onsubmit="return confirm('I-delete ang customer? Hindi ito papayagan kung may sales/utang history.')">

                            <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?=e($c['id'])?>">

                            <button class="btn secondary compact" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<script>
(function () {
    const checks = document.querySelectorAll('.debt-check');

    const totalDisplay = document.getElementById('debtTotal');
    const initialInput = document.getElementById('initialPayment');
    const remainingDisplay = document.getElementById('remainingBalance');

    function updateTotal() {
        let total = 0;

        checks.forEach(function (check) {
            if (!check.checked) return;

            const row = check.closest('tr');
            const qtyInput = row.querySelector('.debt-qty');

            const price = parseFloat(check.dataset.price) || 0;
            const qty = parseInt(qtyInput.value) || 0;
            const stock = parseInt(check.dataset.stock) || 0;

            if (qty > stock) {
                qtyInput.value = stock;
            }

            total += price * (parseInt(qtyInput.value) || 0);
        });

        total = Math.round(total * 100) / 100;

        let initial = parseFloat(initialInput.value) || 0;

        if (initial < 0) {
            initial = 0;
        }

        if (initial > total) {
            initialInput.setCustomValidity(
                'Ang initial payment ay hindi puwedeng mas mataas sa total.'
            );
        } else {
            initialInput.setCustomValidity('');
        }

        let remaining = Math.max(0, total - initial);
        remaining = Math.round(remaining * 100) / 100;

        totalDisplay.textContent = '₱' + total.toFixed(2);
        remainingDisplay.textContent = '₱' + remaining.toFixed(2);
    }

    checks.forEach(function (check) {
        check.addEventListener('change', updateTotal);
    });

    document.querySelectorAll('.debt-qty').forEach(function (input) {
        input.addEventListener('input', updateTotal);
    });

    initialInput.addEventListener('input', updateTotal);

    updateTotal();
})();
</script>

<?php require __DIR__.'/partials/footer.php'; ?>
