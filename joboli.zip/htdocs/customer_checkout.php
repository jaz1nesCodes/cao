
<?php
require_once __DIR__ . '/config.php';

date_default_timezone_set('Asia/Manila');

if (empty($_SESSION['customer'])) {
    redirect('customer_login.php');
}

$pdo = db();

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart']) || empty($_SESSION['cart'])) {
    redirect('customer_shop.php');
}

$errors = [];
$customerId = (int)($_SESSION['customer']['id'] ?? 0);

if ($customerId <= 0) {
    redirect('customer_login.php');
}

// Get latest customer information
$stmt = $pdo->prepare("
    SELECT id, name, phone, address
    FROM customers
    WHERE id = ?
    LIMIT 1
");
$stmt->execute([$customerId]);
$customer = $stmt->fetch();

if (!$customer) {
    redirect('customer_login.php');
}

$name = $customer['name'] ?? '';
$phone = $customer['phone'] ?? '';
$address = $customer['address'] ?? '';
$pickupDate = '';
$pickupTime = '';

$cartItems = [];
$cartTotal = 0;

// Get current cart products from database
$ids = array_filter(
    array_map('intval', array_keys($_SESSION['cart']))
);

if (!$ids) {
    redirect('customer_shop.php');
}

$placeholders = implode(',', array_fill(0, count($ids), '?'));

$stmt = $pdo->prepare("
    SELECT id, name, sku, price, stock, active
    FROM products
    WHERE id IN ($placeholders)
");
$stmt->execute(array_values($ids));
$products = $stmt->fetchAll();

foreach ($products as $product) {
    $id = (int)$product['id'];
    $quantity = (int)($_SESSION['cart'][$id] ?? 0);

    if ($quantity <= 0 || (int)$product['active'] !== 1) {
        continue;
    }

    $subtotal = round((float)$product['price'] * $quantity, 2);

    $product['quantity'] = $quantity;
    $product['subtotal'] = $subtotal;

    $cartItems[] = $product;
    $cartTotal += $subtotal;
}

if (!$cartItems) {
    redirect('customer_shop.php');
}

// Handle checkout submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $pickupDate = trim($_POST['pickup_date'] ?? '');
    $pickupTime = trim($_POST['pickup_time'] ?? '');

    if ($name === '') {
        $errors[] = 'Customer name is required.';
    }

    if ($phone === '') {
        $errors[] = 'Phone number is required.';
    }

    if (strlen($name) > 150 || strlen($phone) > 50 || strlen($address) > 255) {
        $errors[] = 'One or more customer details are too long.';
    }

    // Validate pickup date
    $dateObject = DateTime::createFromFormat(
        '!Y-m-d',
        $pickupDate,
        new DateTimeZone('Asia/Manila')
    );

    $dateErrors = DateTime::getLastErrors();

    if (
        !$dateObject ||
        $dateObject->format('Y-m-d') !== $pickupDate ||
        ($dateErrors !== false && ($dateErrors['warning_count'] > 0 || $dateErrors['error_count'] > 0))
    ) {
        $errors[] = 'Please select a valid pickup date.';
    } else {
        // Monday = 1, Sunday = 7
        $dayOfWeek = (int)$dateObject->format('N');

        if ($dayOfWeek >= 6) {
            $errors[] = 'Pickup is only available Monday to Friday.';
        }

        $today = new DateTime('today', new DateTimeZone('Asia/Manila'));

        if ($dateObject < $today) {
            $errors[] = 'Pickup date cannot be in the past.';
        }
    }

    // Validate pickup time
    $allowedTimes = [];

    for ($hour = 8; $hour <= 23; $hour++) {
        foreach ([0, 30] as $minute) {
            if ($hour === 23 && $minute === 30) {
                $allowedTimes[] = '23:30';
                continue;
            }

            if ($hour < 23) {
                $allowedTimes[] = sprintf('%02d:%02d', $hour, $minute);
            }
        }
    }

    if (!in_array($pickupTime, $allowedTimes, true)) {
        $errors[] = 'Please select a valid pickup time between 8:00 AM and 11:30 PM.';
    }

    // Make sure pickup is in the future
    if (!$errors) {
        $pickupDateTime = DateTime::createFromFormat(
            '!Y-m-d H:i',
            $pickupDate . ' ' . $pickupTime,
            new DateTimeZone('Asia/Manila')
        );

        $now = new DateTime('now', new DateTimeZone('Asia/Manila'));

        if (!$pickupDateTime || $pickupDateTime <= $now) {
            $errors[] = 'Pickup date and time must be in the future.';
        }
    }

    // Recheck products and stock before saving the order
    if (!$errors) {
        $currentCart = $_SESSION['cart'];
        $currentIds = array_filter(array_map('intval', array_keys($currentCart)));

        if (!$currentIds) {
            $errors[] = 'Your cart is empty.';
        } else {
            $currentPlaceholders = implode(',', array_fill(0, count($currentIds), '?'));

            $stmt = $pdo->prepare("
                SELECT id, name, sku, price, stock, active
                FROM products
                WHERE id IN ($currentPlaceholders)
            ");
            $stmt->execute(array_values($currentIds));
            $latestProducts = $stmt->fetchAll();

            $latestById = [];

            foreach ($latestProducts as $product) {
                $latestById[(int)$product['id']] = $product;
            }

            $cartItems = [];
            $cartTotal = 0;

            foreach ($currentCart as $id => $quantity) {
                $id = (int)$id;
                $quantity = (int)$quantity;

                if ($quantity <= 0 || !isset($latestById[$id])) {
                    $errors[] = 'A product in your cart is no longer available.';
                    continue;
                }

                $product = $latestById[$id];

                if ((int)$product['active'] !== 1) {
                    $errors[] = $product['name'] . ' is no longer available.';
                    continue;
                }

                if ($quantity > (int)$product['stock']) {
                    $errors[] = 'Not enough stock for ' . $product['name'] . '. Please update your cart.';
                    continue;
                }

                $subtotal = round((float)$product['price'] * $quantity, 2);

                $product['quantity'] = $quantity;
                $product['subtotal'] = $subtotal;

                $cartItems[] = $product;
                $cartTotal += $subtotal;
            }
        }
    }

    // Save order
    if (!$errors && $cartItems) {
        try {
            $pdo->beginTransaction();

            $orderNumber = 'JOB-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));

            $stmt = $pdo->prepare("
                INSERT INTO orders (
                    order_number,
                    customer_id,
                    customer_name,
                    phone,
                    address,
                    pickup_date,
                    pickup_time,
                    total_amount,
                    order_status,
                    payment_status,
                    payment_method
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending', 'Unpaid', 'Pay at Store')
            ");

            $stmt->execute([
                $orderNumber,
                $customerId,
                $name,
                $phone,
                $address,
                $pickupDate,
                $pickupTime . ':00',
                number_format($cartTotal, 2, '.', '')
            ]);

            $orderId = (int)$pdo->lastInsertId();

            $itemStmt = $pdo->prepare("
                INSERT INTO order_items (
                    order_id,
                    product_id,
                    product_name,
                    sku,
                    quantity,
                    unit_price,
                    subtotal
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            foreach ($cartItems as $item) {
                $itemStmt->execute([
                    $orderId,
                    (int)$item['id'],
                    $item['name'],
                    $item['sku'] ?? null,
                    (int)$item['quantity'],
                    number_format((float)$item['price'], 2, '.', ''),
                    number_format((float)$item['subtotal'], 2, '.', '')
                ]);
            }

            $pdo->commit();

            // Clear cart only after successful order creation
            $_SESSION['cart'] = [];

            $_SESSION['last_order'] = [
                'order_number' => $orderNumber,
                'total' => number_format($cartTotal, 2, '.', ''),
                'pickup_date' => $pickupDate,
                'pickup_time' => $pickupTime
            ];

            redirect('customer_checkout.php?success=1');

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('Checkout error: ' . $e->getMessage());
            $errors[] = 'Unable to place your order right now. Please try again.';
        }
    }
}

// Successful order confirmation
$completedOrder = null;

if (isset($_GET['success']) && !empty($_SESSION['last_order'])) {
    $completedOrder = $_SESSION['last_order'];
}

// Generate pickup time options
$timeOptions = [];

for ($hour = 8; $hour <= 23; $hour++) {
    foreach ([0, 30] as $minute) {
        if ($hour === 23 && $minute === 30) {
            $timeOptions[] = '23:30';
        } elseif ($hour < 23) {
            $timeOptions[] = sprintf('%02d:%02d', $hour, $minute);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Checkout - Jobili</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #f5f5f5;
    color: #222;
    font-family: Arial, sans-serif;
}

.navbar {
    background: white;
    padding: 18px 6%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
}

.logo {
    color: #d62828;
    font-size: 25px;
    font-weight: bold;
}

.navbar a {
    color: #d62828;
    text-decoration: none;
    font-weight: bold;
}

.container {
    width: 90%;
    max-width: 1000px;
    margin: 30px auto;
}

.checkout-grid {
    display: grid;
    grid-template-columns: 1fr 350px;
    gap: 22px;
    align-items: start;
}

.panel {
    background: white;
    padding: 24px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,.05);
    margin-bottom: 20px;
}

h1, h2 {
    margin-top: 0;
}

label {
    display: block;
    font-weight: bold;
    font-size: 14px;
    margin: 15px 0 7px;
}

input, select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 7px;
    font-size: 14px;
    font-family: Arial, sans-serif;
}

textarea {
    min-height: 80px;
    resize: vertical;
}

.btn {
    display: block;
    width: 100%;
    padding: 13px;
    background: #d62828;
    color: white;
    border: none;
    border-radius: 7px;
    font-weight: bold;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
    margin-top: 18px;
}

.btn:hover {
    background: #b71c1c;
}

.secondary {
    background: #eee;
    color: #333;
}

.secondary:hover {
    background: #ddd;
}

.error {
    background: #ffe5e5;
    color: #a00000;
    padding: 12px;
    border-radius: 7px;
    margin-bottom: 12px;
}

.order-item {
    display: flex;
    justify-content: space-between;
    gap: 12px;
    padding: 12px 0;
    border-bottom: 1px solid #eee;
    font-size: 14px;
}

.total {
    display: flex;
    justify-content: space-between;
    font-size: 19px;
    font-weight: bold;
    margin-top: 18px;
}

.payment-info {
    background: #f7f7f7;
    padding: 14px;
    border-radius: 7px;
    margin-top: 15px;
    font-size: 14px;
    line-height: 1.6;
}

.success-panel {
    max-width: 650px;
    margin: 50px auto;
    text-align: center;
}

.order-number {
    font-size: 23px;
    color: #d62828;
    font-weight: bold;
    margin: 20px 0;
}

@media(max-width: 800px) {
    .checkout-grid {
        grid-template-columns: 1fr;
    }
}

@media(max-width: 500px) {
    .navbar {
        padding: 16px 5%;
    }

    .container {
        width: 94%;
    }

    .panel {
        padding: 18px;
    }
}
</style>
</head>

<body>

<header class="navbar">
    <div class="logo">JOBILI</div>
    <a href="customer_shop.php">Back to Store</a>
</header>

<main class="container">

<?php if ($completedOrder): ?>

    <section class="panel success-panel">
        <h1>Order Placed Successfully!</h1>

        <p>Thank you for ordering from Jobili.</p>

        <div class="order-number">
            <?= e($completedOrder['order_number']) ?>
        </div>

        <p><strong>Pickup Date:</strong>
            <?= e($completedOrder['pickup_date']) ?>
        </p>

        <p><strong>Pickup Time:</strong>
            <?= e(date('g:i A', strtotime($completedOrder['pickup_time']))) ?>
        </p>

        <p><strong>Total:</strong>
            <?= money($completedOrder['total']) ?>
        </p>

        <p><strong>Order Status:</strong> Pending</p>
        <p><strong>Payment:</strong> Pay at Store (Unpaid)</p>

        <div class="payment-info">
            Please wait for the cashier to review your order.
            Bring your order number when you visit the store.
            Payment will be collected during pickup.
        </div>

        <a href="customer_shop.php" class="btn">Continue Shopping</a>
    </section>

<?php else: ?>

    <h1>Checkout</h1>
    <p>Please review your details and choose your pickup schedule.</p>

    <?php foreach ($errors as $error): ?>
        <div class="error"><?= e($error) ?></div>
    <?php endforeach; ?>

    <form method="POST">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

        <div class="checkout-grid">

            <section class="panel">
                <h2>Customer Information</h2>

                <label>Full Name</label>
                <input
                    type="text"
                    name="name"
                    maxlength="150"
                    value="<?= e($name) ?>"
                    required
                >

                <label>Phone Number</label>
                <input
                    type="text"
                    name="phone"
                    maxlength="50"
                    value="<?= e($phone) ?>"
                    required
                >

                <label>Address (Optional)</label>
                <textarea
                    name="address"
                    maxlength="255"
                ><?= e($address) ?></textarea>

                <h2 style="margin-top:30px;">Pickup Schedule</h2>

                <label>Pickup Date</label>
                <input
                    type="date"
                    name="pickup_date"
                    min="<?= e(date('Y-m-d')) ?>"
                    value="<?= e($pickupDate) ?>"
                    required
                >

                <label>Pickup Time</label>
                <select name="pickup_time" required>
                    <option value="">Select pickup time</option>

                    <?php foreach ($timeOptions as $time): ?>
                        <option
                            value="<?= e($time) ?>"
                            <?= $pickupTime === $time ? 'selected' : '' ?>
                        >
                            <?= e(date('g:i A', strtotime($time))) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <div class="payment-info">
                    <strong>Store Pickup Schedule</strong><br>
                    Monday to Friday<br>
                    8:00 AM – 11:30 PM<br>
                    Saturday and Sunday: Closed
                </div>

                <h2 style="margin-top:30px;">Payment Method</h2>

                <div class="payment-info">
                    <strong>Pay at Store</strong><br>
                    You will pay the cashier when you pick up your order.
                    Your payment status will remain Unpaid until payment is received.
                </div>

                <button type="submit" class="btn">
                    Place Order
                </button>

                <a href="customer_shop.php" class="btn secondary">
                    Back to Cart
                </a>
            </section>

            <aside class="panel">
                <h2>Order Summary</h2>

                <?php foreach ($cartItems as $item): ?>
                    <div class="order-item">
                        <div>
                            <strong><?= e($item['name']) ?></strong><br>
                            <?= (int)$item['quantity'] ?> ×
                            <?= money($item['price']) ?>
                        </div>

                        <strong><?= money($item['subtotal']) ?></strong>
                    </div>
                <?php endforeach; ?>

                <div class="total">
                    <span>Total</span>
                    <span><?= money($cartTotal) ?></span>
                </div>

                <div class="payment-info">
                    Your order will first be submitted as Pending.
                    Product stock will only be deducted after the cashier accepts the order.
                </div>
            </aside>

        </div>
    </form>

<?php endif; ?>

</main>

</body>
</html>
