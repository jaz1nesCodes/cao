
<?php
require_once __DIR__ . '/config.php';

$error = '';
$success = '';

if (!empty($_SESSION['flash'])) {
    [$success, $flashType] = $_SESSION['flash'];
    unset($_SESSION['flash']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $error = 'Please enter your email and password.';
    } else {
        try {
            $pdo = db();

            $stmt = $pdo->prepare("
                SELECT
                    ca.id,
                    ca.customer_id,
                    ca.email,
                    ca.password_hash,
                    c.name
                FROM customer_accounts ca
                INNER JOIN customers c
                    ON c.id = ca.customer_id
                WHERE ca.email = ?
                LIMIT 1
            ");

            $stmt->execute([$email]);
            $customer = $stmt->fetch();

            if ($customer && password_verify($password, $customer['password_hash'])) {

                session_regenerate_id(true);

                $_SESSION['customer'] = [
                    'account_id' => (int)$customer['id'],
                    'id' => (int)$customer['customer_id'],
                    'name' => $customer['name'],
                    'email' => $customer['email']
                ];

                redirect('customer_shop.php');

            } else {
                $error = 'Incorrect email or password.';
            }

        } catch (PDOException $e) {
            error_log($e->getMessage());
            $error = 'Unable to log in right now. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Customer Login | Jobili</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 25px;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f5f5f5;
            font-family: Arial, sans-serif;
        }

        .login-card {
            width: 100%;
            max-width: 420px;
            padding: 30px;
            background: white;
            border-radius: 14px;
            box-shadow: 0 5px 25px rgba(0,0,0,.08);
        }

        h2 {
            margin-top: 0;
            color: #d62828;
            text-align: center;
        }

        .subtitle {
            text-align: center;
            color: #777;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin: 15px 0 6px;
            font-weight: bold;
            font-size: 14px;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 7px;
            font-size: 14px;
        }

        input:focus {
            outline: none;
            border-color: #d62828;
        }

        button {
            width: 100%;
            margin-top: 22px;
            padding: 13px;
            border: none;
            border-radius: 7px;
            background: #d62828;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #b71c1c;
        }

        .error, .success {
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 7px;
            font-size: 14px;
        }

        .error {
            background: #ffe5e5;
            color: #a00000;
        }

        .success {
            background: #e5ffe9;
            color: #176b2c;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }

        a {
            color: #d62828;
            text-decoration: none;
        }
    </style>
</head>

<body>

<div class="login-card">

    <h2>Jobili</h2>
    <p class="subtitle">Customer Login</p>

    <?php if ($success): ?>
        <div class="success"><?= e($success) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST">

        <input type="hidden" name="csrf"
               value="<?= e(csrf_token()) ?>">

        <label>Email Address</label>
        <input type="email"
               name="email"
               maxlength="190"
               required>

        <label>Password</label>
        <input type="password"
               name="password"
               required>

        <button type="submit">Log In</button>

    </form>

    <div class="footer">
        Don't have an account?
        <a href="customer_register.php">Register here</a>
    </div>

</div>

</body>
</html>
