
<?php
require_once __DIR__ . '/config.php';

$errors = [];
$name = '';
$phone = '';
$address = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validate inputs
    if ($name === '' || strlen($name) > 150) {
        $errors[] = 'Please enter a valid name (maximum 150 characters).';
    }

    if ($phone === '' || strlen($phone) > 50) {
        $errors[] = 'Please enter a valid phone number.';
    }

    if (strlen($address) > 255) {
        $errors[] = 'Address must not exceed 255 characters.';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
        $errors[] = 'Please enter a valid email address.';
    }

    if (strlen($password) < 8) {
        $errors[] = 'Password must contain at least 8 characters.';
    }

    if ($password !== $confirm_password) {
        $errors[] = 'Passwords do not match.';
    }

    if (empty($errors)) {
        try {
            $pdo = db();

            // Check if email is already registered
            $check = $pdo->prepare(
                "SELECT id FROM customer_accounts WHERE email = ?"
            );
            $check->execute([$email]);

            if ($check->fetch()) {
                $errors[] = 'This email is already registered.';
            } else {
                // Create customer profile
                $stmt = $pdo->prepare(
                    "INSERT INTO customers (name, phone, address)
                     VALUES (?, ?, ?)"
                );

                $stmt->execute([$name, $phone, $address]);

                $customerId = (int)$pdo->lastInsertId();

                try {
                    // Securely hash the password
                    $passwordHash = password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                    // Create customer login account
                    $stmt = $pdo->prepare(
                        "INSERT INTO customer_accounts
                         (customer_id, email, password_hash)
                         VALUES (?, ?, ?)"
                    );

                    $stmt->execute([
                        $customerId,
                        $email,
                        $passwordHash
                    ]);

                    flash('Registration successful! You can now log in.');
                    redirect('customer_login.php');

                } catch (PDOException $accountError) {
                    // Remove the profile if account creation fails
                    $delete = $pdo->prepare(
                        "DELETE FROM customers WHERE id = ?"
                    );
                    $delete->execute([$customerId]);

                    throw $accountError;
                }
            }

        } catch (PDOException $e) {
            error_log($e->getMessage());
            $errors[] = 'Registration failed. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Registration | Jobili</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 25px;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f5f5f5;
            font-family: Arial, sans-serif;
        }

        .register-card {
            width: 100%;
            max-width: 450px;
            padding: 30px;
            background: white;
            border-radius: 14px;
            box-shadow: 0 5px 25px rgba(0,0,0,.08);
        }

        h2 {
            margin-top: 0;
            color: #d62828;
            text-align: center;
        }

        .subtitle {
            text-align: center;
            color: #777;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin: 14px 0 6px;
            font-weight: bold;
            font-size: 14px;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 7px;
            font-size: 14px;
        }

        input:focus {
            outline: none;
            border-color: #d62828;
        }

        button {
            width: 100%;
            margin-top: 22px;
            padding: 13px;
            border: none;
            border-radius: 7px;
            background: #d62828;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #b71c1c;
        }

        .error {
            padding: 12px;
            margin-bottom: 15px;
            background: #ffe5e5;
            color: #a00000;
            border-radius: 7px;
            font-size: 14px;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }

        a {
            color: #d62828;
            text-decoration: none;
        }
    </style>
</head>

<body>

<div class="register-card">

    <h2>Jobili</h2>
    <p class="subtitle">Create your customer account</p>

    <?php foreach ($errors as $error): ?>
        <div class="error"><?= e($error) ?></div>
    <?php endforeach; ?>

    <form method="POST">

        <input type="hidden" name="csrf"
               value="<?= e(csrf_token()) ?>">

        <label>Full Name</label>
        <input type="text" name="name"
               maxlength="150"
               value="<?= e($name) ?>" required>

        <label>Phone Number</label>
        <input type="tel" name="phone"
               maxlength="50"
               value="<?= e($phone) ?>" required>

        <label>Address</label>
        <input type="text" name="address"
               maxlength="255"
               value="<?= e($address) ?>" required>

        <label>Email Address</label>
        <input type="email" name="email"
               maxlength="190"
               value="<?= e($email) ?>" required>

        <label>Password</label>
        <input type="password" name="password"
               minlength="8" required>

        <label>Confirm Password</label>
        <input type="password" name="confirm_password"
               minlength="8" required>

        <button type="submit">Create Account</button>

    </form>

    <div class="footer">
        Already have an account?
        <a href="customer_login.php">Log in</a>
    </div>

</div>

</body>
</html>
