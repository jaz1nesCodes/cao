<?php
require __DIR__.'/config.php'; require_login(); $pdo=db();
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf(); $action=$_POST['action']??'';
 try{
 if($action==='save'){
    $imageName = null;

    if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Image upload failed.');
        }

        if ($_FILES['image']['size'] > 2 * 1024 * 1024) {
            throw new RuntimeException('Image must not exceed 2MB.');
        }

        $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
        $imageInfo = getimagesize($_FILES['image']['tmp_name']);

        if (!$imageInfo || !in_array($imageInfo['mime'], $allowedTypes, true)) {
            throw new RuntimeException('Only JPG, PNG, and WEBP images are allowed.');
        }

        $extension = match ($imageInfo['mime']) {
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp'
        };

        $imageName = bin2hex(random_bytes(16)) . '.' . $extension;
        $uploadPath = __DIR__ . '/uploads/products/' . $imageName;

        if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
            throw new RuntimeException('Could not save uploaded image.');
        }
    } $id=(int)($_POST['id']??0);$name=trim($_POST['name']??'');$sku=trim($_POST['sku']??'')?:null;$cat=(int)($_POST['category_id']??0)?:null;$price=(float)($_POST['price']??0);$cost=(float)($_POST['cost']??0);$stock=(int)($_POST['stock']??0);$reorder=(int)($_POST['reorder_level']??5);if($name===''||$price<0||$cost<0||$stock<0)throw new RuntimeException('Enter valid product details.');if($id){
    if($imageName){
        $st=$pdo->prepare('UPDATE products SET sku=?,name=?,category_id=?,price=?,cost=?,stock=?,reorder_level=?,image=? WHERE id=?');
        $st->execute([$sku,$name,$cat,$price,$cost,$stock,$reorder,$imageName,$id]);
    } else {
        $st=$pdo->prepare('UPDATE products SET sku=?,name=?,category_id=?,price=?,cost=?,stock=?,reorder_level=? WHERE id=?');
        $st->execute([$sku,$name,$cat,$price,$cost,$stock,$reorder,$id]);
    }
}else{
    $st=$pdo->prepare('INSERT INTO products(sku,name,category_id,price,cost,stock,reorder_level,image) VALUES(?,?,?,?,?,?,?,?)');
    $st->execute([$sku,$name,$cat,$price,$cost,$stock,$reorder,$imageName]);
    $id=(int)$pdo->lastInsertId();
}flash('Product saved.');}
 elseif($action==='adjust'){ $id=(int)$_POST['id'];$change=(int)$_POST['change_qty'];$reason=trim($_POST['reason']??'Stock adjustment');$pdo->beginTransaction();$st=$pdo->prepare('SELECT stock FROM products WHERE id=? FOR UPDATE');$st->execute([$id]);$p=$st->fetch();if(!$p||$p['stock']+$change<0)throw new RuntimeException('Product not found or stock cannot become negative.');$pdo->prepare('UPDATE products SET stock=stock+? WHERE id=?')->execute([$change,$id]);$pdo->prepare('INSERT INTO inventory_logs(product_id,user_id,change_qty,reason) VALUES(?,?,?,?)')->execute([$id,current_user()['id'],$change,$reason]);$pdo->commit();flash('Stock updated.');}
 elseif($action==='archive'){require_owner();$pdo->prepare('UPDATE products SET active=0 WHERE id=?')->execute([(int)$_POST['id']]);flash('Product archived.');}
 }catch(Throwable $ex){if($pdo->inTransaction())$pdo->rollBack();flash($ex->getMessage(),'error');}redirect('products.php');}
$edit=null;if(isset($_GET['edit'])){$st=$pdo->prepare('SELECT * FROM products WHERE id=?');$st->execute([(int)$_GET['edit']]);$edit=$st->fetch();}
$categories=$pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();$q=trim($_GET['q']??'');$sql="SELECT p.*,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=1";$args=[];if($q!==''){$sql.=" AND (p.name LIKE ? OR p.sku LIKE ?)";$args=["%$q%","%$q%"];}$sql.=' ORDER BY p.name';$st=$pdo->prepare($sql);$st->execute($args);$products=$st->fetchAll();
$pageTitle='Products & Inventory';require __DIR__.'/partials/header.php';?>
<div class="page-intro"><div><h1>Products & Inventory</h1><p>Manage prices, stock levels, and product details.</p></div><button class="btn primary" onclick="document.getElementById('product-form').scrollIntoView({behavior:'smooth'})">＋ Add product</button></div>
<div class="two-col"><section class="panel"><div class="panel-heading"><div><h2><?= $edit?'Edit product':'Add a product' ?></h2><p>Fields marked * are required.</p></div></div><form id="product-form" method="post" enctype="multipart/form-data" class="form-grid"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=e($edit['id']??'')?>"><div class="field full-field"><label>Product name *</label><input name="name" required value="<?=e($edit['name']??'')?>"></div><div class="field"><label>SKU / Barcode</label><input name="sku" value="<?=e($edit['sku']??'')?>"></div>
    <div class="field full-field">
    <label>Product Image</label>
    <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
    <small>JPG, PNG, or WEBP. Maximum 2MB.</small>
</div><div class="field"><label>Category</label><select name="category_id"><option value="">Uncategorized</option><?php foreach($categories as $c):?><option value="<?=$c['id']?>" <?=isset($edit['category_id'])&&(int)$edit['category_id']===$c['id']?'selected':''?>><?=e($c['name'])?></option><?php endforeach;?></select></div><div class="field"><label>Selling price (₱) *</label><input type="number" step=".01" min="0" name="price" required value="<?=e($edit['price']??'0')?>"></div><div class="field"><label>Unit cost (₱)</label><input type="number" step=".01" min="0" name="cost" value="<?=e($edit['cost']??'0')?>"></div><div class="field"><label>Stock quantity *</label><input type="number" min="0" name="stock" required value="<?=e($edit['stock']??'0')?>"></div><div class="field"><label>Low-stock threshold</label><input type="number" min="0" name="reorder_level" value="<?=e($edit['reorder_level']??'5')?>"></div><div class="form-actions full-field"><button class="btn primary">Save product</button><?php if($edit):?><a class="btn secondary" href="products.php">Cancel</a><?php endif;?></div></form></section>
<section class="panel"><div class="panel-heading"><div><h2>Inventory adjustment</h2><p>Record deliveries, corrections, or damaged goods.</p></div></div><form method="post" class="form-stack"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="adjust"><label>Product</label><select name="id" required><?php foreach($products as $p):?><option value="<?=$p['id']?>"><?=e($p['name'])?> (stock: <?=$p['stock']?>)</option><?php endforeach;?></select><label>Quantity change</label><input type="number" name="change_qty" required placeholder="e.g. 20 to add, -2 to remove"><label>Reason</label><input name="reason" required value="Stock adjustment"><button class="btn secondary">Update stock</button></form><p class="hint">Stock adjustments are saved to the inventory log.</p></section></div>
<section class="panel section-gap"><div class="panel-heading"><div><h2>Product list</h2><p><?=count($products)?> active products</p></div><form class="search-form"><input name="q" value="<?=e($q)?>" placeholder="Search name or SKU"><button class="btn secondary">Search</button></form></div><div class="table-wrap"><table><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Cost</th><th>Stock</th><th>Stock status</th><th>Actions</th></tr></thead><tbody><?php if(!$products):?><tr><td colspan="7" class="empty">No products found. Add your first product above.</td></tr><?php endif;foreach($products as $p):?><tr><td><b><?=e($p['name'])?></b><small><?=e($p['sku']?:'No SKU')?></small></td><td><?=e($p['category']??'—')?></td><td><?=money($p['price'])?></td><td><?=money($p['cost'])?></td><td><?=e($p['stock'])?></td><td><span class="pill <?=$p['stock']<=$p['reorder_level']?'utang':'paid'?>"><?=$p['stock']<=$p['reorder_level']?'Low stock':'In stock'?></span></td><td class="actions"><a href="products.php?edit=<?=$p['id']?>">Edit</a><?php if(current_user()['role']==='owner'):?><form method="post" onsubmit="return confirm('Archive this product?')"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="archive"><input type="hidden" name="id" value="<?=$p['id']?>"><button class="link-danger">Archive</button></form><?php endif;?></td></tr><?php endforeach;?></tbody></table></div></section>
<?php require __DIR__.'/partials/footer.php';?>