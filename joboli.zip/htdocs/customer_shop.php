
<?php
require_once __DIR__ . '/config.php';

// Customer login protection
if (empty($_SESSION['customer'])) {
    redirect('customer_login.php');
}

$pdo = db();

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$errors = [];
$success = '';

// Handle cart actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $action = $_POST['action'] ?? '';
    $productId = (int)($_POST['product_id'] ?? 0);

    try {
        if ($action === 'add') {
            $stmt = $pdo->prepare("
                SELECT id, name, stock, active
                FROM products
                WHERE id = ?
                LIMIT 1
            ");
            $stmt->execute([$productId]);
            $product = $stmt->fetch();

            if (!$product || (int)$product['active'] !== 1) {
                throw new RuntimeException('Product is unavailable.');
            }

            $currentQty = (int)($_SESSION['cart'][$productId] ?? 0);

            if ((int)$product['stock'] <= 0) {
                throw new RuntimeException('This product is out of stock.');
            }

            if ($currentQty + 1 > (int)$product['stock']) {
                throw new RuntimeException('You have reached the available stock limit.');
            }

            $_SESSION['cart'][$productId] = $currentQty + 1;
            $success = 'Product added to your cart.';

        } elseif ($action === 'update') {
            $quantity = (int)($_POST['quantity'] ?? 0);

            if ($quantity <= 0) {
                unset($_SESSION['cart'][$productId]);
            } else {
                $stmt = $pdo->prepare("
                    SELECT stock, active
                    FROM products
                    WHERE id = ?
                    LIMIT 1
                ");
                $stmt->execute([$productId]);
                $product = $stmt->fetch();

                if (!$product || (int)$product['active'] !== 1) {
                    throw new RuntimeException('Product is unavailable.');
                }

                if ($quantity > (int)$product['stock']) {
                    throw new RuntimeException('Quantity exceeds available stock.');
                }

                $_SESSION['cart'][$productId] = $quantity;
            }

        } elseif ($action === 'remove') {
            unset($_SESSION['cart'][$productId]);
        }

    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

// Search and category filter
$q = trim($_GET['q'] ?? '');
$categoryId = (int)($_GET['category'] ?? 0);

// Get categories
$categories = $pdo->query("
    SELECT id, name
    FROM categories
    ORDER BY name
")->fetchAll();

// Get active products
$sql = "
    SELECT p.*, c.name AS category_name
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    WHERE p.active = 1
";

$params = [];

if ($q !== '') {
    $sql .= " AND (p.name LIKE ? OR p.sku LIKE ?)";
    $params[] = "%$q%";
    $params[] = "%$q%";
}

if ($categoryId > 0) {
    $sql .= " AND p.category_id = ?";
    $params[] = $categoryId;
}

$sql .= " ORDER BY p.name";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

// Get current cart products
$cartItems = [];
$cartTotal = 0;
$cartCount = 0;

if (!empty($_SESSION['cart'])) {
    $ids = array_map('intval', array_keys($_SESSION['cart']));
    $ids = array_filter($ids);

    if ($ids) {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        $stmt = $pdo->prepare("
            SELECT id, name, price, stock, active
            FROM products
            WHERE id IN ($placeholders)
        ");

        $stmt->execute(array_values($ids));
        $cartProducts = $stmt->fetchAll();

        foreach ($cartProducts as $item) {
            $id = (int)$item['id'];
            $quantity = (int)($_SESSION['cart'][$id] ?? 0);

            if ($quantity <= 0 || (int)$item['active'] !== 1) {
                unset($_SESSION['cart'][$id]);
                continue;
            }

            $subtotal = (float)$item['price'] * $quantity;

            $item['quantity'] = $quantity;
            $item['subtotal'] = $subtotal;

            $cartItems[] = $item;
            $cartTotal += $subtotal;
            $cartCount += $quantity;
        }
    }
}

$customerName = $_SESSION['customer']['name'] ?? 'Customer';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Jobili Online Store</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #f5f5f5;
    color: #222;
    font-family: Arial, sans-serif;
}

.navbar {
    background: white;
    padding: 18px 6%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
    gap: 15px;
    flex-wrap: wrap;
}

.logo {
    color: #d62828;
    font-size: 25px;
    font-weight: bold;
}

.nav-right {
    display: flex;
    align-items: center;
    gap: 20px;
    font-size: 14px;
}

.nav-right a {
    color: #d62828;
    text-decoration: none;
    font-weight: bold;
}

.container {
    width: 90%;
    max-width: 1250px;
    margin: 30px auto;
}

.welcome {
    margin-bottom: 25px;
}

.welcome h1 {
    margin-bottom: 5px;
}

.welcome p {
    color: #777;
}

.search-bar {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}

input, select {
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 7px;
    font-size: 14px;
}

.search-bar input {
    flex: 1;
    min-width: 0;
}

button {
    cursor: pointer;
}

.btn {
    padding: 11px 17px;
    border: none;
    border-radius: 7px;
    background: #d62828;
    color: white;
    font-weight: bold;
}

.btn:hover {
    background: #b71c1c;
}

.message {
    padding: 12px;
    margin-bottom: 15px;
    border-radius: 7px;
    background: #e5ffe9;
    color: #176b2c;
}

.error {
    padding: 12px;
    margin-bottom: 15px;
    border-radius: 7px;
    background: #ffe5e5;
    color: #a00000;
}

.content {
    display: grid;
    grid-template-columns: 1fr 320px;
    gap: 25px;
    align-items: start;
}

.products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(190px, 1fr));
    gap: 18px;
}

.product-card {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 3px 12px rgba(0,0,0,.05);
}

.product-image {
    width: 100%;
    height: 170px;
    object-fit: contain;
    background: #fafafa;
    padding: 12px;
}

.no-image {
    height: 170px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #999;
    background: #eee;
}

.product-info {
    padding: 15px;
}

.product-info h3 {
    margin: 0 0 8px;
    font-size: 16px;
}

.category {
    color: #888;
    font-size: 12px;
}

.price {
    color: #d62828;
    font-weight: bold;
    font-size: 19px;
    margin: 12px 0 5px;
}

.stock {
    color: #777;
    font-size: 12px;
    margin-bottom: 12px;
}

.product-info form button {
    width: 100%;
}

.cart-panel {
    background: white;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 3px 12px rgba(0,0,0,.05);
}

.cart-panel h2 {
    margin-top: 0;
}

.cart-item {
    padding: 12px 0;
    border-bottom: 1px solid #eee;
    font-size: 14px;
}

.cart-item form {
    display: flex;
    gap: 7px;
    margin-top: 8px;
}

.cart-item input {
    width: 65px;
    padding: 7px;
}

.cart-item button {
    padding: 7px 10px;
    border: none;
    border-radius: 5px;
    background: #eee;
}

.cart-item .remove {
    background: #ffe5e5;
    color: #b71c1c;
}

.cart-total {
    display: flex;
    justify-content: space-between;
    font-weight: bold;
    margin-top: 18px;
    font-size: 17px;
}
    .checkout-btn {
    display: block;
    width: 100%;
    margin-top: 18px;
    text-align: center;
    text-decoration: none;
    padding: 13px;
}

.empty {
    color: #888;
    text-align: center;
    padding: 25px 10px;
}

@media(max-width: 850px) {
    .content {
        grid-template-columns: 1fr;
    }
}

@media(max-width: 500px) {
    .search-bar {
        flex-wrap: wrap;
    }

    .search-bar input,
    .search-bar select {
        width: 100%;
    }

    .products-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
    }

    .product-image,
    .no-image {
        height: 130px;
    }

    .product-info {
        padding: 11px;
    }
}
</style>
</head>

<body>

<header class="navbar">
    <div class="logo">JOBILI</div>

    <div class="nav-right">
        <span>Hello, <?= e($customerName) ?>!</span>
        <span>Cart (<?= $cartCount ?>)</span>
        <a href="customer_logout.php">Logout</a>
    </div>
</header>

<main class="container">

    <div class="welcome">
        <h1>Online Store</h1>
        <p>Browse our products and add your favorites to your cart.</p>
    </div>

    <?php if ($success): ?>
        <div class="message"><?= e($success) ?></div>
    <?php endif; ?>

    <?php foreach ($errors as $error): ?>
        <div class="error"><?= e($error) ?></div>
    <?php endforeach; ?>

    <form method="GET" class="search-bar">

        <input
            type="text"
            name="q"
            placeholder="Search products..."
            value="<?= e($q) ?>"
        >

        <select name="category">
            <option value="0">All Categories</option>

            <?php foreach ($categories as $category): ?>
                <option
                    value="<?= (int)$category['id'] ?>"
                    <?= $categoryId === (int)$category['id'] ? 'selected' : '' ?>
                >
                    <?= e($category['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button class="btn" type="submit">Search</button>

    </form>

    <div class="content">

        <section>
            <div class="products-grid">

                <?php if (!$products): ?>
                    <div class="empty">No products found.</div>
                <?php endif; ?>

                <?php foreach ($products as $product): ?>

                    <article class="product-card">

                        <?php
                        $imageFile = basename((string)($product['image'] ?? ''));
                        $imagePath = 'uploads/products/' . rawurlencode($imageFile);
                        $imageExists = $imageFile !== ''
                            && is_file(__DIR__ . '/uploads/products/' . $imageFile);
                        ?>

                        <?php if ($imageExists): ?>
                            <img
                                class="product-image"
                                src="<?= e($imagePath) ?>"
                                alt="<?= e($product['name']) ?>"
                            >
                        <?php else: ?>
                            <div class="no-image">No image available</div>
                        <?php endif; ?>

                        <div class="product-info">

                            <h3><?= e($product['name']) ?></h3>

                            <div class="category">
                                <?= e($product['category_name'] ?? 'Uncategorized') ?>
                            </div>

                            <div class="price">
                                <?= money($product['price']) ?>
                            </div>

                            <div class="stock">
                                <?php if ((int)$product['stock'] > 0): ?>
                                    <?= (int)$product['stock'] ?> available
                                <?php else: ?>
                                    Out of stock
                                <?php endif; ?>
                            </div>

                            <form method="POST">
                                <input type="hidden" name="csrf"
                                    value="<?= e(csrf_token()) ?>">

                                <input type="hidden" name="action" value="add">

                                <input type="hidden" name="product_id"
                                    value="<?= (int)$product['id'] ?>">

                                <button
                                    class="btn"
                                    type="submit"
                                    <?= (int)$product['stock'] <= 0 ? 'disabled' : '' ?>
                                >
                                    Add to Cart
                                </button>
                            </form>

                        </div>
                    </article>

                <?php endforeach; ?>

            </div>
        </section>

        <aside class="cart-panel">

            <h2>Your Cart (<?= $cartCount ?>)</h2>

            <?php if (!$cartItems): ?>

                <div class="empty">Your cart is empty.</div>

            <?php else: ?>

                <?php foreach ($cartItems as $item): ?>

                    <div class="cart-item">

                        <strong><?= e($item['name']) ?></strong>

                        <div>
                            <?= money($item['price']) ?> each
                        </div>

                        <form method="POST">

                            <input type="hidden" name="csrf"
                                value="<?= e(csrf_token()) ?>">

                            <input type="hidden" name="product_id"
                                value="<?= (int)$item['id'] ?>">

                            <input type="number"
                                name="quantity"
                                min="0"
                                max="<?= (int)$item['stock'] ?>"
                                value="<?= (int)$item['quantity'] ?>"
                                required>

                            <button type="submit" name="action" value="update">
                                Update
                            </button>

                            <button
                                type="submit"
                                name="action"
                                value="remove"
                                class="remove"
                            >
                                Remove
                            </button>

                        </form>

                        <div>
                            Subtotal: <strong><?= money($item['subtotal']) ?></strong>
                        </div>

                    </div>

                <?php endforeach; ?>

               <div class="cart-total">
    <span>Total</span>
    <span><?= money($cartTotal) ?></span>
</div>

<a href="customer_checkout.php" class="btn checkout-btn">
    Proceed to Checkout
</a>

            <?php endif; ?>

        </aside>

    </div>

</main>

</body>
</html>
