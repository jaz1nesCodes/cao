
<?php
require_once __DIR__ . '/../config.php';
require_login();

$pageTitle = $pageTitle ?? 'Dashboard';
$user = current_user();

/* ACCOUNT PROFILE */

$userName = trim($user['name'] ?? 'User');
$userRole = ucfirst($user['role'] ?? 'Staff');

$nameParts = preg_split('/\s+/u', $userName, -1, PREG_SPLIT_NO_EMPTY);
$userInitials = '';

foreach (array_slice($nameParts, 0, 2) as $part) {
    $firstCharacter = function_exists('mb_substr')
        ? mb_substr($part, 0, 1, 'UTF-8')
        : substr($part, 0, 1);

    $userInitials .= function_exists('mb_strtoupper')
        ? mb_strtoupper($firstCharacter, 'UTF-8')
        : strtoupper($firstCharacter);
}

$userInitials = $userInitials ?: 'U';

$pendingOnlineOrders = 0;
$pendingProductRequests = 0;

try {
    $pdo = db();

    $stmt = $pdo->query("
        SELECT COUNT(*) FROM orders
        WHERE order_status = 'Pending'
    ");
    $pendingOnlineOrders = (int)$stmt->fetchColumn();

    $stmt = $pdo->query("
        SELECT COUNT(*) FROM customer_product_requests
        WHERE status = 'Pending'
    ");
    $pendingProductRequests = (int)$stmt->fetchColumn();

} catch (Throwable $e) {
    error_log('Navigation notification error: ' . $e->getMessage());
}

$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($pageTitle) ?> · Jobili</title>

<link rel="stylesheet" href="assets/style.css?v=3">

<style>
.app {
    --sidebar-width: 250px;
}

.sidebar {
    width: var(--sidebar-width);
    min-width: var(--sidebar-width);
    background: #fff;
    border-right: 1px solid #eceef2;
    border-radius: 0 7px 7px 0;
    overflow-x: hidden;
    transition: width .25s ease, min-width .25s ease, transform .25s ease;
}

.brand {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 17px 16px;
    min-height: 72px;
    text-decoration: none;
    white-space: nowrap;
}

.brand-logo {
    width: 39px;
    height: 39px;
    object-fit: contain;
    flex-shrink: 0;
    border-radius: 8px;
}

.brand-text {
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.brand-text b {
    color: #171717;
    font-size: 17px;
    font-weight: 800;
}

.brand-text small {
    color: #9298a3;
    font-size: 9px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
}

.side-label {
    margin: 17px 18px 10px;
    color: #a0a5af;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1.4px;
}

.sidebar nav {
    padding: 0 11px;
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.sidebar nav a {
    position: relative;
    display: flex;
    align-items: center;
    gap: 12px;
    min-height: 43px;
    padding: 10px 13px;
    border-radius: 7px;
    color: #626976;
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
    transition: .2s ease;
}

.sidebar nav a:hover,
.sidebar nav a.active {
    background: #fff0f0;
    color: #dc2626;
}

.sidebar nav a.active {
    font-weight: 750;
}

.sidebar nav a.active::before {
    content: "";
    position: absolute;
    left: 0;
    top: 10px;
    bottom: 10px;
    width: 3px;
    border-radius: 0 4px 4px 0;
    background: #dc2626;
}

.nav-icon {
    width: 20px;
    flex-shrink: 0;
    text-align: center;
    font-size: 16px;
}

.nav-count {
    margin-left: auto;
    min-width: 21px;
    height: 21px;
    padding: 0 6px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 20px;
    background: #dc2626;
    color: #fff;
    font-size: 10px;
    font-weight: 800;
}

.sidebar-bottom {
    border-top: 1px solid #f0f1f4;
    padding: 14px 12px;
}

.profile {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 9px;
    border-radius: 8px;
    background: #f8f9fb;
    min-width: 0;
}

.avatar {
    width: 37px;
    height: 37px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: linear-gradient(135deg, #dc2626, #991b1b);
    color: #fff;
    font-size: 12px;
    font-weight: 850;
    letter-spacing: .5px;
}

.profile > div:last-child {
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.profile b {
    color: #252a34;
    font-size: 12px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.profile small {
    color: #9298a3;
    font-size: 10px;
}

.logout {
    display: flex;
    align-items: center;
    gap: 9px;
    margin-top: 9px;
    padding: 10px 12px;
    border-radius: 7px;
    color: #737985;
    font-size: 12px;
    font-weight: 650;
    text-decoration: none;
}

.logout:hover {
    background: #fff0f0;
    color: #dc2626;
}

.topbar {
    border-bottom: 1px solid #eceef2;
    background: rgba(255,255,255,.97);
}

.topbar-left {
    display: flex;
    align-items: center;
    gap: 12px;
}

.sidebar-toggle {
    width: 33px;
    height: 33px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    border: 1px solid #e8eaf0;
    border-radius: 7px;
    background: #fff;
    color: #555d6b;
    cursor: pointer;
    font-size: 17px;
}

.sidebar-toggle:hover {
    background: #fff0f0;
    color: #dc2626;
}

.mobile-brand {
    color: #dc2626;
    font-weight: 800;
}

.status-dot {
    color: #16a34a;
    font-size: 10px;
    font-weight: 650;
}

@media (min-width: 769px) {
    .app.sidebar-collapsed .sidebar {
        width: 72px;
        min-width: 72px;
    }

    .app.sidebar-collapsed .brand {
        justify-content: center;
        padding: 17px 5px;
    }

    .app.sidebar-collapsed .brand-text,
    .app.sidebar-collapsed .side-label,
    .app.sidebar-collapsed .sidebar nav a > span:not(.nav-icon),
    .app.sidebar-collapsed .profile > div:last-child,
    .app.sidebar-collapsed .logout > span:last-child {
        display: none;
    }

    .app.sidebar-collapsed .sidebar nav {
        padding: 0 9px;
    }

    .app.sidebar-collapsed .sidebar nav a {
        justify-content: center;
        padding: 10px 5px;
    }

    .app.sidebar-collapsed .nav-icon {
        width: auto;
    }

    .app.sidebar-collapsed .nav-count {
        position: absolute;
        top: 2px;
        right: 2px;
        min-width: 15px;
        height: 15px;
        padding: 0 3px;
        font-size: 9px;
    }

    .app.sidebar-collapsed .profile {
        justify-content: center;
        padding: 7px 3px;
    }

    .app.sidebar-collapsed .logout {
        justify-content: center;
    }
}

@media (max-width: 768px) {
    .sidebar {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        z-index: 1000;
        width: 250px;
        min-width: 250px;
        border-radius: 0 8px 8px 0;
        box-shadow: 5px 0 25px rgba(0,0,0,.08);
    }

    .app.sidebar-collapsed .sidebar {
        transform: translateX(-105%);
    }

    .app:not(.sidebar-collapsed) .sidebar {
        transform: translateX(0);
    }

    .app.sidebar-collapsed .brand {
        justify-content: flex-start;
    }

    .app.sidebar-collapsed .sidebar nav {
        padding: 0 11px;
    }

    .app.sidebar-collapsed .sidebar nav a {
        justify-content: flex-start;
        padding: 10px 13px;
    }

    .app.sidebar-collapsed .sidebar nav a > span,
    .app.sidebar-collapsed .profile > div:last-child,
    .app.sidebar-collapsed .logout > span:last-child {
        display: initial;
    }
}
</style>
</head>

<body>

<div class="app" id="jobiliApp">

<aside class="sidebar">

    <a class="brand" href="index.php">
        <img src="assets/jobili-logo.png" alt="JOBILI Logo" class="brand-logo">
        <span class="brand-text">
            <b>JOBILI</b>
            <small>Store Manager</small>
        </span>
    </a>

    <div class="side-label">WORKSPACE</div>

    <nav>
        <a href="index.php" class="<?= $currentPage === 'index.php' ? 'active' : '' ?>">
            <span class="nav-icon">▦</span>
            <span>Dashboard</span>
        </a>

        <a href="pos.php" class="<?= $currentPage === 'pos.php' ? 'active' : '' ?>">
            <span class="nav-icon">▣</span>
            <span>POS Register</span>
        </a>

        <a href="products.php" class="<?= $currentPage === 'products.php' ? 'active' : '' ?>">
            <span class="nav-icon">▤</span>
            <span>Products & Inventory</span>
        </a>

        <a href="customers.php" class="<?= $currentPage === 'customers.php' ? 'active' : '' ?>">
            <span class="nav-icon">♙</span>
            <span>Customers & Utang</span>
        </a>

        <a href="expenses.php" class="<?= $currentPage === 'expenses.php' ? 'active' : '' ?>">
            <span class="nav-icon">₱</span>
            <span>Expenses</span>
        </a>

        <a href="reports.php" class="<?= $currentPage === 'reports.php' ? 'active' : '' ?>">
            <span class="nav-icon">▥</span>
            <span>Reports</span>
        </a>

        <a href="online_orders.php" class="<?= $currentPage === 'online_orders.php' ? 'active' : '' ?>">
            <span class="nav-icon">🛒</span>
            <span>Online Orders</span>
            <?php if ($pendingOnlineOrders > 0): ?>
                <span class="nav-count"><?= $pendingOnlineOrders > 99 ? '99+' : $pendingOnlineOrders ?></span>
            <?php endif; ?>
        </a>

        <a href="product_requests.php" class="<?= $currentPage === 'product_requests.php' ? 'active' : '' ?>">
            <span class="nav-icon">📦</span>
            <span>Product Requests</span>
            <?php if ($pendingProductRequests > 0): ?>
                <span class="nav-count"><?= $pendingProductRequests > 99 ? '99+' : $pendingProductRequests ?></span>
            <?php endif; ?>
        </a>

        <?php if (($user['role'] ?? '') === 'owner'): ?>
            <a href="users.php" class="<?= $currentPage === 'users.php' ? 'active' : '' ?>">
                <span class="nav-icon">⚙</span>
                <span>Accounts</span>
            </a>
        <?php endif; ?>
    </nav>

    <div class="sidebar-bottom">

        <div class="profile">
            <div class="avatar"><?= e($userInitials) ?></div>

            <div>
                <b><?= e($userName) ?></b>
                <small><?= e($userRole) ?></small>
            </div>
        </div>

        <a class="logout" href="logout.php">
            <span>↪</span>
            <span>Sign out</span>
        </a>

    </div>

</aside>

<main class="main">

<header class="topbar">
    <div class="topbar-left">
        <button
            type="button"
            class="sidebar-toggle"
            id="sidebarToggle"
            aria-label="Toggle sidebar"
            aria-expanded="true"
        >☰</button>

        <div>
            <span class="mobile-brand">Jobili / </span>
            <b><?= e($pageTitle) ?></b>
            <small class="status-dot">● Online</small>
        </div>
    </div>

    <div class="top-actions">
        <span class="date"><?= date('D, M j, Y') ?></span>
        <a class="btn primary compact" href="pos.php">＋ New Sale</a>
    </div>
</header>

<section class="content">

<?php
if (!empty($_SESSION['flash'])):
    $f = $_SESSION['flash'];
    unset($_SESSION['flash']);
?>
    <div class="alert <?= e($f[1]) ?>"><?= e($f[0]) ?></div>
<?php endif; ?>

<script>
(function () {
    const app = document.getElementById('jobiliApp');
    const toggle = document.getElementById('sidebarToggle');

    if (!app || !toggle) return;

    toggle.addEventListener('click', function () {
        app.classList.toggle('sidebar-collapsed');

        const expanded = !app.classList.contains('sidebar-collapsed');
        toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    });

    app.querySelectorAll('.sidebar nav a').forEach(function (link) {
        link.addEventListener('click', function () {
            if (window.innerWidth <= 768) {
                app.classList.add('sidebar-collapsed');
                toggle.setAttribute('aria-expanded', 'false');
            }
        });
    });
})();
</script>
