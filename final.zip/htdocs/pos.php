
<?php
require __DIR__.'/config.php';
require_login();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    try {
        $items = $_POST['items'] ?? [];
        $customer = (int)($_POST['customer_id'] ?? 0) ?: null;
        $method = $_POST['payment_method'] ?? 'cash';

        $allowed = ['cash', 'utang', 'gcash', 'bank'];

        if (!in_array($method, $allowed, true)) {
            throw new RuntimeException('Invalid payment method.');
        }

        if ($method === 'utang' && !$customer) {
            throw new RuntimeException('Choose a customer for an utang sale.');
        }

        if ($method === 'utang' && $customer) {
            $checkCustomer = $pdo->prepare(
                'SELECT id FROM customers WHERE id=?'
            );
            $checkCustomer->execute([$customer]);

            if (!$checkCustomer->fetch()) {
                throw new RuntimeException('Selected customer was not found. Please select a valid customer.');
            }
        }

        if (!is_array($items) || !$items) {
            throw new RuntimeException('Add at least one item.');
        }

        $pdo->beginTransaction();

        $clean = [];
        $subtotal = 0;

        foreach ($items as $id => $qty) {
            $id = (int)$id;
            $qty = (int)$qty;

            if ($qty < 1) continue;

            $st = $pdo->prepare(
                'SELECT * FROM products WHERE id=? AND active=1 FOR UPDATE'
            );
            $st->execute([$id]);
            $p = $st->fetch();

            if (!$p) {
                throw new RuntimeException('A selected product is no longer available.');
            }

            if ($p['stock'] < $qty) {
                throw new RuntimeException(
                    'Not enough stock for '.$p['name'].'. Available: '.$p['stock']
                );
            }

            $line = $p['price'] * $qty;
            $subtotal += $line;

            $clean[] = [
                'p' => $p,
                'qty' => $qty,
                'line' => $line
            ];
        }

        if (!$clean) {
            throw new RuntimeException('Add valid item quantities.');
        }

        $discount = max(0, (float)($_POST['discount'] ?? 0));

        if ($discount > $subtotal) {
            throw new RuntimeException('Discount cannot exceed subtotal.');
        }

        $total = round($subtotal - $discount, 2);

        $paid = $method === 'utang'
            ? 0
            : max(0, (float)($_POST['amount_paid'] ?? 0));

        if ($method !== 'utang' && $paid < $total) {
            throw new RuntimeException('Amount paid is less than the total.');
        }

        $status = $method === 'utang' ? 'utang' : 'paid';

        $receipt = 'JB-'.date('ymd').'-'.strtoupper(bin2hex(random_bytes(3)));

        $st = $pdo->prepare(
            'INSERT INTO sales
            (receipt_no,customer_id,user_id,subtotal,discount,total,amount_paid,change_due,payment_method,status)
            VALUES(?,?,?,?,?,?,?,?,?,?)'
        );

        $st->execute([
            $receipt,
            $customer,
            current_user()['id'],
            $subtotal,
            $discount,
            $total,
            $paid,
            $method === 'utang' ? 0 : $paid - $total,
            $method,
            $status
        ]);

        $saleId = (int)$pdo->lastInsertId();

        foreach ($clean as $it) {
            $p = $it['p'];
            $qty = $it['qty'];

            $pdo->prepare(
                'INSERT INTO sale_items
                (sale_id,product_id,product_name,quantity,unit_price,unit_cost,line_total)
                VALUES(?,?,?,?,?,?,?)'
            )->execute([
                $saleId,
                $p['id'],
                $p['name'],
                $qty,
                $p['price'],
                $p['cost'],
                $it['line']
            ]);

            $pdo->prepare(
                'UPDATE products SET stock=stock-? WHERE id=?'
            )->execute([$qty, $p['id']]);

            $pdo->prepare(
                'INSERT INTO inventory_logs(product_id,user_id,change_qty,reason)
                VALUES(?,?,?,?)'
            )->execute([
                $p['id'],
                current_user()['id'],
                -$qty,
                'Sale '.$receipt
            ]);
        }

        if ($method === 'utang') {
            $pdo->prepare(
                'INSERT INTO debt_payments(sale_id,amount,user_id,notes)
                VALUES(?,0,?,?)'
            )->execute([
                $saleId,
                current_user()['id'],
                'Utang sale opened'
            ]);
        }

        $pdo->commit();

        flash('Sale completed. Receipt: '.$receipt);
        redirect('receipt.php?id='.$saleId);

    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        flash($ex->getMessage(), 'error');
        redirect('pos.php');
    }
}

/* GET CATEGORIES */
$categories = $pdo->query(
    'SELECT id,name FROM categories ORDER BY name'
)->fetchAll();

/* GET AVAILABLE PRODUCTS WITH CATEGORY */
$products = $pdo->query(
    'SELECT
        p.id,
        p.name,
        p.sku,
        p.price,
        p.stock,
        p.image,
        p.category_id,
        c.name AS category_name
     FROM products p
     LEFT JOIN categories c ON c.id = p.category_id
     WHERE p.active = 1 AND p.stock > 0
     ORDER BY p.name'
)->fetchAll();

/* GET CUSTOMERS */
$customers = $pdo->query(
    'SELECT id,name,phone FROM customers ORDER BY name'
)->fetchAll();

$pageTitle = 'POS Register';
require __DIR__.'/partials/header.php';
?>

<style>
/* =========================================
   JOBILI PREMIUM POS DESIGN
========================================= */

.pos-page {
    --pos-red: #dc2626;
    --pos-red-dark: #b91c1c;
    --pos-text: #202633;
    --pos-muted: #89919f;
    --pos-border: #eaedf1;
    --pos-bg: #f8f9fb;
    color: var(--pos-text);
}

.pos-page * {
    box-sizing: border-box;
}

.pos-page .pos-intro {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 22px;
}

.pos-page .pos-intro h1 {
    margin: 0 0 5px;
    font-size: 25px;
    font-weight: 800;
    letter-spacing: -.7px;
    color: #1d2430;
}

.pos-page .pos-intro p {
    margin: 0;
    color: var(--pos-muted);
    font-size: 13px;
}

.pos-page .ready-status {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 8px 12px;
    border: 1px solid #bbf7d0;
    background: #f0fdf4;
    color: #15803d;
    border-radius: 7px;
    font-size: 11px;
    font-weight: 750;
    white-space: nowrap;
}

.pos-page .ready-status span {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #22c55e;
}

/* MAIN LAYOUT */

.pos-page .pos-layout {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 355px;
    align-items: start;
    gap: 20px;
}

.pos-page .pos-panel {
    background: #fff;
    border: 1px solid var(--pos-border);
    border-radius: 9px;
    padding: 20px;
    min-width: 0;
    box-shadow: 0 2px 8px rgba(20, 30, 50, .025);
}

.pos-page .pos-panel-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 17px;
}

.pos-page .pos-panel-heading h2 {
    margin: 0 0 4px;
    font-size: 16px;
    font-weight: 800;
    color: #222936;
}

.pos-page .pos-panel-heading p {
    margin: 0;
    font-size: 11px;
    color: var(--pos-muted);
}

.pos-page .heading-icon {
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    background: #fff1f1;
    color: var(--pos-red);
    border-radius: 8px;
    font-size: 17px;
}

/* SEARCH AND FILTER */

.pos-page .pos-toolbar {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 185px;
    gap: 10px;
    margin-bottom: 17px;
}

.pos-page .pos-search-wrap {
    position: relative;
}

.pos-page .pos-search-icon {
    position: absolute;
    left: 13px;
    top: 50%;
    transform: translateY(-50%);
    color: #9ca3af;
    font-size: 15px;
    pointer-events: none;
}

.pos-page .pos-search,
.pos-page .pos-category,
.pos-page .pos-form input,
.pos-page .pos-form select {
    width: 100%;
    min-height: 42px;
    border: 1px solid #e5e8ed;
    border-radius: 7px;
    background: #fff;
    color: #303846;
    font-size: 12px;
    outline: none;
    transition: border-color .2s, box-shadow .2s;
}

.pos-page .pos-search {
    padding: 10px 12px 10px 38px;
}

.pos-page .pos-category {
    padding: 10px 12px;
}

.pos-page .pos-search:focus,
.pos-page .pos-category:focus,
.pos-page .pos-form input:focus,
.pos-page .pos-form select:focus {
    border-color: #f87171;
    box-shadow: 0 0 0 3px rgba(220, 38, 38, .07);
}

.pos-page input::placeholder {
    color: #a4aab4;
}

/* PRODUCT GRID */

.pos-page .pos-product-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(155px, 1fr));
    gap: 12px;
}

.pos-page .product-tile {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    min-width: 0;
    padding: 11px;
    border: 1px solid #edf0f3;
    border-radius: 8px;
    background: #fff;
    transition: border-color .2s, box-shadow .2s, transform .2s;
}

.pos-page .product-tile:hover {
    border-color: #fecaca;
    box-shadow: 0 5px 16px rgba(30, 40, 60, .06);
    transform: translateY(-2px);
}

.pos-page .product-image,
.pos-page .tile-icon {
    width: 100%;
    height: 115px;
    object-fit: contain;
    border-radius: 6px;
    background: #f8f9fb;
    margin-bottom: 10px;
}

.pos-page .tile-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    color: #c4c9d1;
    font-size: 34px;
}

.pos-page .product-tile > b {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    min-height: 34px;
    color: #293140;
    font-size: 12px;
    font-weight: 750;
    line-height: 1.4;
}

.pos-page .product-tile > small {
    margin-top: 4px;
    color: #959daa;
    font-size: 10px;
    line-height: 1.4;
}

.pos-page .product-tile > strong {
    margin: 10px 0;
    color: var(--pos-red);
    font-size: 15px;
    font-weight: 800;
}

.pos-page .pos-add-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    width: 100%;
    min-height: 34px;
    border: 1px solid #fecaca;
    border-radius: 6px;
    background: #fff5f5;
    color: #dc2626;
    font-size: 11px;
    font-weight: 750;
    cursor: pointer;
    transition: .2s;
}

.pos-page .pos-add-btn:hover {
    background: var(--pos-red);
    color: #fff;
    border-color: var(--pos-red);
}

.pos-page .product-tile[hidden] {
    display: none !important;
}

/* CART PANEL */

.pos-page .cart-panel {
    position: sticky;
    top: 15px;
}

.pos-page .cart-count {
    min-width: 27px;
    height: 27px;
    padding: 0 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 7px;
    background: #fff0f0;
    color: var(--pos-red);
    font-size: 11px;
    font-weight: 800;
}

.pos-page .cart-items {
    max-height: 310px;
    overflow-y: auto;
    border-top: 1px solid #f0f1f4;
    border-bottom: 1px solid #f0f1f4;
}

.pos-page .cart-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 13px 0;
    border-bottom: 1px solid #f0f1f4;
}

.pos-page .cart-row:last-child {
    border-bottom: 0;
}

.pos-page .cart-row > div:first-child {
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.pos-page .cart-row > div:first-child b {
    font-size: 12px;
    color: #303846;
    overflow-wrap: anywhere;
}

.pos-page .cart-row small {
    color: #969daa;
    font-size: 10px;
}

.pos-page .cart-line-end {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 7px;
    flex-shrink: 0;
}

.pos-page .cart-line-end > strong {
    color: #293140;
    font-size: 12px;
}

.pos-page .qty-controls {
    display: flex;
    align-items: center;
    gap: 8px;
}

.pos-page .qty-controls button {
    width: 25px;
    height: 25px;
    border: 1px solid #e6e8ed;
    border-radius: 5px;
    background: #fff;
    color: #4b5563;
    cursor: pointer;
    font-size: 14px;
    font-weight: 700;
}

.pos-page .qty-controls button:hover {
    background: #fff0f0;
    color: var(--pos-red);
    border-color: #fecaca;
}

.pos-page .qty-controls span {
    min-width: 15px;
    text-align: center;
    font-size: 11px;
    font-weight: 750;
}

.pos-page .pos-empty {
    padding: 32px 10px;
    text-align: center;
    color: #9aa1ac;
    font-size: 12px;
}

.pos-page .pos-empty-icon {
    display: block;
    margin-bottom: 9px;
    color: #c8cdd5;
    font-size: 27px;
}

/* SUMMARY */

.pos-page .cart-summary {
    padding-top: 16px;
}

.pos-page .summary-line {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    font-size: 12px;
}

.pos-page .summary-line span {
    color: #818a98;
}

.pos-page .summary-line b {
    color: #343c49;
    font-size: 12px;
}

.pos-page .pos-form label {
    display: block;
    margin-bottom: 7px;
    color: #4b5563;
    font-size: 11px;
    font-weight: 700;
}

.pos-page .pos-field {
    margin-bottom: 13px;
}

.pos-page .pos-form input,
.pos-page .pos-form select {
    padding: 10px 11px;
}

.pos-page .pos-total {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 15px 0;
    padding: 14px 0;
    border-top: 1px dashed #e3e6eb;
    border-bottom: 1px dashed #e3e6eb;
}

.pos-page .pos-total span {
    color: #414958;
    font-size: 13px;
    font-weight: 750;
}

.pos-page .pos-total strong {
    color: var(--pos-red);
    font-size: 24px;
    font-weight: 850;
    letter-spacing: -.7px;
}

.pos-page .change-box {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 13px 0;
    padding: 11px 12px;
    border: 1px solid #e9edf2;
    border-radius: 7px;
    background: #f8f9fb;
    color: #687181;
    font-size: 11px;
}

.pos-page .change-box b {
    color: #293140;
    font-size: 13px;
    font-weight: 800;
}

.pos-page .pos-checkout {
    width: 100%;
    min-height: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    border: 0;
    border-radius: 7px;
    background: linear-gradient(135deg, #e33434, #c91e1e);
    color: #fff;
    font-size: 12px;
    font-weight: 800;
    cursor: pointer;
    box-shadow: 0 4px 10px rgba(220, 38, 38, .16);
    transition: .2s;
}

.pos-page .pos-checkout:hover {
    background: #b91c1c;
    box-shadow: 0 5px 15px rgba(220, 38, 38, .22);
    transform: translateY(-1px);
}

/* RESPONSIVE */

@media (max-width: 1100px) {
    .pos-page .pos-layout {
        grid-template-columns: minmax(0, 1fr) 320px;
        gap: 14px;
    }

    .pos-page .pos-panel {
        padding: 15px;
    }
}

@media (max-width: 850px) {
    .pos-page .pos-layout {
        grid-template-columns: 1fr;
    }

    .pos-page .cart-panel {
        position: static;
    }

    .pos-page .cart-items {
        max-height: 350px;
    }
}

@media (max-width: 500px) {
    .pos-page .pos-intro {
        align-items: flex-start;
        flex-direction: column;
    }

    .pos-page .pos-intro h1 {
        font-size: 22px;
    }

    .pos-page .pos-toolbar {
        grid-template-columns: 1fr;
    }

    .pos-page .pos-product-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 9px;
    }

    .pos-page .product-image,
    .pos-page .tile-icon {
        height: 95px;
    }

    .pos-page .pos-panel {
        padding: 13px;
    }
}
</style>


<div class="pos-page">

    <!-- PAGE INTRO -->
    <div class="pos-intro">
        <div>
            <h1>POS Register</h1>
            <p>Manage products, process transactions and complete sales.</p>
        </div>

        <div class="ready-status">
            <span></span>
            Ready to sell
        </div>
    </div>


    <form method="post" id="pos-form" class="pos-form">

        <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">

        <div class="pos-layout">

            <!-- PRODUCTS -->
            <section class="pos-panel">

                <div class="pos-panel-heading">
                    <div>
                        <h2>Available Products</h2>
                        <p>Browse products and add them to your current sale.</p>
                    </div>

                    <div class="heading-icon">▤</div>
                </div>


                <!-- SEARCH AND FILTER -->
                <div class="pos-toolbar">

                    <div class="pos-search-wrap">
                        <span class="pos-search-icon">⌕</span>

                        <input
                            type="search"
                            id="pos-product-search"
                            class="pos-search"
                            placeholder="Search product name or SKU..."
                        >
                    </div>

                    <select
                        id="pos-category-filter"
                        class="pos-category"
                    >
                        <option value="all">All Categories</option>

                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= (int)$cat['id'] ?>">
                                <?=e($cat['name'])?>
                            </option>
                        <?php endforeach; ?>

                    </select>

                </div>


                <!-- PRODUCT GRID -->
                <div id="pos-product-grid" class="pos-product-grid">

                    <?php foreach ($products as $p): ?>

                        <article
                            class="product-tile"
                            data-name="<?=e(strtolower($p['name'].' '.$p['sku']))?>"
                            data-category="<?= (int)($p['category_id'] ?? 0) ?>"
                        >

                            <?php if (!empty($p['image'])): ?>

                                <img
                                    src="uploads/products/<?=e($p['image'])?>"
                                    alt="<?=e($p['name'])?>"
                                    class="product-image"
                                    loading="lazy"
                                >

                            <?php else: ?>

                                <div class="tile-icon">▤</div>

                            <?php endif; ?>

                            <b><?=e($p['name'])?></b>

                            <small>
                                <?=e($p['sku'] ?: 'No SKU')?>
                                · <?=$p['stock']?> in stock
                            </small>

                            <small>
                                <?=e($p['category_name'] ?? 'Uncategorized')?>
                            </small>

                            <strong><?=money($p['price'])?></strong>

                            <button
                                type="button"
                                class="pos-add-btn add-product"
                                data-id="<?=$p['id']?>"
                                data-name="<?=e($p['name'])?>"
                                data-price="<?=$p['price']?>"
                                data-stock="<?=$p['stock']?>"
                            >
                                ＋ Add to cart
                            </button>

                        </article>

                    <?php endforeach; ?>

                </div>


                <p
                    id="pos-no-results"
                    class="pos-empty"
                    style="display:none;"
                >
                    No matching products found. Try another search or category.
                </p>


                <?php if (!$products): ?>

                    <div class="pos-empty">
                        <span class="pos-empty-icon">▤</span>
                        No products with available stock.
                        <br>
                        Add products in Inventory first.
                    </div>

                <?php endif; ?>

            </section>


            <!-- CURRENT SALE -->
            <aside class="pos-panel cart-panel">

                <div class="pos-panel-heading">

                    <div>
                        <h2>Current Sale</h2>
                        <p>Review your transaction before checkout.</p>
                    </div>

                    <span id="cart-count" class="cart-count">0</span>

                </div>


                <!-- CART ITEMS -->
                <div id="cart-items" class="cart-items">

                    <div class="pos-empty">
                        <span class="pos-empty-icon">🛒</span>
                        Your cart is empty.
                        <br>
                        Select products to get started.
                    </div>

                </div>


                <!-- CART SUMMARY -->
                <div class="cart-summary">

                    <div class="summary-line">
                        <span>Subtotal</span>
                        <b id="subtotal">₱0.00</b>
                    </div>


                    <div class="pos-field">

                        <label for="discount">Discount (₱)</label>

                        <input
                            type="number"
                            id="discount"
                            name="discount"
                            min="0"
                            step=".01"
                            value="0"
                        >

                    </div>


                    <div class="pos-total">
                        <span>Total Amount</span>
                        <strong id="total">₱0.00</strong>
                    </div>


                    <div class="pos-field">

                        <label for="customer-id">Customer</label>

                        <select name="customer_id" id="customer-id">

                            <option value="">Walk-in customer</option>

                            <?php foreach ($customers as $c): ?>

                                <option value="<?=$c['id']?>">
                                    <?=e($c['name'])?>
                                    <?=$c['phone'] ? ' · '.e($c['phone']) : ''?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="pos-field">

                        <label for="payment-method">Payment Method</label>

                        <select name="payment_method" id="payment-method">

                            <option value="cash">Cash</option>
                            <option value="gcash">GCash</option>
                            <option value="bank">Bank Transfer</option>
                            <option value="utang">Utang / Pay Later</option>

                        </select>

                    </div>


                    <div id="paid-wrap" class="pos-field">

                        <label for="amount-paid">Amount Received (₱)</label>

                        <input
                            type="number"
                            id="amount-paid"
                            name="amount_paid"
                            min="0"
                            step=".01"
                            value="0"
                        >

                    </div>


                    <div class="change-box">
                        <span>Change Due</span>
                        <b id="change">₱0.00</b>
                    </div>


                    <button type="submit" class="pos-checkout checkout-btn">
                        <span>✓</span>
                        Complete Sale
                    </button>

                </div>

            </aside>

        </div>

    </form>

</div>


<!-- CATEGORY FILTER -->
<script>
document.addEventListener('DOMContentLoaded', function () {

    const searchInput = document.getElementById('pos-product-search');
    const categoryFilter = document.getElementById('pos-category-filter');
    const productGrid = document.getElementById('pos-product-grid');
    const noResults = document.getElementById('pos-no-results');

    if (!searchInput || !categoryFilter || !productGrid) return;

    const productTiles = Array.from(
        productGrid.querySelectorAll('.product-tile')
    );

    function filterProducts() {

        const searchValue = searchInput.value.trim().toLowerCase();
        const selectedCategory = categoryFilter.value;

        let visibleCount = 0;

        productTiles.forEach(function (product) {

            const productName = product.dataset.name || '';
            const productCategory = product.dataset.category || '0';

            const matchesSearch = productName.includes(searchValue);

            const matchesCategory =
                selectedCategory === 'all' ||
                productCategory === selectedCategory;

            const isVisible = matchesSearch && matchesCategory;

            product.hidden = !isVisible;

            if (isVisible) visibleCount++;

        });

        if (noResults) {
            noResults.style.display =
                visibleCount === 0 ? 'block' : 'none';
        }
    }

    searchInput.addEventListener('input', filterProducts);
    categoryFilter.addEventListener('change', filterProducts);

});
</script>


<!-- EXISTING POS CART DATA -->
<script>
window.JOBILI_PRODUCTS = <?=json_encode(
    array_map(
        fn($p) => [
            'id' => (int)$p['id'],
            'name' => $p['name'],
            'price' => (float)$p['price'],
            'stock' => (int)$p['stock']
        ],
        $products
    ),
    JSON_HEX_TAG |
    JSON_HEX_APOS |
    JSON_HEX_QUOT |
    JSON_HEX_AMP
)?>;
</script>


<?php require __DIR__.'/partials/footer.php'; ?>
