
<?php
require __DIR__ . '/config.php';
require_login();

$pdo = db();

$errors = [];
$success = '';

$allowedStatuses = ['Pending', 'Reviewing', 'Available', 'Not Available'];

/* UPDATE STATUS */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    if (($_POST['action'] ?? '') === 'update_status') {
        $requestId = (int)($_POST['request_id'] ?? 0);
        $newStatus = trim($_POST['status'] ?? '');

        if ($requestId <= 0) {
            $errors[] = 'Invalid product request.';
        } elseif (!in_array($newStatus, $allowedStatuses, true)) {
            $errors[] = 'Invalid request status.';
        } else {
            $stmt = $pdo->prepare("
                UPDATE customer_product_requests
                SET status = ?
                WHERE id = ?
            ");
            $stmt->execute([$newStatus, $requestId]);

            if ($stmt->rowCount() > 0) {
                $success = 'Product request status updated successfully.';
            } else {
                $check = $pdo->prepare("
                    SELECT id, status
                    FROM customer_product_requests
                    WHERE id = ?
                ");
                $check->execute([$requestId]);
                $existing = $check->fetch();

                if ($existing && $existing['status'] === $newStatus) {
                    $success = 'Request status is already ' . $newStatus . '.';
                } else {
                    $errors[] = 'Product request not found.';
                }
            }
        }
    }
}

/* STATISTICS */
$countStmt = $pdo->query("
    SELECT
        COUNT(*) AS total,
        SUM(status = 'Pending') AS pending,
        SUM(status = 'Reviewing') AS reviewing,
        SUM(status = 'Available') AS available,
        SUM(status = 'Not Available') AS unavailable
    FROM customer_product_requests
");
$counts = $countStmt->fetch();

/* SEARCH AND FILTER */
$search = trim($_GET['q'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');

$sql = "
    SELECT
        r.id,
        r.product_name,
        r.preferred_quantity,
        r.details,
        r.status,
        r.created_at,
        COALESCE(c.name, 'Unknown Customer') AS customer_name
    FROM customer_product_requests r
    LEFT JOIN customers c ON c.id = r.customer_id
    WHERE 1 = 1
";

$params = [];

if ($search !== '') {
    $sql .= " AND (r.product_name LIKE ? OR c.name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (in_array($statusFilter, $allowedStatuses, true)) {
    $sql .= " AND r.status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY r.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$requests = $stmt->fetchAll();

$pageTitle = 'Product Requests';
require __DIR__ . '/partials/header.php';
?>

<style>
/* PREMIUM PRODUCT REQUESTS DESIGN */

.pr-page {
    display: flex;
    flex-direction: column;
    gap: 24px;
    padding-bottom: 30px;
    color: #172033;
}

.pr-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 18px;
}

.pr-header h1 {
    font-size: 27px;
    font-weight: 750;
    letter-spacing: -0.8px;
    margin: 7px 0;
    color: #172033;
}

.pr-header p {
    color: #8490a3;
    font-size: 13px;
    margin: 0;
}

.pr-eyebrow {
    color: #64748b;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1.5px;
}

.pr-back {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    background: #fff;
    color: #334155;
    border: 1px solid #e6eaf0;
    padding: 11px 16px;
    border-radius: 9px;
    font-size: 12px;
    font-weight: 700;
    transition: .2s;
}

.pr-back:hover {
    background: #f8fafc;
    border-color: #cbd5e1;
    transform: translateY(-1px);
}

/* ALERTS */

.pr-alert {
    padding: 14px 17px;
    border-radius: 10px;
    font-size: 13px;
    font-weight: 600;
}

.pr-success {
    background: #ecfdf5;
    border: 1px solid #bbf7d0;
    color: #15803d;
}

.pr-error {
    background: #fff1f2;
    border: 1px solid #fecdd3;
    color: #be123c;
}

/* STATISTICS */

.pr-stats {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 18px;
}

.pr-stat {
    position: relative;
    overflow: hidden;
    background: #fff;
    border: 1px solid #e9edf3;
    border-radius: 14px;
    padding: 21px;
    box-shadow: 0 3px 12px rgba(15, 23, 42, .035);
    transition: .2s;
}

.pr-stat:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 22px rgba(15, 23, 42, .07);
}

.pr-stat-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    margin-bottom: 19px;
}

.pr-stat-label {
    font-size: 12px;
    font-weight: 700;
    color: #7b8799;
}

.pr-stat-icon {
    width: 39px;
    height: 39px;
    border-radius: 11px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    font-weight: 800;
}

.pr-stat-number {
    display: block;
    color: #172033;
    font-size: 29px;
    font-weight: 800;
    letter-spacing: -1px;
    line-height: 1.2;
}

.pr-stat-note {
    display: block;
    color: #98a2b3;
    font-size: 11px;
    margin-top: 7px;
}

.pr-icon-blue {
    color: #2563eb;
    background: #eff6ff;
}

.pr-icon-amber {
    color: #d97706;
    background: #fffbeb;
}

.pr-icon-purple {
    color: #7c3aed;
    background: #f5f3ff;
}

.pr-icon-green {
    color: #059669;
    background: #ecfdf5;
}

/* PANELS */

.pr-panel {
    background: #fff;
    border: 1px solid #e9edf3;
    border-radius: 14px;
    padding: 22px;
    box-shadow: 0 3px 12px rgba(15, 23, 42, .035);
}

.pr-panel-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 19px;
}

.pr-panel-heading h2 {
    margin: 0;
    font-size: 16px;
    font-weight: 750;
    color: #172033;
}

.pr-panel-heading p {
    margin: 6px 0 0;
    font-size: 12px;
    color: #98a2b3;
}

.pr-count {
    background: #eff6ff;
    color: #2563eb;
    padding: 7px 11px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 800;
}

/* FILTER FORM */

.pr-filter {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 11px;
}

.pr-search-wrap {
    position: relative;
    flex: 1;
    min-width: 220px;
}

.pr-search-wrap span {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
    font-size: 16px;
}

.pr-filter input,
.pr-filter select,
.pr-action-form select {
    height: 43px;
    border: 1px solid #e2e8f0;
    border-radius: 9px;
    background: #fff;
    color: #334155;
    outline: none;
    font-size: 12px;
    transition: .2s;
}

.pr-filter input {
    width: 100%;
    padding: 0 13px 0 39px;
}

.pr-filter select {
    min-width: 165px;
    padding: 0 12px;
}

.pr-filter input:focus,
.pr-filter select:focus,
.pr-action-form select:focus {
    border-color: #7398f5;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, .10);
}

.pr-btn {
    height: 43px;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    gap: 7px;
    padding: 0 17px;
    border: 0;
    border-radius: 9px;
    background: #2563eb;
    color: #fff;
    font-size: 12px;
    font-weight: 750;
    cursor: pointer;
    text-decoration: none;
    transition: .2s;
    white-space: nowrap;
}

.pr-btn:hover {
    background: #1d4ed8;
    transform: translateY(-1px);
}

.pr-btn-reset {
    background: #f1f5f9;
    color: #475569;
}

.pr-btn-reset:hover {
    background: #e2e8f0;
}

/* TABLE */

.pr-table-wrap {
    width: 100%;
    overflow-x: auto;
}

.pr-table {
    width: 100%;
    min-width: 900px;
    border-collapse: separate;
    border-spacing: 0;
}

.pr-table th {
    padding: 14px 13px;
    text-align: left;
    background: #f8fafc;
    color: #8490a3;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .7px;
    text-transform: uppercase;
    border-top: 1px solid #edf0f4;
    border-bottom: 1px solid #edf0f4;
    white-space: nowrap;
}

.pr-table th:first-child {
    border-radius: 8px 0 0 8px;
}

.pr-table th:last-child {
    border-radius: 0 8px 8px 0;
}

.pr-table td {
    padding: 16px 13px;
    border-bottom: 1px solid #f0f2f5;
    color: #475569;
    font-size: 12px;
    vertical-align: middle;
}

.pr-table tbody tr {
    transition: background .15s;
}

.pr-table tbody tr:hover {
    background: #fafcff;
}

.pr-product-name {
    display: block;
    color: #172033;
    font-size: 12px;
    font-weight: 750;
    max-width: 190px;
}

.pr-request-id {
    display: block;
    color: #a0aabb;
    font-size: 10px;
    margin-top: 5px;
}

.pr-customer {
    color: #334155;
    font-weight: 650;
}

.pr-quantity {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 32px;
    padding: 6px 9px;
    border-radius: 7px;
    background: #f1f5f9;
    color: #334155;
    font-weight: 750;
}

.pr-details {
    display: block;
    max-width: 180px;
    line-height: 1.6;
    color: #64748b;
    overflow-wrap: anywhere;
}

.pr-date {
    color: #64748b;
    white-space: nowrap;
    font-size: 11px;
}

/* STATUS BADGES */

.pr-status {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 7px 10px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 800;
    white-space: nowrap;
}

.pr-status::before {
    content: "";
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: currentColor;
}

.pr-status-pending {
    background: #fffbeb;
    color: #b45309;
}

.pr-status-reviewing {
    background: #eff6ff;
    color: #2563eb;
}

.pr-status-available {
    background: #ecfdf5;
    color: #059669;
}

.pr-status-unavailable {
    background: #fff1f2;
    color: #e11d48;
}

/* ACTION FORM */

.pr-action-form {
    display: flex;
    align-items: center;
    gap: 7px;
    min-width: 190px;
}

.pr-action-form select {
    height: 36px;
    min-width: 115px;
    padding: 0 8px;
    font-size: 11px;
}

.pr-save {
    height: 36px;
    padding: 0 12px;
    border: 0;
    border-radius: 8px;
    background: #172f57;
    color: #fff;
    font-size: 11px;
    font-weight: 750;
    cursor: pointer;
    transition: .2s;
}

.pr-save:hover {
    background: #254b80;
}

/* EMPTY STATE */

.pr-empty {
    text-align: center;
    padding: 45px 20px !important;
    color: #94a3b8 !important;
}

.pr-empty-icon {
    display: block;
    font-size: 27px;
    margin-bottom: 10px;
}

.pr-empty strong {
    display: block;
    color: #475569;
    font-size: 13px;
    margin-bottom: 5px;
}

.pr-empty small {
    font-size: 11px;
}

/* RESPONSIVE */

@media (max-width: 1100px) {
    .pr-stats {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 650px) {
    .pr-page {
        gap: 17px;
    }

    .pr-header {
        align-items: flex-start;
    }

    .pr-header h1 {
        font-size: 23px;
    }

    .pr-stats {
        grid-template-columns: 1fr 1fr;
        gap: 10px;
    }

    .pr-stat {
        padding: 15px;
    }

    .pr-stat-number {
        font-size: 24px;
    }

    .pr-stat-top {
        margin-bottom: 13px;
    }

    .pr-panel {
        padding: 16px;
    }

    .pr-filter {
        flex-direction: column;
        align-items: stretch;
    }

    .pr-search-wrap {
        min-width: 100%;
    }

    .pr-filter select,
    .pr-filter button,
    .pr-filter .pr-btn {
        width: 100%;
    }
}
</style>

<div class="pr-page">

    <!-- PAGE HEADER -->
    <div class="pr-header">
        <div>
            <span class="pr-eyebrow">CUSTOMER DEMAND MANAGEMENT</span>
            <h1>Product Requests</h1>
            <p>Monitor customer demand and discover what products to stock next.</p>
        </div>

        <a class="pr-back" href="index.php">
            ← Back to Dashboard
        </a>
    </div>

    <!-- MESSAGES -->
    <?php if ($success): ?>
        <div class="pr-alert pr-success">
            ✓ <?= e($success) ?>
        </div>
    <?php endif; ?>

    <?php foreach ($errors as $error): ?>
        <div class="pr-alert pr-error">
            <?= e($error) ?>
        </div>
    <?php endforeach; ?>

    <!-- STATISTICS -->
    <div class="pr-stats">

        <div class="pr-stat">
            <div class="pr-stat-top">
                <span class="pr-stat-label">Total Requests</span>
                <span class="pr-stat-icon pr-icon-blue">▤</span>
            </div>
            <strong class="pr-stat-number">
                <?= number_format((int)$counts['total']) ?>
            </strong>
            <span class="pr-stat-note">All customer requests</span>
        </div>

        <div class="pr-stat">
            <div class="pr-stat-top">
                <span class="pr-stat-label">Pending</span>
                <span class="pr-stat-icon pr-icon-amber">◷</span>
            </div>
            <strong class="pr-stat-number">
                <?= number_format((int)$counts['pending']) ?>
            </strong>
            <span class="pr-stat-note">Waiting for review</span>
        </div>

        <div class="pr-stat">
            <div class="pr-stat-top">
                <span class="pr-stat-label">Reviewing</span>
                <span class="pr-stat-icon pr-icon-purple">⌕</span>
            </div>
            <strong class="pr-stat-number">
                <?= number_format((int)$counts['reviewing']) ?>
            </strong>
            <span class="pr-stat-note">Currently being reviewed</span>
        </div>

        <div class="pr-stat">
            <div class="pr-stat-top">
                <span class="pr-stat-label">Available</span>
                <span class="pr-stat-icon pr-icon-green">✓</span>
            </div>
            <strong class="pr-stat-number">
                <?= number_format((int)$counts['available']) ?>
            </strong>
            <span class="pr-stat-note">Approved for stocking</span>
        </div>

    </div>

    <!-- SEARCH AND FILTER -->
    <section class="pr-panel">

        <div class="pr-panel-heading">
            <div>
                <h2>Manage Requests</h2>
                <p>Find and filter submitted customer requests.</p>
            </div>
        </div>

        <form method="GET" class="pr-filter">

            <div class="pr-search-wrap">
                <span>⌕</span>
                <input
                    type="text"
                    name="q"
                    value="<?= e($search) ?>"
                    placeholder="Search product or customer..."
                >
            </div>

            <select name="status">
                <option value="">All Statuses</option>

                <?php foreach ($allowedStatuses as $status): ?>
                    <option value="<?= e($status) ?>"
                        <?= $statusFilter === $status ? 'selected' : '' ?>>
                        <?= e($status) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="pr-btn">
                ⌕ Search
            </button>

            <a href="product_requests.php" class="pr-btn pr-btn-reset">
                ↻ Reset
            </a>

        </form>

    </section>

    <!-- REQUEST TABLE -->
    <section class="pr-panel">

        <div class="pr-panel-heading">
            <div>
                <h2>Customer Requests</h2>
                <p>Review product details and update request status.</p>
            </div>

            <span class="pr-count">
                <?= count($requests) ?> Requests
            </span>
        </div>

        <div class="pr-table-wrap">

            <table class="pr-table">

                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Customer</th>
                        <th>Quantity</th>
                        <th>Additional Details</th>
                        <th>Date Requested</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (!$requests): ?>

                    <tr>
                        <td colspan="7" class="pr-empty">
                            <span class="pr-empty-icon">📦</span>
                            <strong>No product requests found</strong>
                            <small>Customer requests will appear here.</small>
                        </td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($requests as $request): ?>

                        <?php
                        $statusClass = 'pr-status-pending';

                        if ($request['status'] === 'Reviewing') {
                            $statusClass = 'pr-status-reviewing';
                        } elseif ($request['status'] === 'Available') {
                            $statusClass = 'pr-status-available';
                        } elseif ($request['status'] === 'Not Available') {
                            $statusClass = 'pr-status-unavailable';
                        }
                        ?>

                        <tr>

                            <td>
                                <span class="pr-product-name">
                                    <?= e($request['product_name']) ?>
                                </span>
                                <span class="pr-request-id">
                                    Request #<?= (int)$request['id'] ?>
                                </span>
                            </td>

                            <td>
                                <span class="pr-customer">
                                    <?= e($request['customer_name']) ?>
                                </span>
                            </td>

                            <td>
                                <span class="pr-quantity">
                                    <?= number_format((int)$request['preferred_quantity']) ?>
                                </span>
                            </td>

                            <td>
                                <span class="pr-details">
                                    <?= e($request['details'] ?: '—') ?>
                                </span>
                            </td>

                            <td>
                                <span class="pr-date">
                                    <?= e(date('M j, Y g:i A', strtotime($request['created_at']))) ?>
                                </span>
                            </td>

                            <td>
                                <span class="pr-status <?= $statusClass ?>">
                                    <?= e($request['status']) ?>
                                </span>
                            </td>

                            <td>
                                <form method="POST" class="pr-action-form">

                                    <input
                                        type="hidden"
                                        name="csrf"
                                        value="<?= e(csrf_token()) ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="action"
                                        value="update_status"
                                    >

                                    <input
                                        type="hidden"
                                        name="request_id"
                                        value="<?= (int)$request['id'] ?>"
                                    >

                                    <select name="status">
                                        <?php foreach ($allowedStatuses as $status): ?>
                                            <option value="<?= e($status) ?>"
                                                <?= $request['status'] === $status ? 'selected' : '' ?>>
                                                <?= e($status) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>

                                    <button type="submit" class="pr-save">
                                        Save
                                    </button>

                                </form>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>
            </table>

        </div>

    </section>

</div>

<?php require __DIR__ . '/partials/footer.php'; ?>
