
<?php
require_once __DIR__ . '/config.php';

if (empty($_SESSION['customer'])) {
    redirect('customer_login.php');
}

$pdo = db();

$customerName = $_SESSION['customer']['name'] ?? 'Customer';
$customerId = (int)($_SESSION['customer']['id'] ?? 0);

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$errors = [];
$success = '';

/* AJAX: MARK NOTIFICATIONS AS READ */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && ($_POST['action'] ?? '') === 'mark_notifications_read'
) {
    verify_csrf();
    header('Content-Type: application/json');

    try {
        $stmt = $pdo->prepare("
            SELECT id, order_status
            FROM orders
            WHERE customer_id = ?
              AND order_status IN (
                  'Preparing',
                  'Ready for Pickup',
                  'Completed',
                  'Cancelled'
              )
            ORDER BY created_at DESC
            LIMIT 5
        ");
        $stmt->execute([$customerId]);

        $insert = $pdo->prepare("
            INSERT IGNORE INTO customer_notification_reads
                (customer_id, order_id, order_status)
            VALUES (?, ?, ?)
        ");

        foreach ($stmt->fetchAll() as $row) {
            $insert->execute([
                $customerId,
                (int)$row['id'],
                $row['order_status']
            ]);
        }

        echo json_encode(['success' => true]);

    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['success' => false]);
    }

    exit;
}

/* CART ACTIONS */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $action = $_POST['action'] ?? '';
    $productId = (int)($_POST['product_id'] ?? 0);

    try {

        /* ADD TO CART */

        if ($action === 'add') {

            $stmt = $pdo->prepare("
                SELECT id, name, stock, active
                FROM products
                WHERE id = ?
                LIMIT 1
            ");
            $stmt->execute([$productId]);
            $product = $stmt->fetch();

            if (!$product || (int)$product['active'] !== 1) {
                throw new RuntimeException('Product is unavailable.');
            }

            $currentQty = (int)($_SESSION['cart'][$productId] ?? 0);

            if ((int)$product['stock'] <= 0) {
                throw new RuntimeException('This product is out of stock.');
            }

            if ($currentQty + 1 > (int)$product['stock']) {
                throw new RuntimeException('You have reached the available stock limit.');
            }

            $_SESSION['cart'][$productId] = $currentQty + 1;
            $success = 'Product added to your cart.';

        /* UPDATE CART */

        } elseif ($action === 'update') {

            $quantity = (int)($_POST['quantity'] ?? 0);

            if ($quantity <= 0) {
                unset($_SESSION['cart'][$productId]);
            } else {
                $stmt = $pdo->prepare("
                    SELECT stock, active
                    FROM products
                    WHERE id = ?
                    LIMIT 1
                ");
                $stmt->execute([$productId]);
                $product = $stmt->fetch();

                if (!$product || (int)$product['active'] !== 1) {
                    throw new RuntimeException('Product is unavailable.');
                }

                if ($quantity > (int)$product['stock']) {
                    throw new RuntimeException('Quantity exceeds available stock.');
                }

                $_SESSION['cart'][$productId] = $quantity;
            }

        /* REMOVE FROM CART */

        } elseif ($action === 'remove') {

            unset($_SESSION['cart'][$productId]);
        }

    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

/* NOTIFICATIONS */

$notificationStmt = $pdo->prepare("
    SELECT
        o.id,
        o.order_number,
        o.order_status,
        o.created_at,
        CASE WHEN r.id IS NULL THEN 0 ELSE 1 END AS is_read
    FROM orders o
    LEFT JOIN customer_notification_reads r
        ON r.customer_id = o.customer_id
        AND r.order_id = o.id
        AND r.order_status = o.order_status
    WHERE o.customer_id = ?
      AND o.order_status IN (
          'Preparing',
          'Ready for Pickup',
          'Completed',
          'Cancelled'
      )
    ORDER BY o.created_at DESC
    LIMIT 5
");

$notificationStmt->execute([$customerId]);
$notifications = $notificationStmt->fetchAll();

$notificationCount = 0;

foreach ($notifications as $notification) {
    if (!(int)$notification['is_read']) {
        $notificationCount++;
    }
}

/* SEARCH AND CATEGORY */

$q = trim($_GET['q'] ?? '');
$categoryId = (int)($_GET['category'] ?? 0);

$categories = $pdo->query("
    SELECT id, name
    FROM categories
    ORDER BY name
")->fetchAll();

$sql = "
    SELECT p.*, c.name AS category_name
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    WHERE p.active = 1
";

$params = [];

if ($q !== '') {
    $sql .= " AND (p.name LIKE ? OR p.sku LIKE ?)";
    $params[] = "%$q%";
    $params[] = "%$q%";
}

if ($categoryId > 0) {
    $sql .= " AND p.category_id = ?";
    $params[] = $categoryId;
}

$sql .= " ORDER BY p.name";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

/* CART DATA */

$cartItems = [];
$cartTotal = 0;
$cartCount = 0;

if (!empty($_SESSION['cart'])) {

    $ids = array_map('intval', array_keys($_SESSION['cart']));
    $ids = array_filter($ids);

    if ($ids) {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        $stmt = $pdo->prepare("
            SELECT id, name, price, stock, active
            FROM products
            WHERE id IN ($placeholders)
        ");
        $stmt->execute(array_values($ids));

        foreach ($stmt->fetchAll() as $item) {

            $id = (int)$item['id'];
            $quantity = (int)($_SESSION['cart'][$id] ?? 0);

            if ($quantity <= 0 || (int)$item['active'] !== 1) {
                unset($_SESSION['cart'][$id]);
                continue;
            }

            if ($quantity > (int)$item['stock']) {
                $quantity = (int)$item['stock'];
                $_SESSION['cart'][$id] = $quantity;
            }

            if ($quantity <= 0) {
                unset($_SESSION['cart'][$id]);
                continue;
            }

            $subtotal = (float)$item['price'] * $quantity;

            $item['quantity'] = $quantity;
            $item['subtotal'] = $subtotal;

            $cartItems[] = $item;
            $cartTotal += $subtotal;
            $cartCount += $quantity;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>JOBILI | Online Shopping</title>

<style>
:root {
    --primary:#d62828;
    --primary-dark:#ad1717;
    --text:#24242a;
    --muted:#85858f;
    --border:#eeeeef;
    --background:#f7f7f9;
    --white:#fff;
}

* { box-sizing:border-box; }

body {
    margin:0;
    background:var(--background);
    color:var(--text);
    font-family:'Segoe UI',Arial,sans-serif;
}

a { text-decoration:none; }

.navbar {
    position:sticky;
    top:0;
    z-index:100;
    background:rgba(255,255,255,.97);
    backdrop-filter:blur(15px);
    padding:9px 5%;
    min-height:65px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:15px;
    border-bottom:1px solid var(--border);
    box-shadow:0 3px 15px rgba(0,0,0,.035);
}

.logo img {
    width:125px;
    max-width:100%;
    height:auto;
    display:block;
    object-fit:contain;
}

.nav-right {
    display:flex;
    align-items:center;
    gap:17px;
    font-size:12px;
}

.nav-right a {
    color:#555;
    font-weight:650;
}

.nav-right a:hover { color:var(--primary); }

.customer-greeting {
    color:#555;
    font-weight:600;
}

/* PRODUCT REQUEST BUTTON */

.request-link {
    background:#fff1f1;
    color:var(--primary)!important;
    border:1px solid #ffdada;
    padding:9px 12px;
    border-radius:8px;
    white-space:nowrap;
    transition:.2s;
}

.request-link:hover {
    background:var(--primary);
    color:white!important;
    border-color:var(--primary);
}

/* NOTIFICATIONS AND CART */

.notification-menu,.cart-menu { position:relative; }

.notification-menu summary {
    cursor:pointer;
    color:var(--primary);
    font-weight:750;
    list-style:none;
    white-space:nowrap;
}

.notification-menu summary::-webkit-details-marker,
.cart-menu summary::-webkit-details-marker { display:none; }

.notification-count,.cart-count {
    display:inline-block;
    background:var(--primary);
    color:white;
    padding:3px 7px;
    border-radius:20px;
    font-size:10px;
}

.notification-dropdown,.cart-dropdown {
    position:absolute;
    right:0;
    top:35px;
    width:310px;
    max-width:85vw;
    background:white;
    padding:18px;
    border-radius:14px;
    box-shadow:0 15px 40px rgba(0,0,0,.13);
    border:1px solid var(--border);
    z-index:200;
}

.notification-item {
    display:block;
    padding:13px 0;
    border-bottom:1px solid var(--border);
    color:#555!important;
    font-size:13px;
    line-height:1.6;
}

.notification-item strong { color:var(--primary); }

.notification-item.unread {
    background:#fff5f5;
    padding-left:10px;
    padding-right:10px;
    border-radius:8px;
    border-left:3px solid var(--primary);
}

.new-label {
    background:var(--primary);
    color:white;
    font-size:9px;
    font-weight:800;
    padding:3px 7px;
    border-radius:20px;
}

.notification-empty {
    color:var(--muted);
    font-size:13px;
}

.cart-menu summary {
    list-style:none;
    cursor:pointer;
    background:var(--primary);
    color:white;
    padding:9px 14px;
    border-radius:8px;
    font-weight:750;
    white-space:nowrap;
}

.cart-menu summary:hover { background:var(--primary-dark); }

.cart-menu summary .cart-count {
    background:white;
    color:var(--primary);
    margin-left:5px;
}

.cart-dropdown {
    top:43px;
    width:340px;
    max-height:75vh;
    overflow-y:auto;
}

.cart-dropdown-header {
    display:flex;
    justify-content:space-between;
    padding-bottom:12px;
    border-bottom:1px solid var(--border);
    font-size:15px;
    font-weight:800;
}

.cart-dropdown-item {
    padding:13px 0;
    border-bottom:1px solid var(--border);
    font-size:12px;
}

.cart-dropdown-item strong {
    display:block;
    margin-bottom:5px;
}

.cart-dropdown-item .item-price { color:var(--muted); }

.cart-dropdown-item form {
    display:flex;
    gap:6px;
    margin-top:9px;
}

.cart-dropdown-item input {
    width:58px;
    min-width:0;
    padding:7px;
    border:1px solid var(--border);
    border-radius:6px;
}

.cart-dropdown-item button {
    border:0;
    padding:7px 9px;
    border-radius:6px;
    background:#f1f1f4;
    color:#555;
    font-size:10px;
    font-weight:700;
    cursor:pointer;
}

.cart-dropdown-item button.remove {
    background:#fff0f0;
    color:var(--primary);
}

.cart-dropdown-total {
    display:flex;
    justify-content:space-between;
    margin-top:15px;
    font-size:15px;
    font-weight:850;
}

.cart-dropdown-total span:last-child { color:var(--primary); }

.cart-dropdown-empty {
    text-align:center;
    padding:25px 10px;
    color:var(--muted);
    font-size:12px;
    line-height:1.6;
}

/* MAIN */

.container {
    width:92%;
    max-width:1380px;
    margin:30px auto 50px;
}

.hero {
    position:relative;
    overflow:hidden;
    background:linear-gradient(120deg,#b71928,#e33b3b 65%,#f05a50);
    border-radius:20px;
    padding:42px 45px;
    color:white;
    margin-bottom:30px;
    box-shadow:0 12px 30px rgba(201,35,50,.14);
}

.hero:after {
    content:"J";
    position:absolute;
    right:55px;
    top:-85px;
    font-size:290px;
    font-weight:900;
    color:rgba(255,255,255,.075);
}

.hero-content { position:relative; z-index:1; max-width:600px; }

.hero-label {
    display:inline-block;
    padding:7px 12px;
    border-radius:30px;
    background:rgba(255,255,255,.16);
    font-size:11px;
    font-weight:800;
    letter-spacing:1.4px;
    margin-bottom:15px;
}

.hero h1 {
    font-size:34px;
    line-height:1.2;
    margin:0 0 12px;
}

.hero p {
    color:rgba(255,255,255,.85);
    font-size:14px;
    line-height:1.7;
    margin:0;
}

.message,.error {
    padding:14px 17px;
    margin-bottom:17px;
    border-radius:10px;
    font-size:13px;
}

.message {
    background:#eaf9ef;
    color:#176b37;
    border:1px solid #ccebd5;
}

.error {
    background:#fff0f0;
    color:#a00000;
    border:1px solid #ffd6d6;
}

/* SEARCH */

.search-section { margin-bottom:27px; }

.section-heading {
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    margin-bottom:13px;
}

.section-heading h2 {
    font-size:21px;
    margin:0;
}

.section-heading p {
    margin:0;
    color:var(--muted);
    font-size:12px;
}

.search-bar {
    display:flex;
    gap:11px;
    background:white;
    padding:12px;
    border-radius:13px;
    border:1px solid var(--border);
}

.search-bar input,.search-bar select {
    padding:13px 14px;
    border:1px solid #e7e7eb;
    border-radius:9px;
    font-size:13px;
    background:white;
}

.search-bar input { flex:1; min-width:0; }
.search-bar select { min-width:175px; }

/* BUTTONS */

.btn {
    display:inline-block;
    padding:12px 18px;
    border:0;
    border-radius:9px;
    background:var(--primary);
    color:white;
    font-size:13px;
    font-weight:750;
    cursor:pointer;
    transition:.2s;
}

.btn:hover { background:var(--primary-dark); }

.btn:disabled {
    opacity:.45;
    cursor:not-allowed;
}

/* PRODUCTS */

.products-grid {
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(190px,1fr));
    gap:18px;
}

.product-card {
    background:white;
    border:1px solid var(--border);
    border-radius:15px;
    overflow:hidden;
    transition:.25s;
}

.product-card:hover {
    transform:translateY(-5px);
    box-shadow:0 13px 28px rgba(0,0,0,.075);
    border-color:#f1c8cc;
}

.product-image,.no-image {
    width:100%;
    height:185px;
    object-fit:contain;
    background:#fafafa;
    padding:16px;
}

.no-image {
    display:flex;
    align-items:center;
    justify-content:center;
    color:#aaa;
    font-size:12px;
}

.product-info { padding:16px; }

.product-info h3 {
    margin:0 0 8px;
    font-size:15px;
    line-height:1.45;
    min-height:42px;
}

.category { color:var(--muted); font-size:11px; }

.price {
    color:var(--primary);
    font-weight:850;
    font-size:21px;
    margin:13px 0 6px;
}

.stock {
    color:var(--muted);
    font-size:11px;
    margin-bottom:14px;
}

.product-info form button { width:100%; }

.footer {
    border-top:1px solid var(--border);
    background:white;
    padding:22px 5%;
    text-align:center;
    color:#999;
    font-size:11px;
}

@media(max-width:950px) {
    .products-grid {
        grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
    }
}

@media(max-width:600px) {
    .navbar { padding:9px 4%; gap:8px; }
    .logo img { width:105px; }
    .nav-right { gap:9px; font-size:10px; }
    .request-link { padding:7px 8px; }
    .cart-menu summary { padding:8px 10px; }
    .cart-dropdown { right:-5px; width:320px; }
    .container { width:94%; margin:20px auto 35px; }
    .hero { padding:30px 23px; border-radius:15px; }
    .hero h1 { font-size:26px; }
    .hero p { font-size:12px; }
    .hero:after { right:-5px; font-size:190px; }
    .search-bar { flex-wrap:wrap; }
    .search-bar input,.search-bar select,.search-bar button { width:100%; }
    .products-grid { grid-template-columns:repeat(2,minmax(0,1fr)); gap:11px; }
    .product-image,.no-image { height:135px; }
    .product-info { padding:11px; }
    .product-info h3 { font-size:13px; min-height:38px; }
    .price { font-size:18px; }
    .product-info .btn { padding:10px 7px; font-size:11px; }
    .section-heading h2 { font-size:18px; }
}

@media(max-width:380px) {
    .nav-right { gap:7px; }
    .customer-greeting { display:none; }
    .products-grid { gap:8px; }
    .nav-right>a { font-size:9px; }
}
</style>
</head>

<body>

<header class="navbar">

    <a href="customer_shop.php" class="logo">
        <img src="assets/jobili-logo.png" alt="JOBILI Logo">
    </a>

    <div class="nav-right">

        <span class="customer-greeting">
            Hello, <?= e($customerName) ?>!
        </span>

        <!-- NOTIFICATIONS -->

        <details class="notification-menu" id="notificationMenu">
            <summary>
                🔔 Notifications
                <span class="notification-count"
                    id="notificationCount"
                    style="<?= $notificationCount > 0 ? '' : 'display:none;' ?>">
                    <?= $notificationCount ?>
                </span>
            </summary>

            <div class="notification-dropdown">

                <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
                    <strong>Order Updates</strong>
                    <button type="button" id="markAllRead"
                        style="border:0;background:none;color:#d62828;font-size:11px;font-weight:700;cursor:pointer;">
                        Mark All as Read
                    </button>
                </div>

                <form id="notificationReadForm" style="display:none;">
                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="mark_notifications_read">
                </form>

                <?php if (!$notifications): ?>
                    <p class="notification-empty">No order updates yet.</p>
                <?php else: ?>

                    <?php foreach ($notifications as $notification): ?>
                        <a href="customer_orders.php"
                           class="notification-item <?= !(int)$notification['is_read'] ? 'unread' : '' ?>">

                            <div style="display:flex;justify-content:space-between;gap:8px;">
                                <strong><?= e($notification['order_number']) ?></strong>

                                <?php if (!(int)$notification['is_read']): ?>
                                    <span class="new-label">NEW</span>
                                <?php endif; ?>
                            </div>

                            <?php
                            switch ($notification['order_status']) {
                                case 'Preparing':
                                    echo 'Your order has been approved and is being prepared.';
                                    break;
                                case 'Ready for Pickup':
                                    echo 'Your order is ready for pickup!';
                                    break;
                                case 'Completed':
                                    echo 'Your order has been completed.';
                                    break;
                                case 'Cancelled':
                                    echo 'Your order has been cancelled.';
                                    break;
                            }
                            ?>

                            <br>
                            <small><?= date('M j, Y g:i A', strtotime($notification['created_at'])) ?></small>
                        </a>
                    <?php endforeach; ?>

                <?php endif; ?>

                <a href="customer_orders.php"
                   style="display:block;margin-top:12px;color:#d62828;font-weight:700;">
                    View My Orders →
                </a>
            </div>
        </details>

        <!-- PRODUCT REQUEST -->

        <a href="customer_product_request.php" class="request-link">
            + Request a Product
        </a>

        <!-- CART -->

        <details class="cart-menu">
            <summary>
                🛒 Cart
                <span class="cart-count"><?= $cartCount ?></span>
            </summary>

            <div class="cart-dropdown">

                <div class="cart-dropdown-header">
                    <span>Shopping Cart</span>
                    <span><?= $cartCount ?> item(s)</span>
                </div>

                <?php if (!$cartItems): ?>

                    <div class="cart-dropdown-empty">
                        <div style="font-size:30px;margin-bottom:8px;">🛒</div>
                        Your cart is currently empty.
                        <br>
                        Add products to get started!
                    </div>

                <?php else: ?>

                    <?php foreach ($cartItems as $item): ?>
                        <div class="cart-dropdown-item">

                            <strong><?= e($item['name']) ?></strong>

                            <div class="item-price"><?= money($item['price']) ?> each</div>

                            <form method="POST">
                                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="product_id" value="<?= (int)$item['id'] ?>">

                                <input type="number" name="quantity"
                                    min="0" max="<?= (int)$item['stock'] ?>"
                                    value="<?= (int)$item['quantity'] ?>" required>

                                <button type="submit" name="action" value="update">Update</button>
                                <button type="submit" name="action" value="remove" class="remove">Remove</button>
                            </form>

                            <div style="margin-top:8px;text-align:right;">
                                Subtotal: <strong><?= money($item['subtotal']) ?></strong>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <div class="cart-dropdown-total">
                        <span>Total</span>
                        <span><?= money($cartTotal) ?></span>
                    </div>

                    <a href="customer_checkout.php" class="btn"
                       style="display:block;margin-top:14px;text-align:center;color:black;">
                        Proceed to Checkout →
                    </a>

                <?php endif; ?>
            </div>
        </details>

        <a href="customer_orders.php">My Orders</a>
        <a href="customer_logout.php">Logout</a>

    </div>
</header>

<main class="container">

    <section class="hero">
        <div class="hero-content">
            <span class="hero-label">WELCOME TO JOBILI</span>
            <h1>
                Hello, <?= e($customerName) ?>!
                <br>
                Happy Shopping!
            </h1>
            <p>
                Discover our available products and enjoy a convenient
                online shopping experience with Jobili.
            </p>
        </div>
    </section>

    <?php if ($success): ?>
        <div class="message"><?= e($success) ?></div>
    <?php endif; ?>

    <?php foreach ($errors as $error): ?>
        <div class="error"><?= e($error) ?></div>
    <?php endforeach; ?>

    <section class="search-section">

        <div class="section-heading">
            <div>
                <h2>Find Your Products</h2>
                <p>Search by product name or SKU.</p>
            </div>
        </div>

        <form method="GET" class="search-bar">

            <input type="text" name="q"
                placeholder="Search products..."
                value="<?= e($q) ?>">

            <select name="category">
                <option value="0">All Categories</option>

                <?php foreach ($categories as $category): ?>
                    <option value="<?= (int)$category['id'] ?>"
                        <?= $categoryId === (int)$category['id'] ? 'selected' : '' ?>>
                        <?= e($category['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button class="btn" type="submit">Search Products</button>
        </form>
    </section>

    <section class="products-section">

        <div class="section-heading">
            <div>
                <h2>Our Products</h2>
                <p><?= count($products) ?> product(s) available in this listing</p>
            </div>
        </div>

        <div class="products-grid">

            <?php if (!$products): ?>
                <div>No products found. Try another search or category.</div>
            <?php endif; ?>

            <?php foreach ($products as $product): ?>

                <?php
                $imageFile = basename((string)($product['image'] ?? ''));
                $imagePath = 'uploads/products/' . rawurlencode($imageFile);

                $imageExists = $imageFile !== ''
                    && is_file(__DIR__ . '/uploads/products/' . $imageFile);
                ?>

                <article class="product-card">

                    <?php if ($imageExists): ?>
                        <img class="product-image"
                            src="<?= e($imagePath) ?>"
                            alt="<?= e($product['name']) ?>">
                    <?php else: ?>
                        <div class="no-image">No image available</div>
                    <?php endif; ?>

                    <div class="product-info">

                        <h3><?= e($product['name']) ?></h3>

                        <div class="category">
                            <?= e($product['category_name'] ?? 'Uncategorized') ?>
                        </div>

                        <div class="price"><?= money($product['price']) ?></div>

                        <div class="stock">
                            <?php if ((int)$product['stock'] > 0): ?>
                                <?= (int)$product['stock'] ?> available
                            <?php else: ?>
                                Out of stock
                            <?php endif; ?>
                        </div>

                        <!-- ADD TO CART -->

                        <form method="POST">
                            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                            <input type="hidden" name="action" value="add">
                            <input type="hidden" name="product_id"
                                value="<?= (int)$product['id'] ?>">

                            <button class="btn" type="submit"
                                <?= (int)$product['stock'] <= 0 ? 'disabled' : '' ?>>
                                + Add to Cart
                            </button>
                        </form>

                    </div>
                </article>

            <?php endforeach; ?>

        </div>
    </section>

</main>

<footer class="footer">
    © <?= date('Y') ?> JOBILI. All rights reserved.
    <br>
    Your convenient online shopping experience.
</footer>

<script>
const notificationMenu = document.getElementById('notificationMenu');
const notificationForm = document.getElementById('notificationReadForm');
const notificationCount = document.getElementById('notificationCount');
const markAllReadButton = document.getElementById('markAllRead');

let notificationRequestRunning = false;

async function markNotificationsRead() {

    if (notificationRequestRunning || !notificationForm) {
        return;
    }

    notificationRequestRunning = true;

    try {
        const formData = new FormData(notificationForm);

        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error('Notification request failed.');
        }

        const result = await response.json();

        if (result.success) {

            document.querySelectorAll('.notification-item.unread').forEach(item => {
                item.classList.remove('unread');

                const newLabel = item.querySelector('.new-label');

                if (newLabel) {
                    newLabel.remove();
                }
            });

            if (notificationCount) {
                notificationCount.style.display = 'none';
            }
        }

    } catch (error) {
        console.error('Unable to update notifications:', error);
    } finally {
        notificationRequestRunning = false;
    }
}

notificationMenu.addEventListener('toggle', function () {
    if (notificationMenu.open) {
        markNotificationsRead();
    }
});

markAllReadButton.addEventListener('click', markNotificationsRead);
</script>

</body>
</html>
