
<?php
require __DIR__ . '/config.php';

date_default_timezone_set('Asia/Manila');

require_login();

$pdo = db();

/* DASHBOARD STATISTICS */

$todaySales = (float)$pdo->query("
    SELECT COALESCE(SUM(total), 0)
    FROM sales
    WHERE DATE(created_at) = CURDATE()
    AND status <> 'void'
")->fetchColumn();

$todayProfit = (float)$pdo->query("
    SELECT COALESCE(
        SUM(si.quantity * (si.unit_price - si.unit_cost)), 0
    )
    FROM sale_items si
    JOIN sales s ON s.id = si.sale_id
    WHERE DATE(s.created_at) = CURDATE()
    AND s.status <> 'void'
")->fetchColumn();

$todayExpenses = (float)$pdo->query("
    SELECT COALESCE(SUM(amount), 0)
    FROM expenses
    WHERE expense_date = CURDATE()
")->fetchColumn();

$totalOutstanding = (float)$pdo->query("
    SELECT COALESCE(
        SUM(GREATEST(total - amount_paid, 0)), 0
    )
    FROM sales
    WHERE status <> 'void'
    AND (status = 'utang' OR payment_method = 'utang')
    AND total > amount_paid
")->fetchColumn();

$customersWithDebt = (int)$pdo->query("
    SELECT COUNT(DISTINCT customer_id)
    FROM sales
    WHERE customer_id IS NOT NULL
    AND status <> 'void'
    AND (status = 'utang' OR payment_method = 'utang')
    AND total > amount_paid
")->fetchColumn();

$productCount = (int)$pdo->query("
    SELECT COUNT(*)
    FROM products
    WHERE active = 1
")->fetchColumn();

$lowStock = $pdo->query("
    SELECT name, stock, reorder_level
    FROM products
    WHERE active = 1
    AND stock <= reorder_level
    ORDER BY stock ASC
    LIMIT 8
")->fetchAll();

$recent = $pdo->query("
    SELECT
        s.id,
        s.receipt_no,
        s.total,
        s.status,
        s.payment_method,
        s.created_at,
        COALESCE(c.name, 'Walk-in') AS customer
    FROM sales s
    LEFT JOIN customers c ON c.id = s.customer_id
    WHERE s.status <> 'void'
    ORDER BY s.id DESC
    LIMIT 6
")->fetchAll();

/* SEVEN-DAY SALES */

$week = $pdo->query("
    SELECT
        DATE(created_at) AS day,
        COALESCE(SUM(total), 0) AS total
    FROM sales
    WHERE created_at >= CURDATE() - INTERVAL 6 DAY
    AND status <> 'void'
    GROUP BY DATE(created_at)
")->fetchAll();

$weekMap = [];

foreach ($week as $w) {
    $weekMap[$w['day']] = (float)$w['total'];
}

$chartMax = max(array_merge([1], array_values($weekMap)));

/* PRODUCT REQUEST NOTIFICATION */

$pendingProductRequests = 0;

try {
    $pendingProductRequests = (int)$pdo->query("
        SELECT COUNT(*)
        FROM customer_product_requests
        WHERE status = 'Pending'
    ")->fetchColumn();
} catch (Throwable $e) {
    error_log('Product request dashboard count error: ' . $e->getMessage());
}

$pageTitle = 'Dashboard';
require __DIR__ . '/partials/header.php';
?>

<style>
.dash-premium {
    display: flex;
    flex-direction: column;
    gap: 23px;
    padding-bottom: 30px;
    color: #172033;
}

/* WELCOME HEADER */

.dp-welcome {
    position: relative;
    overflow: hidden;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 22px;
    padding: 27px 29px;
    border-radius: 16px;
    background: linear-gradient(120deg, #7f1d1d, #b91c1c, #dc2626);
    color: white;
    box-shadow: 0 8px 22px rgba(185, 28, 28, .15);
}

.dp-welcome::after {
    content: "";
    position: absolute;
    width: 240px;
    height: 240px;
    border: 35px solid rgba(255,255,255,.06);
    border-radius: 50%;
    right: 100px;
    top: -145px;
    pointer-events: none;
}

.dp-welcome-content {
    position: relative;
    z-index: 1;
}

.dp-eyebrow {
    display: block;
    color: #fecaca;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1.5px;
    margin-bottom: 10px;
}

.dp-welcome h1 {
    color: #fff;
    font-size: 25px;
    font-weight: 800;
    letter-spacing: -.7px;
    margin: 0 0 8px;
}

.dp-welcome p {
    color: #fee2e2;
    font-size: 12px;
    margin: 0;
}

.dp-welcome-right {
    position: relative;
    z-index: 2;
    display: flex;
    align-items: center;
    gap: 14px;
}

.dp-date-card {
    width: 82px;
    height: 88px;
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,.12);
}

.dp-date-day {
    color: #b91c1c;
    font-size: 31px;
    line-height: 1;
    font-weight: 900;
}

.dp-date-month {
    color: #374151;
    font-size: 11px;
    font-weight: 900;
    letter-spacing: 1px;
    margin-top: 5px;
}

.dp-date-year {
    color: #9ca3af;
    font-size: 9px;
    font-weight: 700;
    margin-top: 3px;
}

.dp-welcome-action {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    padding: 12px 17px;
    border-radius: 9px;
    background: #fff;
    color: #991b1b;
    font-size: 12px;
    font-weight: 800;
    text-decoration: none;
    white-space: nowrap;
    transition: .2s;
}

.dp-welcome-action:hover {
    background: #fee2e2;
    transform: translateY(-2px);
}

/* STATISTICS */

.dp-stats {
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
    gap: 15px;
}

.dp-stat {
    min-width: 0;
    padding: 19px;
    background: #fff;
    border: 1px solid #e9edf3;
    border-radius: 13px;
    box-shadow: 0 3px 12px rgba(15, 23, 42, .035);
    transition: .2s;
}

.dp-stat:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 20px rgba(15, 23, 42, .07);
}

.dp-stat-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 7px;
    margin-bottom: 17px;
}

.dp-stat-label {
    color: #78869a;
    font-size: 11px;
    font-weight: 750;
}

.dp-stat-icon {
    width: 34px;
    height: 34px;
    flex-shrink: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 9px;
    font-size: 16px;
    font-weight: 800;
}

.dp-blue { background: #fff1f2; color: #dc2626; }
.dp-green { background: #ecfdf5; color: #059669; }
.dp-amber { background: #fffbeb; color: #d97706; }
.dp-purple { background: #f5f3ff; color: #7c3aed; }
.dp-red { background: #fee2e2; color: #b91c1c; }

.dp-stat strong {
    display: block;
    font-size: clamp(19px, 2vw, 25px);
    color: #172033;
    font-weight: 850;
    letter-spacing: -.8px;
    overflow-wrap: anywhere;
}

.dp-stat small {
    display: block;
    margin-top: 8px;
    color: #98a2b3;
    font-size: 10px;
    line-height: 1.5;
}

/* DASHBOARD GRID */

.dp-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.55fr) minmax(280px, 1fr);
    gap: 18px;
    align-items: stretch;
}

.dp-panel {
    min-width: 0;
    background: #fff;
    border: 1px solid #e9edf3;
    border-radius: 14px;
    padding: 21px;
    box-shadow: 0 3px 12px rgba(15, 23, 42, .035);
}

.dp-panel-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin-bottom: 20px;
}

.dp-panel-heading h2 {
    margin: 0;
    color: #172033;
    font-size: 15px;
    font-weight: 800;
}

.dp-panel-heading p {
    margin: 6px 0 0;
    color: #98a2b3;
    font-size: 11px;
}

.dp-panel-link {
    color: #dc2626;
    font-size: 11px;
    font-weight: 750;
    text-decoration: none;
    white-space: nowrap;
}

.dp-panel-link:hover {
    color: #991b1b;
}

/* SALES CHART */

.dp-chart {
    display: flex;
    align-items: flex-end;
    justify-content: space-around;
    gap: 12px;
    height: 220px;
    padding: 10px 4px 0;
}

.dp-chart-column {
    flex: 1;
    min-width: 0;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    align-items: center;
    gap: 8px;
}

.dp-chart-value {
    color: #64748b;
    font-size: 9px;
    font-weight: 700;
    white-space: nowrap;
}

.dp-chart-track {
    height: 150px;
    width: min(100%, 39px);
    display: flex;
    align-items: flex-end;
    border-radius: 7px;
    background: #f1f5f9;
    overflow: hidden;
}

.dp-chart-bar {
    width: 100%;
    min-height: 3px;
    border-radius: 7px 7px 3px 3px;
    background: linear-gradient(180deg, #f87171, #b91c1c);
    transition: height .3s;
}

.dp-chart-day {
    color: #8995a7;
    font-size: 10px;
    font-weight: 700;
}

/* QUICK ACTIONS */

.dp-actions {
    display: flex;
    flex-direction: column;
    gap: 9px;
}

.dp-action {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 11px;
    border: 1px solid #edf0f4;
    border-radius: 10px;
    text-decoration: none;
    transition: .2s;
}

.dp-action:hover {
    background: #fff7f7;
    border-color: #fecaca;
    transform: translateX(2px);
}

.dp-action-icon {
    width: 38px;
    height: 38px;
    flex-shrink: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 10px;
    background: #fff1f2;
    color: #dc2626;
    font-size: 17px;
    font-weight: 800;
}

.dp-action-icon.gray { background: #f1f5f9; color: #475569; }
.dp-action-icon.green { background: #ecfdf5; color: #059669; }
.dp-action-icon.amber { background: #fffbeb; color: #d97706; }
.dp-action-icon.purple { background: #f5f3ff; color: #7c3aed; }

.dp-action-info {
    flex: 1;
    min-width: 0;
}

.dp-action-info b {
    display: block;
    color: #27364c;
    font-size: 11px;
    font-weight: 800;
}

.dp-action-info small {
    display: block;
    margin-top: 4px;
    color: #98a2b3;
    font-size: 10px;
}

.dp-action-arrow {
    color: #94a3b8;
    font-size: 18px;
}

.dp-action-badge {
    min-width: 20px;
    padding: 3px 7px;
    border-radius: 20px;
    background: #fee2e2;
    color: #dc2626;
    font-size: 10px;
    font-weight: 800;
    text-align: center;
}

.dp-system {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 16px;
    padding: 12px 13px;
    border-radius: 9px;
    background: #f8fafc;
    color: #64748b;
    font-size: 10px;
}

.dp-system strong {
    color: #059669;
    font-size: 10px;
}

/* TABLE */

.dp-table-wrap {
    width: 100%;
    overflow-x: auto;
}

.dp-table {
    width: 100%;
    min-width: 520px;
    border-collapse: separate;
    border-spacing: 0;
}

.dp-table th {
    padding: 12px 11px;
    text-align: left;
    background: #f8fafc;
    color: #8793a5;
    font-size: 9px;
    font-weight: 800;
    letter-spacing: .6px;
    text-transform: uppercase;
    border-top: 1px solid #edf0f4;
    border-bottom: 1px solid #edf0f4;
    white-space: nowrap;
}

.dp-table td {
    padding: 14px 11px;
    color: #475569;
    font-size: 11px;
    border-bottom: 1px solid #f0f2f5;
    vertical-align: middle;
}

.dp-table tbody tr:hover {
    background: #fffafa;
}

.dp-receipt {
    display: block;
    color: #253750;
    font-weight: 800;
}

.dp-subtext {
    display: block;
    color: #98a2b3;
    font-size: 9px;
    margin-top: 5px;
}

.dp-pill {
    display: inline-flex;
    align-items: center;
    padding: 6px 9px;
    border-radius: 20px;
    font-size: 9px;
    font-weight: 800;
    white-space: nowrap;
}

.dp-pill-paid,
.dp-pill-completed {
    background: #ecfdf5;
    color: #059669;
}

.dp-pill-utang {
    background: #fffbeb;
    color: #b45309;
}

.dp-pill-other {
    background: #fff1f2;
    color: #dc2626;
}

/* LOW STOCK */

.dp-stock-list {
    display: flex;
    flex-direction: column;
}

.dp-stock-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    padding: 13px 0;
    border-bottom: 1px solid #f0f2f5;
}

.dp-stock-item:last-child {
    border-bottom: 0;
}

.dp-stock-name {
    display: block;
    color: #334155;
    font-size: 11px;
    font-weight: 750;
}

.dp-stock-reorder {
    display: block;
    margin-top: 5px;
    color: #98a2b3;
    font-size: 10px;
}

.dp-stock-count {
    padding: 6px 9px;
    border-radius: 7px;
    background: #fff1f2;
    color: #dc2626;
    font-size: 10px;
    font-weight: 800;
    white-space: nowrap;
}

.dp-empty {
    padding: 28px 12px;
    color: #98a2b3;
    text-align: center;
    font-size: 11px;
    line-height: 1.7;
}

/* RESPONSIVE */

@media (max-width: 1250px) {
    .dp-stats {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }
}

@media (max-width: 950px) {
    .dp-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 650px) {
    .dash-premium {
        gap: 15px;
    }

    .dp-welcome {
        align-items: flex-start;
        flex-direction: column;
        padding: 21px;
    }

    .dp-welcome-right {
        width: 100%;
        justify-content: space-between;
    }

    .dp-welcome h1 {
        font-size: 21px;
    }

    .dp-stats {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
    }

    .dp-stat {
        padding: 14px;
    }

    .dp-stat strong {
        font-size: 19px;
    }

    .dp-stat-label {
        font-size: 10px;
    }

    .dp-panel {
        padding: 15px;
    }

    .dp-chart {
        gap: 6px;
        height: 190px;
    }

    .dp-chart-value {
        font-size: 8px;
    }
}
</style>

<div class="dash-premium">

    <!-- WELCOME HEADER -->

    <section class="dp-welcome">

        <div class="dp-welcome-content">
            <span class="dp-eyebrow">JOBILI STORE OVERVIEW</span>

            <h1>
                Welcome back, <?= e(ucfirst(current_user()['role'] ?? 'Owner')) ?>!
            </h1>

            <p>
                Here's what's happening with your store today.
            </p>
        </div>

        <div class="dp-welcome-right">

            <div class="dp-date-card">
                <span class="dp-date-day"><?= date('d') ?></span>
                <span class="dp-date-month"><?= strtoupper(date('M')) ?></span>
                <span class="dp-date-year"><?= date('Y') ?></span>
            </div>

            <a href="pos.php" class="dp-welcome-action">
                ▣ Open POS Register →
            </a>

        </div>

    </section>

    <!-- STATISTICS -->

    <section class="dp-stats">

        <article class="dp-stat">
            <div class="dp-stat-head">
                <span class="dp-stat-label">Today's Sales</span>
                <span class="dp-stat-icon dp-blue">₱</span>
            </div>
            <strong><?= money($todaySales) ?></strong>
            <small>Completed and utang sales</small>
        </article>

        <article class="dp-stat">
            <div class="dp-stat-head">
                <span class="dp-stat-label">Estimated Gross Profit</span>
                <span class="dp-stat-icon dp-green">↗</span>
            </div>
            <strong><?= money($todayProfit) ?></strong>
            <small>Before operating expenses</small>
        </article>

        <article class="dp-stat">
            <div class="dp-stat-head">
                <span class="dp-stat-label">Today's Expenses</span>
                <span class="dp-stat-icon dp-amber">−</span>
            </div>
            <strong><?= money($todayExpenses) ?></strong>
            <small>Recorded expenses today</small>
        </article>

        <article class="dp-stat">
            <div class="dp-stat-head">
                <span class="dp-stat-label">Outstanding Utang</span>
                <span class="dp-stat-icon dp-red">₱</span>
            </div>
            <strong><?= money($totalOutstanding) ?></strong>
            <small><?= number_format($customersWithDebt) ?> customers with unpaid balances</small>
        </article>

        <article class="dp-stat">
            <div class="dp-stat-head">
                <span class="dp-stat-label">Active Products</span>
                <span class="dp-stat-icon dp-purple">▤</span>
            </div>
            <strong><?= number_format($productCount) ?></strong>
            <small><?= count($lowStock) ?> low-stock items shown</small>
        </article>

    </section>

    <!-- SALES CHART AND QUICK ACTIONS -->

    <section class="dp-grid">

        <article class="dp-panel">

            <div class="dp-panel-heading">
                <div>
                    <h2>7-Day Sales Performance</h2>
                    <p>Daily sales totals for the last seven days</p>
                </div>

                <a href="reports.php" class="dp-panel-link">
                    Full Reports →
                </a>
            </div>

            <div class="dp-chart">

                <?php for ($i = 6; $i >= 0; $i--): ?>

                    <?php
                    $day = date('Y-m-d', strtotime("-$i days"));
                    $value = $weekMap[$day] ?? 0;
                    $height = $value > 0
                        ? max(5, ($value / $chartMax) * 100)
                        : 3;
                    ?>

                    <div class="dp-chart-column">

                        <strong class="dp-chart-value">
                            <?= $value > 0 ? money($value) : '—' ?>
                        </strong>

                        <div class="dp-chart-track">
                            <div
                                class="dp-chart-bar"
                                style="height: <?= $height ?>%;"
                                title="<?= e(date('M j', strtotime($day))) ?>: <?= e(money($value)) ?>"
                            ></div>
                        </div>

                        <small class="dp-chart-day">
                            <?= e(date('D', strtotime($day))) ?>
                        </small>

                    </div>

                <?php endfor; ?>

            </div>

        </article>

        <!-- QUICK ACTIONS -->

        <article class="dp-panel">

            <div class="dp-panel-heading">
                <div>
                    <h2>Quick Store Actions</h2>
                    <p>Shortcuts to manage daily operations</p>
                </div>
            </div>

            <div class="dp-actions">

                <a href="pos.php" class="dp-action">
                    <span class="dp-action-icon">▣</span>
                    <span class="dp-action-info">
                        <b>New Sale (POS)</b>
                        <small>Record a customer purchase</small>
                    </span>
                    <span class="dp-action-arrow">›</span>
                </a>

                <a href="products.php" class="dp-action">
                    <span class="dp-action-icon gray">▤</span>
                    <span class="dp-action-info">
                        <b>Stock & Inventory</b>
                        <small>Add products or adjust stock</small>
                    </span>
                    <span class="dp-action-arrow">›</span>
                </a>

                <a href="customers.php" class="dp-action">
                    <span class="dp-action-icon green">♙</span>
                    <span class="dp-action-info">
                        <b>Customers & Utang</b>
                        <small>Track balances and payments</small>
                    </span>
                    <span class="dp-action-arrow">›</span>
                </a>

                <a href="expenses.php" class="dp-action">
                    <span class="dp-action-icon amber">₱</span>
                    <span class="dp-action-info">
                        <b>Record Expense</b>
                        <small>Log bills, supplies, and fare</small>
                    </span>
                    <span class="dp-action-arrow">›</span>
                </a>

                <a href="product_requests.php" class="dp-action">
                    <span class="dp-action-icon purple">▧</span>
                    <span class="dp-action-info">
                        <b>Product Requests</b>
                        <small>See what customers want to buy</small>
                    </span>

                    <?php if ($pendingProductRequests > 0): ?>
                        <span class="dp-action-badge">
                            <?= $pendingProductRequests > 99 ? '99+' : $pendingProductRequests ?>
                        </span>
                    <?php endif; ?>

                    <span class="dp-action-arrow">›</span>
                </a>

            </div>

            <div class="dp-system">
                <span>System status</span>
                <strong>● Ready</strong>
            </div>

        </article>

    </section>

    <!-- RECENT TRANSACTIONS AND LOW STOCK -->

    <section class="dp-grid">

        <article class="dp-panel">

            <div class="dp-panel-heading">
                <div>
                    <h2>Recent Transactions</h2>
                    <p>Latest store sales and activity</p>
                </div>

                <a href="reports.php" class="dp-panel-link">
                    View All →
                </a>
            </div>

            <div class="dp-table-wrap">

                <table class="dp-table">

                    <thead>
                        <tr>
                            <th>Receipt</th>
                            <th>Customer</th>
                            <th>Total</th>
                            <th>Payment</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php if (!$recent): ?>

                            <tr>
                                <td colspan="5" class="dp-empty">
                                    No sales yet.<br>
                                    Start by creating a new sale.
                                </td>
                            </tr>

                        <?php else: ?>

                            <?php foreach ($recent as $r): ?>

                                <?php
                                $status = strtolower($r['status']);
                                $pillClass = 'dp-pill-other';

                                if ($status === 'paid' || $status === 'completed') {
                                    $pillClass = 'dp-pill-paid';
                                } elseif ($status === 'utang') {
                                    $pillClass = 'dp-pill-utang';
                                }
                                ?>

                                <tr>

                                    <td>
                                        <span class="dp-receipt">
                                            <?= e($r['receipt_no']) ?>
                                        </span>

                                        <small class="dp-subtext">
                                            <?= e(date('M j, g:i A', strtotime($r['created_at']))) ?>
                                        </small>
                                    </td>

                                    <td>
                                        <?= e($r['customer']) ?>
                                    </td>

                                    <td>
                                        <strong><?= money($r['total']) ?></strong>
                                    </td>

                                    <td>
                                        <?= e(strtoupper($r['payment_method'])) ?>
                                    </td>

                                    <td>
                                        <span class="dp-pill <?= $pillClass ?>">
                                            <?= e(ucfirst($r['status'])) ?>
                                        </span>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </article>

        <!-- LOW STOCK -->

        <article class="dp-panel">

            <div class="dp-panel-heading">
                <div>
                    <h2>Low Stock Alerts</h2>
                    <p>Products that need restocking</p>
                </div>

                <a href="products.php" class="dp-panel-link">
                    Inventory →
                </a>
            </div>

            <?php if (!$lowStock): ?>

                <div class="dp-empty">
                    ✓ All listed products are above their reorder levels.
                </div>

            <?php else: ?>

                <div class="dp-stock-list">

                    <?php foreach ($lowStock as $p): ?>

                        <div class="dp-stock-item">

                            <span>
                                <b class="dp-stock-name">
                                    <?= e($p['name']) ?>
                                </b>

                                <small class="dp-stock-reorder">
                                    Reorder level: <?= e($p['reorder_level']) ?>
                                </small>
                            </span>

                            <span class="dp-stock-count">
                                <?= e($p['stock']) ?> left
                            </span>

                        </div>

                    <?php endforeach; ?>

                </div>

            <?php endif; ?>

        </article>

    </section>

</div>

<?php require __DIR__ . '/partials/footer.php'; ?>
