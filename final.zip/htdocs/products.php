
<?php
require __DIR__ . '/config.php';
require_login();

$pdo = db();

/* =====================================================
   HELPERS
===================================================== */

function product_redirect(): void {
    redirect('products.php');
}

function product_image_path(?string $filename): ?string {
    if (!$filename) return null;

    $filename = basename($filename);
    $path = __DIR__ . '/uploads/products/' . $filename;

    return is_file($path) ? 'uploads/products/' . $filename : null;
}

/* =====================================================
   HANDLE POST ACTIONS
===================================================== */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $action = $_POST['action'] ?? '';
    $newImagePath = null;
    $oldImagePath = null;

    try {

        /* SAVE PRODUCT */

        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);

            $name = trim($_POST['name'] ?? '');
            $sku = trim($_POST['sku'] ?? '') ?: null;
            $categoryId = (int)($_POST['category_id'] ?? 0) ?: null;

            $price = (float)($_POST['price'] ?? 0);
            $cost = (float)($_POST['cost'] ?? 0);
            $stock = (int)($_POST['stock'] ?? 0);
            $reorder = (int)($_POST['reorder_level'] ?? 5);

            if (
                $name === '' ||
                $price < 0 ||
                $cost < 0 ||
                $stock < 0 ||
                $reorder < 0
            ) {
                throw new RuntimeException('Please enter valid product details.');
            }

            /* CHECK EXISTING PRODUCT */

            $existing = null;

            if ($id > 0) {
                $check = $pdo->prepare('SELECT * FROM products WHERE id = ?');
                $check->execute([$id]);
                $existing = $check->fetch();

                if (!$existing) {
                    throw new RuntimeException('Product not found.');
                }

                $oldImagePath = $existing['image']
                    ? __DIR__ . '/uploads/products/' . basename($existing['image'])
                    : null;
            }

            /* IMAGE UPLOAD */

            $imageName = $existing['image'] ?? null;

            if (
                isset($_FILES['image']) &&
                $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE
            ) {
                if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
                    throw new RuntimeException('Image upload failed.');
                }

                if ($_FILES['image']['size'] > 2 * 1024 * 1024) {
                    throw new RuntimeException('Image must not exceed 2MB.');
                }

                $tmp = $_FILES['image']['tmp_name'];

                $imageInfo = getimagesize($tmp);

                $allowedTypes = [
                    'image/jpeg' => 'jpg',
                    'image/png' => 'png',
                    'image/webp' => 'webp'
                ];

                if (
                    !$imageInfo ||
                    !isset($allowedTypes[$imageInfo['mime']])
                ) {
                    throw new RuntimeException(
                        'Only JPG, PNG, and WEBP images are allowed.'
                    );
                }

                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $actualMime = $finfo->file($tmp);

                if ($actualMime !== $imageInfo['mime']) {
                    throw new RuntimeException('Invalid image file.');
                }

                $uploadDirectory = __DIR__ . '/uploads/products/';

                if (!is_dir($uploadDirectory)) {
                    if (!mkdir($uploadDirectory, 0755, true)) {
                        throw new RuntimeException('Upload folder is unavailable.');
                    }
                }

                $imageName = bin2hex(random_bytes(16))
                    . '.' . $allowedTypes[$imageInfo['mime']];

                $newImagePath = $uploadDirectory . $imageName;

                if (!move_uploaded_file($tmp, $newImagePath)) {
                    throw new RuntimeException('Could not save uploaded image.');
                }
            }

            /* UPDATE OR INSERT */

            if ($id > 0) {
                $st = $pdo->prepare("
                    UPDATE products
                    SET sku = ?,
                        name = ?,
                        category_id = ?,
                        price = ?,
                        cost = ?,
                        stock = ?,
                        reorder_level = ?,
                        image = ?
                    WHERE id = ?
                ");

                $st->execute([
                    $sku,
                    $name,
                    $categoryId,
                    $price,
                    $cost,
                    $stock,
                    $reorder,
                    $imageName,
                    $id
                ]);

                flash('Product updated successfully.');

            } else {
                $st = $pdo->prepare("
                    INSERT INTO products
                    (sku, name, category_id, price, cost, stock, reorder_level, image)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");

                $st->execute([
                    $sku,
                    $name,
                    $categoryId,
                    $price,
                    $cost,
                    $stock,
                    $reorder,
                    $imageName
                ]);

                flash('Product added successfully.');
            }

            /* REMOVE OLD IMAGE AFTER SUCCESSFUL UPDATE */

            if (
                $newImagePath &&
                $oldImagePath &&
                is_file($oldImagePath)
            ) {
                @unlink($oldImagePath);
            }
        }

        /* STOCK ADJUSTMENT */

        elseif ($action === 'adjust') {
            $id = (int)($_POST['id'] ?? 0);
            $change = (int)($_POST['change_qty'] ?? 0);
            $reason = trim($_POST['reason'] ?? '');

            if ($id <= 0 || $change === 0) {
                throw new RuntimeException('Enter a valid stock adjustment.');
            }

            if ($reason === '') {
                throw new RuntimeException('Please provide an adjustment reason.');
            }

            $pdo->beginTransaction();

            $st = $pdo->prepare("
                SELECT stock
                FROM products
                WHERE id = ? AND active = 1
                FOR UPDATE
            ");

            $st->execute([$id]);
            $product = $st->fetch();

            if (!$product) {
                throw new RuntimeException('Product not found.');
            }

            $newStock = (int)$product['stock'] + $change;

            if ($newStock < 0) {
                throw new RuntimeException('Stock cannot become negative.');
            }

            $update = $pdo->prepare("
                UPDATE products
                SET stock = ?
                WHERE id = ?
            ");

            $update->execute([$newStock, $id]);

            $log = $pdo->prepare("
                INSERT INTO inventory_logs
                (product_id, user_id, change_qty, reason)
                VALUES (?, ?, ?, ?)
            ");

            $log->execute([
                $id,
                current_user()['id'],
                $change,
                $reason
            ]);

            $pdo->commit();

            flash('Inventory updated successfully.');
        }

        /* ARCHIVE PRODUCT */

        elseif ($action === 'archive') {
            require_owner();

            $id = (int)($_POST['id'] ?? 0);

            $st = $pdo->prepare("
                UPDATE products
                SET active = 0
                WHERE id = ?
            ");

            $st->execute([$id]);

            flash('Product archived successfully.');
        }

    } catch (Throwable $ex) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        if ($newImagePath && is_file($newImagePath)) {
            @unlink($newImagePath);
        }

        flash($ex->getMessage(), 'error');
    }

    product_redirect();
}

/* =====================================================
   EDIT PRODUCT
===================================================== */

$edit = null;

if (isset($_GET['edit'])) {
    $st = $pdo->prepare("
        SELECT *
        FROM products
        WHERE id = ? AND active = 1
    ");

    $st->execute([(int)$_GET['edit']]);
    $edit = $st->fetch();

    if (!$edit) {
        flash('Product not found.', 'error');
        product_redirect();
    }
}

/* =====================================================
   FILTERS
===================================================== */

$categories = $pdo->query("
    SELECT *
    FROM categories
    ORDER BY name
")->fetchAll();

$q = trim($_GET['q'] ?? '');
$categoryFilter = (int)($_GET['category'] ?? 0);
$stockFilter = $_GET['stock_status'] ?? '';

$allowedStockFilters = ['in_stock', 'low_stock', 'out_of_stock'];

if (!in_array($stockFilter, $allowedStockFilters, true)) {
    $stockFilter = '';
}

/* =====================================================
   SUMMARY STATISTICS
===================================================== */

$summary = $pdo->query("
    SELECT
        COUNT(*) AS total_products,

        COALESCE(SUM(
            CASE
                WHEN stock > 0 AND stock <= reorder_level THEN 1
                ELSE 0
            END
        ), 0) AS low_stock,

        COALESCE(SUM(
            CASE
                WHEN stock = 0 THEN 1
                ELSE 0
            END
        ), 0) AS out_of_stock,

        COALESCE(SUM(stock * cost), 0) AS inventory_value

    FROM products
    WHERE active = 1
")->fetch();

/* =====================================================
   PRODUCT QUERY
===================================================== */

$where = ['p.active = 1'];
$args = [];

if ($q !== '') {
    $where[] = '(p.name LIKE ? OR p.sku LIKE ?)';
    $args[] = "%$q%";
    $args[] = "%$q%";
}

if ($categoryFilter > 0) {
    $where[] = 'p.category_id = ?';
    $args[] = $categoryFilter;
}

if ($stockFilter === 'in_stock') {
    $where[] = 'p.stock > p.reorder_level';
}

if ($stockFilter === 'low_stock') {
    $where[] = 'p.stock > 0 AND p.stock <= p.reorder_level';
}

if ($stockFilter === 'out_of_stock') {
    $where[] = 'p.stock = 0';
}

$whereSql = implode(' AND ', $where);

/* PAGINATION */

$countQuery = $pdo->prepare("
    SELECT COUNT(*)
    FROM products p
    WHERE $whereSql
");

$countQuery->execute($args);

$totalFiltered = (int)$countQuery->fetchColumn();

$perPage = 15;
$totalPages = max(1, (int)ceil($totalFiltered / $perPage));

$page = max(1, (int)($_GET['page'] ?? 1));
$page = min($page, $totalPages);

$offset = ($page - 1) * $perPage;

/* FETCH PRODUCTS */

$sql = "
    SELECT
        p.*,
        c.name AS category
    FROM products p
    LEFT JOIN categories c
        ON c.id = p.category_id
    WHERE $whereSql
    ORDER BY p.name ASC
    LIMIT $perPage OFFSET $offset
";

$st = $pdo->prepare($sql);
$st->execute($args);

$products = $st->fetchAll();

/* INVENTORY ADJUSTMENT PRODUCT OPTIONS */

$adjustProducts = $pdo->query("
    SELECT id, name, stock
    FROM products
    WHERE active = 1
    ORDER BY name
")->fetchAll();

$pageTitle = 'Products & Inventory';

require __DIR__ . '/partials/header.php';
?>

<style>
/* =====================================================
   JOBILI PRODUCT PAGE
===================================================== */

.products-page {
    --product-red: #d92d3a;
    --product-dark: #20242d;
    --product-muted: #858b98;
    --product-border: #eceef2;
    --product-bg: #f8f9fb;
    color: var(--product-dark);
}

.products-page * {
    box-sizing: border-box;
}

.products-page .product-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    margin-bottom: 23px;
}

.products-page .product-heading h1 {
    font-size: 25px;
    font-weight: 800;
    margin: 0 0 5px;
    letter-spacing: -.7px;
}

.products-page .product-heading p {
    color: var(--product-muted);
    font-size: 13px;
    margin: 0;
}

.products-page .premium-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    border: 0;
    border-radius: 9px;
    padding: 11px 16px;
    background: var(--product-red);
    color: white;
    font-size: 13px;
    font-weight: 700;
    text-decoration: none;
    cursor: pointer;
    transition: .2s;
}

.products-page .premium-btn:hover {
    background: #bd202e;
    transform: translateY(-1px);
}

.products-page .premium-btn.secondary {
    background: #f1f2f5;
    color: #303542;
}

.products-page .premium-btn.secondary:hover {
    background: #e6e8ed;
}

.products-page .summary-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 14px;
    margin-bottom: 22px;
}

.products-page .summary-card {
    background: #fff;
    border: 1px solid var(--product-border);
    border-radius: 12px;
    padding: 17px;
    min-width: 0;
}

.products-page .summary-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
}

.products-page .summary-label {
    color: var(--product-muted);
    font-size: 12px;
    font-weight: 600;
}

.products-page .summary-icon {
    width: 35px;
    height: 35px;
    display: grid;
    place-items: center;
    border-radius: 9px;
    background: #fff0f1;
    color: var(--product-red);
    font-size: 17px;
}

.products-page .summary-icon.orange {
    background: #fff5e9;
    color: #d88724;
}

.products-page .summary-icon.blue {
    background: #edf4ff;
    color: #3974c6;
}

.products-page .summary-icon.green {
    background: #eaf8f0;
    color: #25965c;
}

.products-page .summary-value {
    font-size: 25px;
    font-weight: 800;
    letter-spacing: -.7px;
    margin-top: 13px;
    line-height: 1.2;
}

.products-page .summary-note {
    color: var(--product-muted);
    font-size: 11px;
    margin-top: 5px;
}

.products-page .workspace-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.35fr) minmax(280px, .85fr);
    gap: 17px;
    align-items: start;
    margin-bottom: 20px;
}

.products-page .premium-panel {
    background: #fff;
    border: 1px solid var(--product-border);
    border-radius: 12px;
    overflow: hidden;
    min-width: 0;
}

.products-page .panel-top {
    padding: 17px 19px;
    border-bottom: 1px solid var(--product-border);
}

.products-page .panel-top h2 {
    font-size: 15px;
    font-weight: 800;
    margin: 0 0 4px;
}

.products-page .panel-top p {
    color: var(--product-muted);
    font-size: 12px;
    margin: 0;
}

.products-page .panel-content {
    padding: 19px;
}

.products-page .product-form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
}

.products-page .field {
    min-width: 0;
}

.products-page .field.full {
    grid-column: 1 / -1;
}

.products-page .field label,
.products-page .adjust-form label {
    display: block;
    font-size: 12px;
    font-weight: 700;
    margin-bottom: 7px;
    color: #424754;
}

.products-page input,
.products-page select {
    width: 100%;
    min-width: 0;
    height: 41px;
    padding: 0 11px;
    border: 1px solid #e4e6eb;
    border-radius: 8px;
    background: #fff;
    color: #282d37;
    font-size: 13px;
    outline: none;
    transition: .2s;
}

.products-page input:focus,
.products-page select:focus {
    border-color: var(--product-red);
    box-shadow: 0 0 0 3px rgba(217,45,58,.09);
}

.products-page input[type="file"] {
    height: auto;
    padding: 10px;
    background: #fafbfc;
}

.products-page .field small {
    display: block;
    color: var(--product-muted);
    font-size: 11px;
    margin-top: 6px;
}

.products-page .image-upload-box {
    border: 1px dashed #d8dce4;
    background: #fafbfc;
    border-radius: 10px;
    padding: 12px;
}

.products-page .image-preview {
    display: flex;
    align-items: center;
    gap: 13px;
    margin-bottom: 11px;
}

.products-page .image-preview img {
    width: 65px;
    height: 65px;
    object-fit: cover;
    border-radius: 9px;
    border: 1px solid #e7e9ee;
    background: white;
}

.products-page .image-preview-info {
    font-size: 12px;
    color: var(--product-muted);
}

.products-page .image-preview-info b {
    display: block;
    color: #343945;
    margin-bottom: 4px;
}

.products-page .form-buttons {
    display: flex;
    align-items: center;
    gap: 9px;
    flex-wrap: wrap;
    margin-top: 5px;
}

.products-page .adjust-form {
    display: flex;
    flex-direction: column;
    gap: 11px;
}

.products-page .stock-preview {
    border: 1px solid #eceef2;
    background: #fafbfc;
    padding: 12px;
    border-radius: 9px;
    font-size: 12px;
    color: var(--product-muted);
}

.products-page .stock-preview strong {
    color: #252a34;
    font-size: 17px;
}

.products-page .stock-preview .projected {
    color: var(--product-red);
    font-weight: 800;
}

.products-page .adjust-hint {
    background: #fff8ed;
    border: 1px solid #f6e5c8;
    color: #966b2d;
    padding: 11px;
    border-radius: 8px;
    font-size: 11px;
    line-height: 1.5;
}

.products-page .list-panel {
    margin-top: 19px;
}

.products-page .list-toolbar {
    padding: 17px 19px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
    flex-wrap: wrap;
    border-bottom: 1px solid var(--product-border);
}

.products-page .list-toolbar h2 {
    font-size: 15px;
    font-weight: 800;
    margin: 0 0 4px;
}

.products-page .list-toolbar p {
    font-size: 11px;
    color: var(--product-muted);
    margin: 0;
}

.products-page .filter-form {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    align-items: center;
}

.products-page .filter-form input {
    width: 190px;
}

.products-page .filter-form select {
    width: 145px;
}

.products-page .filter-form .premium-btn {
    height: 39px;
    padding: 0 13px;
}

.products-page .table-wrap {
    overflow-x: auto;
}

.products-page table {
    width: 100%;
    border-collapse: collapse;
    min-width: 790px;
}

.products-page th {
    text-align: left;
    color: #858b98;
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .5px;
    padding: 13px 16px;
    background: #fafbfc;
    white-space: nowrap;
}

.products-page td {
    padding: 13px 16px;
    border-top: 1px solid #f0f1f4;
    font-size: 12px;
    vertical-align: middle;
}

.products-page tbody tr:hover {
    background: #fcfcfd;
}

.products-page .product-cell {
    display: flex;
    align-items: center;
    gap: 11px;
    min-width: 175px;
}

.products-page .product-thumb {
    width: 43px;
    height: 43px;
    border-radius: 8px;
    object-fit: cover;
    border: 1px solid #eceef2;
    background: #f7f8fa;
    flex-shrink: 0;
}

.products-page .product-placeholder {
    display: grid;
    place-items: center;
    color: #a0a5af;
    font-size: 17px;
}

.products-page .product-cell b {
    display: block;
    color: #303541;
    font-size: 12px;
    margin-bottom: 4px;
}

.products-page .product-cell small {
    color: var(--product-muted);
    font-size: 10px;
}

.products-page .status-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    border-radius: 20px;
    padding: 5px 9px;
    font-size: 10px;
    font-weight: 800;
    white-space: nowrap;
}

.products-page .status-pill:before {
    content: '';
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: currentColor;
}

.products-page .status-good {
    color: #218653;
    background: #eaf7ef;
}

.products-page .status-low {
    color: #b9781b;
    background: #fff4e2;
}

.products-page .status-out {
    color: #c52e3b;
    background: #fff0f1;
}

.products-page .action-links {
    display: flex;
    align-items: center;
    gap: 12px;
    white-space: nowrap;
}

.products-page .action-links a,
.products-page .action-links button {
    background: none;
    border: 0;
    padding: 0;
    font-size: 11px;
    font-weight: 700;
    text-decoration: none;
    color: #3974c6;
    cursor: pointer;
}

.products-page .action-links button {
    color: var(--product-red);
}

.products-page .action-links form {
    margin: 0;
}

.products-page .empty-state {
    text-align: center;
    padding: 42px 15px;
    color: var(--product-muted);
    font-size: 12px;
}

.products-page .empty-state .empty-icon {
    font-size: 27px;
    margin-bottom: 8px;
}

.products-page .pagination {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    padding: 15px 19px;
    border-top: 1px solid var(--product-border);
    font-size: 11px;
    color: var(--product-muted);
}

.products-page .pagination-links {
    display: flex;
    gap: 5px;
}

.products-page .pagination-links a,
.products-page .pagination-links span {
    min-width: 30px;
    height: 30px;
    display: grid;
    place-items: center;
    border: 1px solid #e8eaf0;
    border-radius: 7px;
    text-decoration: none;
    color: #454b57;
    font-size: 11px;
    padding: 0 8px;
}

.products-page .pagination-links .current {
    color: white;
    background: var(--product-red);
    border-color: var(--product-red);
}

@media(max-width:1000px) {
    .products-page .summary-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .products-page .workspace-grid {
        grid-template-columns: 1fr;
    }
}

@media(max-width:650px) {
    .products-page .product-heading {
        align-items: flex-start;
        flex-direction: column;
    }

    .products-page .product-heading .premium-btn {
        width: 100%;
    }

    .products-page .summary-card {
        padding: 13px;
    }

    .products-page .summary-value {
        font-size: 21px;
    }

    .products-page .panel-content {
        padding: 14px;
    }

    .products-page .product-form-grid {
        grid-template-columns: 1fr;
    }

    .products-page .field.full {
        grid-column: auto;
    }

    .products-page .filter-form {
        width: 100%;
    }

    .products-page .filter-form input,
    .products-page .filter-form select {
        width: 100%;
    }

    .products-page .filter-form .premium-btn {
        flex: 1;
    }

    .products-page .pagination {
        align-items: flex-start;
        flex-direction: column;
    }
}
</style>

<div class="products-page">

    <!-- PAGE HEADING -->

    <div class="product-heading">
        <div>
            <h1>Products & Inventory</h1>
            <p>Manage your products, pricing, and stock levels.</p>
        </div>

        <button
            type="button"
            class="premium-btn"
            onclick="document.getElementById('product-form').scrollIntoView({behavior:'smooth'})"
        >
            ＋ Add New Product
        </button>
    </div>

    <!-- SUMMARY CARDS -->

    <div class="summary-grid">

        <div class="summary-card">
            <div class="summary-top">
                <span class="summary-label">Total Products</span>
                <span class="summary-icon">▦</span>
            </div>
            <div class="summary-value">
                <?= number_format((int)$summary['total_products']) ?>
            </div>
            <div class="summary-note">Active products in inventory</div>
        </div>

        <div class="summary-card">
            <div class="summary-top">
                <span class="summary-label">Low Stock</span>
                <span class="summary-icon orange">⚠</span>
            </div>
            <div class="summary-value">
                <?= number_format((int)$summary['low_stock']) ?>
            </div>
            <div class="summary-note">Products needing restocking</div>
        </div>

        <div class="summary-card">
            <div class="summary-top">
                <span class="summary-label">Out of Stock</span>
                <span class="summary-icon blue">□</span>
            </div>
            <div class="summary-value">
                <?= number_format((int)$summary['out_of_stock']) ?>
            </div>
            <div class="summary-note">Products with zero stock</div>
        </div>

        <div class="summary-card">
            <div class="summary-top">
                <span class="summary-label">Inventory Value</span>
                <span class="summary-icon green">₱</span>
            </div>
            <div class="summary-value">
                <?= money($summary['inventory_value']) ?>
            </div>
            <div class="summary-note">Based on unit cost × stock</div>
        </div>

    </div>

    <!-- PRODUCT FORM + STOCK ADJUSTMENT -->

    <div class="workspace-grid">

        <!-- PRODUCT FORM -->

        <section class="premium-panel" id="product-form-panel">

            <div class="panel-top">
                <h2><?= $edit ? 'Edit Product' : 'Add New Product' ?></h2>
                <p>
                    <?= $edit
                        ? 'Update the selected product information.'
                        : 'Enter the details of your new product.' ?>
                </p>
            </div>

            <div class="panel-content">

                <form
                    id="product-form"
                    method="post"
                    enctype="multipart/form-data"
                >

                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">

                    <div class="product-form-grid">

                        <div class="field full">
                            <label>Product Name *</label>
                            <input
                                name="name"
                                required
                                maxlength="255"
                                placeholder="Enter product name"
                                value="<?= e($edit['name'] ?? '') ?>"
                            >
                        </div>

                        <div class="field">
                            <label>SKU / Barcode</label>
                            <input
                                name="sku"
                                placeholder="Enter SKU or barcode"
                                value="<?= e($edit['sku'] ?? '') ?>"
                            >
                        </div>

                        <div class="field">
                            <label>Category</label>
                            <select name="category_id">
                                <option value="">Uncategorized</option>

                                <?php foreach ($categories as $c): ?>
                                    <option
                                        value="<?= (int)$c['id'] ?>"
                                        <?= isset($edit['category_id']) &&
                                            (int)$edit['category_id'] === (int)$c['id']
                                            ? 'selected'
                                            : '' ?>
                                    >
                                        <?= e($c['name']) ?>
                                    </option>
                                <?php endforeach; ?>

                            </select>
                        </div>

                        <div class="field full">
                            <label>Product Image</label>

                            <div class="image-upload-box">

                                <div class="image-preview">

                                    <?php
                                    $currentImage = product_image_path($edit['image'] ?? null);
                                    ?>

                                    <img
                                        id="image-preview"
                                        src="<?= e($currentImage ?? 'assets/jobili-logo.png') ?>"
                                        alt="Product preview"
                                    >

                                    <div class="image-preview-info">
                                        <b id="image-preview-title">
                                            <?= $currentImage
                                                ? 'Current product image'
                                                : 'Product image preview' ?>
                                        </b>
                                        JPG, PNG, or WEBP. Maximum 2MB.
                                    </div>

                                </div>

                                <input
                                    type="file"
                                    name="image"
                                    id="product-image"
                                    accept="image/jpeg,image/png,image/webp"
                                >

                                <small>
                                    Leave empty to keep the existing image when editing.
                                </small>

                            </div>
                        </div>

                        <div class="field">
                            <label>Selling Price (₱) *</label>
                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="price"
                                required
                                value="<?= e($edit['price'] ?? '0') ?>"
                            >
                        </div>

                        <div class="field">
                            <label>Unit Cost (₱)</label>
                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                name="cost"
                                value="<?= e($edit['cost'] ?? '0') ?>"
                            >
                        </div>

                        <div class="field">
                            <label>Stock Quantity *</label>
                            <input
                                type="number"
                                min="0"
                                name="stock"
                                required
                                value="<?= e($edit['stock'] ?? '0') ?>"
                            >
                        </div>

                        <div class="field">
                            <label>Low Stock Threshold</label>
                            <input
                                type="number"
                                min="0"
                                name="reorder_level"
                                value="<?= e($edit['reorder_level'] ?? '5') ?>"
                            >
                        </div>

                        <div class="field full form-buttons">

                            <button type="submit" class="premium-btn">
                                <?= $edit ? 'Save Changes' : '＋ Save Product' ?>
                            </button>

                            <?php if ($edit): ?>
                                <a href="products.php" class="premium-btn secondary">
                                    Cancel
                                </a>
                            <?php endif; ?>

                        </div>

                    </div>

                </form>

            </div>

        </section>

        <!-- INVENTORY ADJUSTMENT -->

        <section class="premium-panel">

            <div class="panel-top">
                <h2>Inventory Adjustment</h2>
                <p>Record deliveries, corrections, and damaged goods.</p>
            </div>

            <div class="panel-content">

                <form method="post" class="adjust-form" id="adjust-form">

                    <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="adjust">

                    <div>
                        <label>Select Product</label>

                        <select name="id" id="adjust-product" required>
                            <option value="">Choose a product</option>

                            <?php foreach ($adjustProducts as $p): ?>
                                <option
                                    value="<?= (int)$p['id'] ?>"
                                    data-stock="<?= (int)$p['stock'] ?>"
                                >
                                    <?= e($p['name']) ?>
                                </option>
                            <?php endforeach; ?>

                        </select>
                    </div>

                    <div class="stock-preview">
                        Current stock:
                        <strong id="current-stock">—</strong>
                        <br>
                        Projected stock:
                        <strong class="projected" id="projected-stock">—</strong>
                    </div>

                    <div>
                        <label>Adjustment Type</label>

                        <select id="adjustment-type">
                            <option value="in">Stock In</option>
                            <option value="out">Stock Out</option>
                        </select>
                    </div>

                    <div>
                        <label>Quantity</label>
                        <input
                            type="number"
                            id="adjustment-quantity"
                            min="1"
                            step="1"
                            placeholder="Enter quantity"
                            required
                        >
                    </div>

                    <input
                        type="hidden"
                        name="change_qty"
                        id="change-qty"
                    >

                    <div>
                        <label>Reason</label>

                        <select name="reason" id="adjustment-reason" required>
                            <option value="Delivery">New Delivery</option>
                            <option value="Damaged Goods">Damaged Goods</option>
                            <option value="Stock Correction">Stock Correction</option>
                            <option value="Customer Return">Customer Return</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="adjust-hint">
                        Stock adjustments are automatically recorded in the inventory log.
                        Please verify the quantity before saving.
                    </div>

                    <button type="submit" class="premium-btn secondary">
                        Update Inventory
                    </button>

                </form>

            </div>

        </section>

    </div>

    <!-- PRODUCT LIST -->

    <section class="premium-panel list-panel">

        <div class="list-toolbar">

            <div>
                <h2>Product Inventory</h2>
                <p>
                    Showing <?= count($products) ?> of
                    <?= number_format($totalFiltered) ?> matching products
                </p>
            </div>

            <form method="get" class="filter-form" id="product-filter">

                <input
                    type="search"
                    name="q"
                    id="product-search"
                    placeholder="Search product or SKU..."
                    value="<?= e($q) ?>"
                >

                <select name="category">
                    <option value="0">All Categories</option>

                    <?php foreach ($categories as $c): ?>
                        <option
                            value="<?= (int)$c['id'] ?>"
                            <?= $categoryFilter === (int)$c['id'] ? 'selected' : '' ?>
                        >
                            <?= e($c['name']) ?>
                        </option>
                    <?php endforeach; ?>

                </select>

                <select name="stock_status">
                    <option value="">All Stock Status</option>
                    <option value="in_stock" <?= $stockFilter === 'in_stock' ? 'selected' : '' ?>>
                        In Stock
                    </option>
                    <option value="low_stock" <?= $stockFilter === 'low_stock' ? 'selected' : '' ?>>
                        Low Stock
                    </option>
                    <option value="out_of_stock" <?= $stockFilter === 'out_of_stock' ? 'selected' : '' ?>>
                        Out of Stock
                    </option>
                </select>

                <button type="submit" class="premium-btn">
                    Filter
                </button>

                <?php if ($q !== '' || $categoryFilter || $stockFilter !== ''): ?>
                    <a href="products.php" class="premium-btn secondary">
                        Reset
                    </a>
                <?php endif; ?>

            </form>

        </div>

        <div class="table-wrap">

            <table>

                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Cost</th>
                        <th>Stock</th>
                        <th>Stock Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (!$products): ?>

                        <tr>
                            <td colspan="7">
                                <div class="empty-state">
                                    <div class="empty-icon">▦</div>
                                    <b>No products found</b>
                                    <p>Try changing your filters or add a new product.</p>
                                </div>
                            </td>
                        </tr>

                    <?php endif; ?>

                    <?php foreach ($products as $p): ?>

                        <?php
                        $image = product_image_path($p['image'] ?? null);

                        if ((int)$p['stock'] === 0) {
                            $status = 'Out of Stock';
                            $statusClass = 'status-out';
                        } elseif ((int)$p['stock'] <= (int)$p['reorder_level']) {
                            $status = 'Low Stock';
                            $statusClass = 'status-low';
                        } else {
                            $status = 'In Stock';
                            $statusClass = 'status-good';
                        }
                        ?>

                        <tr>

                            <td>
                                <div class="product-cell">

                                    <?php if ($image): ?>

                                        <img
                                            class="product-thumb"
                                            src="<?= e($image) ?>"
                                            alt="<?= e($p['name']) ?>"
                                        >

                                    <?php else: ?>

                                        <div class="product-thumb product-placeholder">
                                            ▦
                                        </div>

                                    <?php endif; ?>

                                    <div>
                                        <b><?= e($p['name']) ?></b>
                                        <small><?= e($p['sku'] ?: 'No SKU') ?></small>
                                    </div>

                                </div>
                            </td>

                            <td><?= e($p['category'] ?? 'Uncategorized') ?></td>

                            <td><b><?= money($p['price']) ?></b></td>

                            <td><?= money($p['cost']) ?></td>

                            <td>
                                <b><?= number_format((int)$p['stock']) ?></b>
                            </td>

                            <td>
                                <span class="status-pill <?= $statusClass ?>">
                                    <?= e($status) ?>
                                </span>
                            </td>

                            <td>
                                <div class="action-links">

                                    <a href="products.php?edit=<?= (int)$p['id'] ?>">
                                        Edit
                                    </a>

                                    <?php if (current_user()['role'] === 'owner'): ?>

                                        <form
                                            method="post"
                                            onsubmit="return confirm('Archive this product? It will no longer appear in active inventory.');"
                                        >
                                            <input
                                                type="hidden"
                                                name="csrf"
                                                value="<?= e(csrf_token()) ?>"
                                            >

                                            <input type="hidden" name="action" value="archive">

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="<?= (int)$p['id'] ?>"
                                            >

                                            <button type="submit">Archive</button>
                                        </form>

                                    <?php endif; ?>

                                </div>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

        <!-- PAGINATION -->

        <?php if ($totalPages > 1): ?>

            <div class="pagination">

                <span>
                    Page <?= $page ?> of <?= $totalPages ?>
                </span>

                <div class="pagination-links">

                    <?php
                    $queryParams = $_GET;
                    ?>

                    <?php if ($page > 1): ?>
                        <?php
                        $queryParams['page'] = $page - 1;
                        ?>
                        <a href="?<?= e(http_build_query($queryParams)) ?>">
                            Previous
                        </a>
                    <?php endif; ?>

                    <?php
                    $startPage = max(1, $page - 2);
                    $endPage = min($totalPages, $page + 2);

                    for ($i = $startPage; $i <= $endPage; $i++):
                        $queryParams['page'] = $i;
                    ?>

                        <?php if ($i === $page): ?>

                            <span class="current"><?= $i ?></span>

                        <?php else: ?>

                            <a href="?<?= e(http_build_query($queryParams)) ?>">
                                <?= $i ?>
                            </a>

                        <?php endif; ?>

                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                        <?php
                        $queryParams['page'] = $page + 1;
                        ?>
                        <a href="?<?= e(http_build_query($queryParams)) ?>">
                            Next
                        </a>
                    <?php endif; ?>

                </div>

            </div>

        <?php endif; ?>

    </section>

</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    /* IMAGE PREVIEW */

    const imageInput = document.getElementById('product-image');
    const imagePreview = document.getElementById('image-preview');
    const imageTitle = document.getElementById('image-preview-title');

    if (imageInput) {
        imageInput.addEventListener('change', function () {

            const file = this.files[0];

            if (!file) return;

            const allowed = [
                'image/jpeg',
                'image/png',
                'image/webp'
            ];

            if (!allowed.includes(file.type)) {
                alert('Only JPG, PNG, and WEBP images are allowed.');
                this.value = '';
                return;
            }

            if (file.size > 2 * 1024 * 1024) {
                alert('Image must not exceed 2MB.');
                this.value = '';
                return;
            }

            const reader = new FileReader();

            reader.onload = function (event) {
                imagePreview.src = event.target.result;
                imageTitle.textContent = file.name;
            };

            reader.readAsDataURL(file);
        });
    }

    /* STOCK ADJUSTMENT PREVIEW */

    const productSelect = document.getElementById('adjust-product');
    const adjustmentType = document.getElementById('adjustment-type');
    const adjustmentQuantity = document.getElementById('adjustment-quantity');

    const currentStock = document.getElementById('current-stock');
    const projectedStock = document.getElementById('projected-stock');
    const changeQty = document.getElementById('change-qty');

    function updateStockPreview() {

        const option = productSelect.options[productSelect.selectedIndex];

        const stock = option && option.value
            ? Number(option.dataset.stock || 0)
            : null;

        const quantity = Number(adjustmentQuantity.value || 0);

        if (stock === null) {
            currentStock.textContent = '—';
            projectedStock.textContent = '—';
            changeQty.value = '';
            return;
        }

        const isStockIn = adjustmentType.value === 'in';
        const change = isStockIn ? quantity : -quantity;

        const projected = stock + change;

        currentStock.textContent = stock.toLocaleString();
        projectedStock.textContent = projected.toLocaleString();

        changeQty.value = quantity > 0 ? change : '';
        projectedStock.style.color = projected < 0 ? '#c52e3b' : '#d92d3a';
    }

    if (productSelect) {
        productSelect.addEventListener('change', updateStockPreview);
        adjustmentType.addEventListener('change', updateStockPreview);
        adjustmentQuantity.addEventListener('input', updateStockPreview);
    }

    /* STOCK ADJUSTMENT CONFIRMATION */

    const adjustForm = document.getElementById('adjust-form');

    if (adjustForm) {
        adjustForm.addEventListener('submit', function (event) {

            const option = productSelect.options[productSelect.selectedIndex];
            const stock = Number(option?.dataset.stock || 0);
            const quantity = Number(adjustmentQuantity.value || 0);

            const change = adjustmentType.value === 'in'
                ? quantity
                : -quantity;

            if (!option.value || quantity <= 0) {
                event.preventDefault();
                alert('Please select a product and enter a valid quantity.');
                return;
            }

            if (stock + change < 0) {
                event.preventDefault();
                alert('Insufficient stock. The adjustment would result in negative stock.');
                return;
            }

            changeQty.value = change;

            const type = change > 0 ? 'add to' : 'remove from';

            if (!confirm(
                'Are you sure you want to ' +
                type + ' inventory?\n\n' +
                'Current stock: ' + stock + '\n' +
                'New stock: ' + (stock + change)
            )) {
                event.preventDefault();
            }
        });
    }

    /* LIVE SEARCH */

    const search = document.getElementById('product-search');
    const filterForm = document.getElementById('product-filter');

    if (search && filterForm) {
        let searchTimer;

        search.addEventListener('input', function () {
            clearTimeout(searchTimer);

            searchTimer = setTimeout(function () {
                filterForm.requestSubmit();
            }, 500);
        });
    }

});
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>
