
<?php
require_once __DIR__ . '/config.php';

// Clear customer login and shopping cart
unset($_SESSION['customer']);
unset($_SESSION['cart']);

// Regenerate session ID for security
session_regenerate_id(true);

// Return to customer login page
redirect('customer_login.php');
exit;
