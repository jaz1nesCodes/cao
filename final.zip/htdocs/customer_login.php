
<?php
require_once __DIR__ . '/config.php';

$error = '';
$success = '';

if (!empty($_SESSION['flash'])) {
    [$success, $flashType] = $_SESSION['flash'];
    unset($_SESSION['flash']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $error = 'Please enter your email and password.';
    } else {
        try {
            $pdo = db();

            $stmt = $pdo->prepare("
                SELECT
                    ca.id,
                    ca.customer_id,
                    ca.email,
                    ca.password_hash,
                    c.name
                FROM customer_accounts ca
                INNER JOIN customers c
                    ON c.id = ca.customer_id
                WHERE ca.email = ?
                LIMIT 1
            ");

            $stmt->execute([$email]);
            $customer = $stmt->fetch();

            if ($customer && password_verify($password, $customer['password_hash'])) {

                session_regenerate_id(true);

                $_SESSION['customer'] = [
                    'account_id' => (int)$customer['id'],
                    'id' => (int)$customer['customer_id'],
                    'name' => $customer['name'],
                    'email' => $customer['email']
                ];

                redirect('customer_shop.php');

            } else {
                $error = 'Incorrect email or password.';
            }

        } catch (PDOException $e) {
            error_log($e->getMessage());
            $error = 'Unable to log in right now. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Customer Login | Jobili</title>

<style>
:root {
    --primary: #d62828;
    --primary-dark: #ad1717;
    --text: #242424;
    --muted: #858585;
    --border: #eaeaea;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 30px 18px;
    font-family: 'Segoe UI', Arial, sans-serif;
    color: var(--text);
    background:
        radial-gradient(circle at 10% 15%, rgba(214,40,40,.07), transparent 28%),
        radial-gradient(circle at 90% 85%, rgba(214,40,40,.06), transparent 30%),
        #f7f7f9;
}

.login-wrapper {
    width: 100%;
    max-width: 430px;
    animation: appear .65s ease;
}

@keyframes appear {
    from {
        opacity: 0;
        transform: translateY(18px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* BRAND */

.brand {
    text-align: center;
    margin-bottom: 27px;
}

.brand img {
    display: block;
    width: 240px;
    max-width: 80%;
    height: auto;
    object-fit: contain;
    margin: 0 auto 10px;
}

.brand p {
    color: var(--muted);
    font-size: 13px;
    letter-spacing: .3px;
}

/* LOGIN CARD */

.login-card {
    position: relative;
    background: #fff;
    padding: 40px;
    border: 1px solid rgba(0,0,0,.035);
    border-radius: 20px;
    box-shadow:
        0 20px 60px rgba(0,0,0,.055),
        0 3px 12px rgba(0,0,0,.025);
}

.login-heading {
    margin-bottom: 30px;
}

.login-heading .eyebrow {
    color: var(--primary);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    margin-bottom: 10px;
}

.login-heading h2 {
    font-size: 27px;
    font-weight: 750;
    letter-spacing: -.8px;
    margin-bottom: 8px;
}

.login-heading p {
    color: var(--muted);
    font-size: 13px;
    line-height: 1.6;
}

/* NOTIFICATIONS */

.message {
    padding: 13px 15px;
    border-radius: 10px;
    font-size: 13px;
    margin-bottom: 20px;
    line-height: 1.5;
}

.error {
    background: #fff0f0;
    color: #b42323;
    border: 1px solid #ffd5d5;
}

.success {
    background: #edfff1;
    color: #18753a;
    border: 1px solid #c9f0d3;
}

/* FORM */

.form-group {
    margin-bottom: 21px;
}

label {
    display: block;
    margin-bottom: 9px;
    font-size: 13px;
    font-weight: 700;
    color: #383838;
}

.input-wrapper {
    position: relative;
}

.input-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #aaa;
    font-size: 17px;
    pointer-events: none;
}

input {
    width: 100%;
    height: 51px;
    padding: 0 14px 0 43px;
    border: 1px solid var(--border);
    border-radius: 10px;
    outline: none;
    background: #fafafa;
    color: #222;
    font-size: 14px;
    transition: .25s ease;
}

input::placeholder {
    color: #b5b5b5;
}

input:focus {
    background: #fff;
    border-color: var(--primary);
    box-shadow: 0 0 0 4px rgba(214,40,40,.08);
}

.password-input {
    padding-right: 75px;
}

.toggle-password {
    position: absolute;
    right: 13px;
    top: 50%;
    transform: translateY(-50%);
    background: transparent;
    border: none;
    color: var(--primary);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: .5px;
    cursor: pointer;
}

/* LOGIN BUTTON */

.login-button {
    width: 100%;
    height: 52px;
    margin-top: 8px;
    border: none;
    border-radius: 10px;
    background: linear-gradient(135deg, #e33636, #bd1717);
    color: white;
    font-size: 14px;
    font-weight: 800;
    letter-spacing: .4px;
    cursor: pointer;
    box-shadow: 0 7px 18px rgba(214,40,40,.20);
    transition: .25s ease;
}

.login-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 23px rgba(214,40,40,.28);
    background: linear-gradient(135deg, #ed4141, #ad1717);
}

.login-button:active {
    transform: translateY(0);
}

/* REGISTER */

.register-section {
    text-align: center;
    margin-top: 27px;
    padding-top: 23px;
    border-top: 1px solid #f0f0f0;
    color: var(--muted);
    font-size: 13px;
}

.register-section a {
    color: var(--primary);
    font-weight: 800;
    text-decoration: none;
    margin-left: 3px;
}

.register-section a:hover {
    text-decoration: underline;
}

/* FOOTER */

.bottom-text {
    text-align: center;
    margin-top: 25px;
    font-size: 11px;
    color: #aaa;
}

.trust-text {
    text-align: center;
    margin-top: 13px;
    color: #999;
    font-size: 11px;
    letter-spacing: .2px;
}

/* RESPONSIVE */

@media (max-width: 480px) {
    body {
        padding: 22px 16px;
    }

    .login-card {
        padding: 30px 23px;
        border-radius: 16px;
    }

    .login-heading h2 {
        font-size: 24px;
    }

    .brand img {
        width: 210px;
    }
}
</style>
</head>

<body>

<div class="login-wrapper">

    <div class="brand">
        <img src="assets/jobili-logo.png" alt="JOBILI Logo">
        <p>Your convenient online shopping experience</p>
    </div>

    <div class="login-card">

        <div class="login-heading">
            <div class="eyebrow">CUSTOMER PORTAL</div>
            <h2>Welcome Back!</h2>
            <p>Sign in to your account and continue shopping with Jobili.</p>
        </div>

        <?php if ($success): ?>
            <div class="message success">
                <?= e($success) ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="message error">
                <?= e($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <input type="hidden" name="csrf"
                   value="<?= e(csrf_token()) ?>">

            <div class="form-group">
                <label for="email">Email Address</label>

                <div class="input-wrapper">
                    <span class="input-icon">✉</span>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        maxlength="190"
                        placeholder="Enter your email"
                        autocomplete="email"
                        value="<?= e($_POST['email'] ?? '') ?>"
                        required
                    >
                </div>
            </div>

            <div class="form-group">
                <label for="password">Password</label>

                <div class="input-wrapper">
                    <span class="input-icon">🔒</span>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        class="password-input"
                        placeholder="Enter your password"
                        autocomplete="current-password"
                        required
                    >

                    <button
                        type="button"
                        class="toggle-password"
                        onclick="togglePassword()"
                        id="toggleButton"
                    >
                        SHOW
                    </button>
                </div>
            </div>

            <button type="submit" class="login-button">
                Sign In &nbsp; →
            </button>

        </form>

        <div class="register-section">
            Don't have an account?
            <a href="customer_register.php">Create Account</a>
        </div>

    </div>

    <div class="trust-text">
        Secure Login &nbsp; • &nbsp; Easy Shopping &nbsp; • &nbsp; Jobili
    </div>

    <div class="bottom-text">
        © <?= date('Y') ?> Jobili. All rights reserved.
    </div>

</div>

<script>
function togglePassword() {
    const password = document.getElementById('password');
    const button = document.getElementById('toggleButton');

    if (password.type === 'password') {
        password.type = 'text';
        button.textContent = 'HIDE';
    } else {
        password.type = 'password';
        button.textContent = 'SHOW';
    }
}
</script>

</body>
</html>
