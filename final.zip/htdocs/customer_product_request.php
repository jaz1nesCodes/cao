
<?php
require_once __DIR__ . '/config.php';

if (empty($_SESSION['customer'])) {
    redirect('customer_login.php');
}

$pdo = db();

$customerId = (int)($_SESSION['customer']['id'] ?? 0);
$customerName = $_SESSION['customer']['name'] ?? 'Customer';

$errors = [];
$success = '';

/* SUBMIT PRODUCT REQUEST */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $productName = trim($_POST['product_name'] ?? '');
    $quantity = (int)($_POST['preferred_quantity'] ?? 1);
    $details = trim($_POST['details'] ?? '');

    if ($productName === '') {
        $errors[] = 'Please enter the product name.';
    }

    if (strlen($productName) > 150) {
        $errors[] = 'Product name must not exceed 150 characters.';
    }

    if ($quantity < 1 || $quantity > 9999) {
        $errors[] = 'Please enter a valid quantity.';
    }

    if (strlen($details) > 5000) {
        $errors[] = 'Additional details are too long.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare("
            INSERT INTO customer_product_requests
                (customer_id, product_name, preferred_quantity, details)
            VALUES (?, ?, ?, ?)
        ");

        $stmt->execute([
            $customerId,
            $productName,
            $quantity,
            $details !== '' ? $details : null
        ]);

        $success = 'Your product request has been submitted successfully.';
    }
}

/* CUSTOMER REQUEST HISTORY */

$stmt = $pdo->prepare("
    SELECT id, product_name, preferred_quantity, details, status, created_at
    FROM customer_product_requests
    WHERE customer_id = ?
    ORDER BY created_at DESC
");

$stmt->execute([$customerId]);
$requests = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>JOBILI | Request a Product</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #f7f7f9;
    color: #24242a;
    font-family: 'Segoe UI', Arial, sans-serif;
}

.navbar {
    background: white;
    min-height: 65px;
    padding: 10px 5%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    border-bottom: 1px solid #eee;
}

.logo img {
    width: 125px;
    display: block;
}

.nav-links {
    display: flex;
    align-items: center;
    gap: 18px;
    font-size: 13px;
}

.nav-links a {
    color: #555;
    text-decoration: none;
    font-weight: 650;
}

.nav-links a:hover {
    color: #d62828;
}

.container {
    width: 92%;
    max-width: 1100px;
    margin: 35px auto 55px;
}

.heading {
    margin-bottom: 23px;
}

.heading h1 {
    font-size: 27px;
    margin: 0 0 8px;
}

.heading p {
    color: #85858f;
    font-size: 13px;
    margin: 0;
    line-height: 1.6;
}

.panel {
    background: white;
    padding: 25px;
    border: 1px solid #eee;
    border-radius: 14px;
    margin-bottom: 25px;
}

.panel h2 {
    font-size: 18px;
    margin: 0 0 7px;
}

.panel-description {
    color: #85858f;
    font-size: 12px;
    margin-bottom: 22px;
}

.form-group {
    margin-bottom: 17px;
}

label {
    display: block;
    font-size: 12px;
    font-weight: 750;
    margin-bottom: 8px;
}

input, textarea {
    width: 100%;
    padding: 12px 13px;
    border: 1px solid #e5e5e9;
    border-radius: 8px;
    font-family: inherit;
    font-size: 13px;
    outline: none;
}

input:focus, textarea:focus {
    border-color: #d62828;
}

textarea {
    min-height: 100px;
    resize: vertical;
}

.hint {
    color: #999;
    font-size: 11px;
    margin-top: 6px;
}

.btn {
    display: inline-block;
    padding: 12px 19px;
    border: none;
    border-radius: 8px;
    background: #d62828;
    color: white;
    font-weight: 750;
    font-size: 13px;
    cursor: pointer;
    text-decoration: none;
}

.btn:hover {
    background: #ad1717;
}

.message, .error {
    padding: 13px 16px;
    border-radius: 9px;
    font-size: 13px;
    margin-bottom: 16px;
}

.message {
    background: #eaf9ef;
    color: #176b37;
}

.error {
    background: #fff0f0;
    color: #a00000;
}

.table-wrap {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 650px;
}

th, td {
    text-align: left;
    padding: 14px 12px;
    border-bottom: 1px solid #eee;
    font-size: 12px;
}

th {
    color: #777;
    background: #fafafa;
    font-size: 11px;
    text-transform: uppercase;
}

.status {
    display: inline-block;
    padding: 5px 9px;
    border-radius: 20px;
    background: #fff4dc;
    color: #986400;
    font-size: 10px;
    font-weight: 800;
}

.status.available {
    background: #e5f8eb;
    color: #18753a;
}

.status.unavailable {
    background: #fff0f0;
    color: #b51e1e;
}

.status.reviewing {
    background: #eaf2ff;
    color: #285a9b;
}

.empty {
    padding: 25px;
    text-align: center;
    color: #999;
    font-size: 13px;
}

.footer {
    background: white;
    border-top: 1px solid #eee;
    text-align: center;
    padding: 22px;
    color: #999;
    font-size: 11px;
}

@media(max-width:600px) {
    .navbar {
        padding: 10px 4%;
    }

    .logo img {
        width: 100px;
    }

    .nav-links {
        gap: 10px;
        font-size: 11px;
    }

    .container {
        width: 94%;
        margin-top: 25px;
    }

    .panel {
        padding: 18px;
    }

    .heading h1 {
        font-size: 23px;
    }
}
</style>
</head>

<body>

<header class="navbar">
    <a href="customer_shop.php" class="logo">
        <img src="assets/jobili-logo.png" alt="JOBILI Logo">
    </a>

    <nav class="nav-links">
        <a href="customer_shop.php">Shop</a>
        <a href="customer_orders.php">My Orders</a>
        <a href="customer_logout.php">Logout</a>
    </nav>
</header>

<main class="container">

    <div class="heading">
        <h1>Request a Product</h1>
        <p>
            Looking for something that is not available in our shop?
            Tell us what product you need so we can consider it for future stocking.
        </p>
    </div>

    <?php if ($success): ?>
        <div class="message"><?= e($success) ?></div>
    <?php endif; ?>

    <?php foreach ($errors as $error): ?>
        <div class="error"><?= e($error) ?></div>
    <?php endforeach; ?>

    <section class="panel">

        <h2>Product Details</h2>

        <p class="panel-description">
            Fill out the form below to send your product request.
        </p>

        <form method="POST">

            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

            <div class="form-group">
                <label for="product_name">Product Name *</label>

                <input
                    type="text"
                    id="product_name"
                    name="product_name"
                    maxlength="150"
                    placeholder="Example: Bear Brand 1kg"
                    value="<?= e($_POST['product_name'] ?? '') ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="preferred_quantity">Preferred Quantity *</label>

                <input
                    type="number"
                    id="preferred_quantity"
                    name="preferred_quantity"
                    min="1"
                    max="9999"
                    value="<?= e($_POST['preferred_quantity'] ?? '1') ?>"
                    required
                >

                <div class="hint">
                    How many pieces or units would you usually need?
                </div>
            </div>

            <div class="form-group">
                <label for="details">Additional Details (Optional)</label>

                <textarea
                    id="details"
                    name="details"
                    maxlength="5000"
                    placeholder="Brand, size, variant, or other product details..."
                ><?= e($_POST['details'] ?? '') ?></textarea>
            </div>

            <button type="submit" class="btn">
                Submit Product Request
            </button>

        </form>

    </section>

    <section class="panel">

        <h2>My Product Requests</h2>

        <p class="panel-description">
            Check the status of the products you have requested.
        </p>

        <?php if (!$requests): ?>

            <div class="empty">
                You haven't submitted any product requests yet.
            </div>

        <?php else: ?>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Details</th>
                            <th>Status</th>
                            <th>Date Requested</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($requests as $request): ?>

                            <?php
                            $statusClass = match ($request['status']) {
                                'Available' => 'available',
                                'Not Available' => 'unavailable',
                                'Reviewing' => 'reviewing',
                                default => ''
                            };
                            ?>

                            <tr>
                                <td><strong><?= e($request['product_name']) ?></strong></td>
                                <td><?= (int)$request['preferred_quantity'] ?></td>
                                <td><?= e($request['details'] ?: '—') ?></td>
                                <td>
                                    <span class="status <?= $statusClass ?>">
                                        <?= e($request['status']) ?>
                                    </span>
                                </td>
                                <td><?= date('M j, Y', strtotime($request['created_at'])) ?></td>
                            </tr>

                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>

    </section>

</main>

<footer class="footer">
    © <?= date('Y') ?> JOBILI. All rights reserved.
</footer>

</body>
</html>
